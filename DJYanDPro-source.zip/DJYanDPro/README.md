# DJ Yan-D PRO — socle Android (Phase 0 / 1A)

Application Android native Kotlin dont la règle de conception est : **aucune fonction musicale ne peut être affichée comme disponible sans capacité réellement validée**.

## État de cette livraison

- Projet Android Kotlin / Jetpack Compose initialisé.
- Navigation native fonctionnelle : Accueil, Création de soirée, Sources, Recherche, Mes soirées, Paramètres.
- Parcours de configuration de soirée fonctionnel localement (nom, styles, ambiance, durée, énergie).
- Enregistrement réel local des projets de soirées dans DataStore ; liste, duplication et suppression réellement disponibles. Ces projets ne prétendent pas contenir une playlist tant qu’aucune source/catalogue autorisé n’est actif.
- `Music Source Engine` représenté par des fournisseurs aux capacités et états explicites.
- Bibliothèque locale réellement intégrée : sélection multiple de documents audio Android, permission URI persistante et mémorisation des références sélectionnées dans DataStore.
- File de lecture locale réelle via Media3/ExoPlayer dans `YanDPlaybackService`, avec MediaSession et service média de premier plan pour les commandes système/arrière-plan.
- Crossfade local réel réglable de 0 à 12 secondes lorsque deux fichiers sont réellement prêts : deux lecteurs Media3 superposent les deux flux locaux via des rampes de volume opposées. `0` désactive explicitement le fondu. Si les conditions ne sont pas réunies, aucun faux fondu n’est affiché ni aucun son de remplissage créé.
- Volume DJ Yan-D réel et mémorisé : gain interne 0–100 % appliqué aux deux lecteurs, y compris pendant un crossfade, sans modifier le volume système Android.
- Autopilote local : une fois lancé, le service lit, précharge et enchaîne automatiquement toute la file locale. Aucun réglage de mix manuel n’est requis.
- Préparation autonome locale : Yan-D peut analyser réellement le BPM des fichiers de la file puis réordonner cette file par BPM croissant. La règle est affichée comme un simple tri de tempo, jamais comme une analyse complète de la musicalité.
- Adaptation en direct limitée au tempo : les commandes Plus calme et Plus festif réorganisent seulement les pistes restantes ayant un BPM réel, sans couper la piste active ni prétendre analyser l’énergie musicale.
- Retour d’erreur de lecture réel : le service transmet à l’écran Sources le titre concerné et le code Media3. Une erreur ne déclenche aucun son ou titre de remplacement.
- Inspection technique réelle à la demande : durée, MIME, débit et fréquence d’échantillonnage lorsque Android la fournit.
- Estimation BPM locale réelle à la demande : décodage PCM, enveloppe d’énergie et autocorrélation sur au plus 180 secondes. Le résultat affiche une confiance et la durée analysée ; en l’absence de signal fiable, aucun BPM n’est fourni.
- Comparaison transparente de deux pistes dont le BPM a été calculé : score limité à l’écart BPM relatif, avec les BPM et l’écart affichés. Ce n’est pas une prétendue compatibilité musicale complète et aucune transition n’est appliquée. L’énergie musicale et la tonalité restent absentes.
- Spotify est `NON CONFIGURÉ` : aucun identifiant et aucune autorisation OAuth ne sont présents.
- Musify est `NON DISPONIBLE` : aucune API publique officielle de partenaire compatible n'est validée.
- Recherche, génération de playlists, autopilote et contrôles DJ sont volontairement désactivés. Il n'existe ni faux morceau, ni son synthétique, ni catalogue fictif.

## Ce qui manque avant compilation dans cet environnement

L'environnement de travail fourni ne contient ni Android SDK, ni Gradle installé, et Java 17 est requis par l'Android Gradle Plugin configuré. Le projet est prêt à être ouvert avec Android Studio récent ou compilé dans une CI Android avec JDK 17.

```bash
./gradlew assembleDebug
# APK : app/build/outputs/apk/debug/app-debug.apk
```

Le wrapper Gradle 8.7 est inclus (`gradlew`, `gradlew.bat`, `gradle/wrapper/`). Il téléchargera la distribution Gradle lors de la première exécution. L’Android SDK et Java 17 restent nécessaires pour compiler l’APK.

## Compilation automatisée proposée

Le workflow GitHub Actions `.github/workflows/android-debug-apk.yml` prépare JDK 17 et Gradle 8.7, lance `assembleDebug`, puis publie l’APK de débogage comme artefact `DJYanDPro-debug-apk`. Il doit être déclenché depuis un dépôt Git dont la racine est ce dossier `DJYanDPro`. Le résultat du workflow doit être contrôlé avant toute déclaration de compilation réussie.

## Étape suivante recommandée — Phase 1B

1. Ajouter Room/DataStore pour enregistrer réellement les brouillons et soirées.
2. Ajouter `LocalLicensedSource` avec le sélecteur de documents Android : uniquement fichiers audio auxquels l'utilisateur possède un droit de lecture/mix.
3. Ajouter Media3, MediaSession et un service média premier plan pour lecture réelle, arrière-plan, verrouillage, Bluetooth et audio focus.
4. Écrire puis exécuter les tests audio et interruption sur appareil Android.

Voir `docs/FAISABILITE_SOURCES.md` pour les règles d'intégration Spotify/Musify, `docs/ANDROID_STUDIO_BUILD_GUIDE.md` pour compiler le projet, et `docs/VALIDATION_DEVICE_REQUIRED.md` pour le protocole obligatoire de validation autonome sur vrai appareil.
