package re.djyan.pro

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Stocke l'identifiant Jamendo fourni par l'utilisateur.
 * Aucune clé n'est intégrée au code : sans identifiant, le catalogue reste fermé
 * et c'est affiché comme tel, jamais contourné.
 */
private val JAMENDO_CLIENT_ID = stringPreferencesKey("jamendo_client_id_v1")

class JamendoRepository(private val context: Context) {
    val clientId: Flow<String> = context.sourceStore.data.map { it[JAMENDO_CLIENT_ID].orEmpty() }
    suspend fun setClientId(value: String) {
        context.sourceStore.edit { it[JAMENDO_CLIENT_ID] = value.trim() }
    }
}
