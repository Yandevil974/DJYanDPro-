package re.djyan.pro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Client officiel Jamendo (API v3.0) — catalogue de musique sous licence
 * Creative Commons, ~500 000 titres d'artistes indépendants.
 *
 * Ce client est RÉEL : il interroge l'API officielle avec un client_id fourni par
 * l'utilisateur (gratuit sur devportal.jamendo.com) et ne renvoie que ce que
 * l'API a répondu. Aucun résultat n'est fabriqué, aucun titre n'est inventé.
 *
 * Limites assumées et annoncées à l'utilisateur :
 *  - ce sont des artistes indépendants, PAS les hits commerciaux ;
 *  - le streaming et le téléchargement dépendent des droits accordés par l'artiste
 *    (champ audiodownload_allowed).
 */
data class JamendoTrack(
    val id: String,
    val name: String,
    val artistName: String,
    val durationSec: Int,
    val streamUrl: String,
    val downloadUrl: String,
    val licenseUrl: String
) {
    fun durationText(): String = String.format("%d:%02d", durationSec / 60, durationSec % 60)
    fun canDownload(): Boolean = downloadUrl.isNotBlank()
}

object JamendoClient {

    private const val ENDPOINT = "https://api.jamendo.com/v3.0/tracks/"
    const val DOCS_URL = "https://devportal.jamendo.com"

    suspend fun search(
        clientId: String,
        tags: String,
        name: String,
        limit: Int = 20,
        fromDate: String? = null,
        toDate: String? = null
    ): Result<List<JamendoTrack>> = withContext(Dispatchers.IO) {
        runCatching {
            if (clientId.isBlank()) throw IllegalStateException("Identifiant Jamendo manquant")
            if (tags.isBlank() && name.isBlank()) throw IllegalStateException("Écris un style ou un nom à chercher")
            val connection = (URL(buildUrl(clientId, tags, name, limit, fromDate, toDate)).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12_000
                readTimeout = 20_000
                setRequestProperty("Accept", "application/json")
            }
            try {
                val code = connection.responseCode
                if (code !in 200..299) throw IllegalStateException("Jamendo a répondu $code")
                parse(connection.inputStream.bufferedReader().readText())
            } finally {
                connection.disconnect()
            }
        }
    }

    fun buildUrl(
        clientId: String,
        tags: String,
        name: String,
        limit: Int,
        fromDate: String? = null,
        toDate: String? = null
    ): String = buildString {
        append(ENDPOINT)
        append("?client_id=").append(enc(clientId))
        append("&format=json&limit=").append(limit.coerceIn(1, 200))
        append("&audioformat=mp32&audiodlformat=mp32")
        append("&order=popularity_total_desc")
        if (tags.isNotBlank()) append("&tags=").append(enc(tags.trim()))
        if (name.isNotBlank()) append("&namesearch=").append(enc(name.trim()))
        // Filtre de période : l'API attend datebetween=AAAA-MM-JJ_AAAA-MM-JJ
        if (!fromDate.isNullOrBlank() && !toDate.isNullOrBlank()) {
            append("&datebetween=").append(enc(fromDate.trim())).append("_").append(enc(toDate.trim()))
        }
    }

    fun parse(body: String): List<JamendoTrack> {
        val results = JSONObject(body).optJSONArray("results") ?: return emptyList()
        return (0 until results.length()).mapNotNull { index ->
            val item = results.optJSONObject(index) ?: return@mapNotNull null
            val id = item.optString("id")
            val stream = item.optString("audio")
            if (id.isBlank() || stream.isBlank()) return@mapNotNull null
            JamendoTrack(
                id = id,
                name = item.optString("name", "Titre inconnu"),
                artistName = item.optString("artist_name", "Artiste inconnu"),
                durationSec = item.optInt("duration", 0),
                streamUrl = stream,
                downloadUrl = item.optString("audiodownload"),
                licenseUrl = item.optString("license_ccurl")
            )
        }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")
}
