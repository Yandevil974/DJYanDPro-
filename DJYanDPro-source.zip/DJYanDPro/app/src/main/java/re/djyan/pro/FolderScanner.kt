package re.djyan.pro

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Importe un DOSSIER ENTIER au lieu de sélectionner les fichiers un par un.
 *
 * Indispensable quand on ramène sa propre musique : on choisit le dossier,
 * l'application descend dans les sous-dossiers et ajoute tout ce qui est
 * réellement lisible (audio, et vidéo dont on ne gardera que le son).
 *
 * Aucun fichier n'est copié ni déplacé : on mémorise uniquement son adresse.
 */
object FolderScanner {

    private val AUDIO_EXTENSIONS = listOf("mp3", "m4a", "aac", "flac", "ogg", "opus", "wav", "amr", "3gp")
    private val VIDEO_EXTENSIONS = listOf("mp4", "mkv", "webm", "m4v")

    suspend fun scan(context: Context, treeUri: Uri, maximum: Int = 400): List<LocalTrack> = withContext(Dispatchers.IO) {
        val found = mutableListOf<LocalTrack>()
        try {
            context.contentResolver.takePersistableUriPermission(
                treeUri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) { }
        val rootId = DocumentsContract.getTreeDocumentId(treeUri) ?: return@withContext emptyList()
        val pending = ArrayDeque<String>()
        pending.add(rootId)
        while (pending.isNotEmpty() && found.size < maximum) {
            val parentId = pending.removeFirst()
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            )
            val cursor = try {
                context.contentResolver.query(childrenUri, projection, null, null, null)
            } catch (_: Exception) { null }
            cursor?.use { c ->
                val idIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeIndex = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                while (c.moveToNext() && found.size < maximum) {
                    if (idIndex < 0 || nameIndex < 0 || mimeIndex < 0) break
                    val docId = c.getString(idIndex)
                    val name = c.getString(nameIndex) ?: continue
                    val mime = c.getString(mimeIndex) ?: continue
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        pending.add(docId)
                        continue
                    }
                    val lower = name.lowercase()
                    val isAudio = mime.startsWith("audio/") || AUDIO_EXTENSIONS.any { lower.endsWith(".$it") }
                    val isVideo = mime.startsWith("video/") || VIDEO_EXTENSIONS.any { lower.endsWith(".$it") }
                    if (!isAudio && !isVideo) continue
                    found += LocalTrack(DocumentsContract.buildDocumentUriUsingTree(treeUri, docId).toString(), name)
                }
            }
        }
        found
    }
}
