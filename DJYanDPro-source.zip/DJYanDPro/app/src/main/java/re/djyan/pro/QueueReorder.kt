package re.djyan.pro

/**
 * Réorganisation de la file restante, uniquement à partir de données RÉELLES :
 *  - le BPM mesuré par LocalBpmAnalyzer (décodage PCM réel), ou
 *  - le style attribué par l'utilisateur lui-même à ses fichiers.
 *
 * Ce module ne prétend pas analyser le style, l'énergie ou la tonalité d'un
 * morceau : il ne fait qu'ordonner des URI selon des règles simples, visibles et
 * testables. Les pistes dont le BPM n'a pas pu être établi ne sont jamais
 * inventées ni devinées : elles sont placées en fin de file.
 */
object QueueReorder {

    /**
     * Place en tête les pistes dont le BPM mesuré tombe dans la plage demandée,
     * triées par BPM croissant. Les autres suivent, également par BPM croissant.
     * Les pistes sans BPM mesuré finissent la file, sans être réordonnées entre elles.
     */
    fun byDanceRange(uris: List<String>, bpmByUri: Map<String, Int>, minBpm: Int, maxBpm: Int): List<String> {
        val low = minOf(minBpm, maxBpm)
        val high = maxOf(minBpm, maxBpm)
        fun bpmIn(uri: String): Int? = bpmByUri[uri]?.takeIf { it in low..high }
        val inRange = uris.mapNotNull { uri -> bpmIn(uri)?.let { uri to it } }.sortedBy { it.second }.map { it.first }
        val outOfRange = uris.filter { bpmByUri.containsKey(it) && bpmIn(it) == null }.sortedBy { bpmByUri[it]!! }
        val unknown = uris.filter { !bpmByUri.containsKey(it) }
        return inRange + outOfRange + unknown
    }

    /**
     * Place en tête les pistes auxquelles l'utilisateur a attribué le style demandé.
     * L'ordre relatif est conservé dans chaque groupe. Les pistes non étiquetées ne
     * passent jamais devant : elles restent à leur place dans le second groupe.
     */
    fun byStyle(uris: List<String>, styleByUri: Map<String, String>, wanted: String): List<String> {
        val matching = uris.filter { styleByUri[it] == wanted }
        val others = uris.filter { styleByUri[it] != wanted }
        return matching + others
    }
}
