package re.djyan.pro

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.media.AudioManager
import android.media.AudioFocusRequest
import android.media.audiofx.Equalizer
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.media3.common.PlaybackParameters
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlin.math.max
import kotlin.math.min

/**
 * Lecture de fichiers locaux avec deux lecteurs réels. Le second lecteur est
 * préchargé à volume nul ; pendant les six dernières secondes, les deux flux
 * audio authentiques sont superposés avec rampes de volume opposées.
 */
class YanDPlaybackService : MediaSessionService() {
    private lateinit var active: ExoPlayer
    private lateinit var standby: ExoPlayer
    private var session: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private var queue: List<MediaItem> = emptyList()
    private var bpmByUri: Map<String, Int> = emptyMap()
    private var activeIndex = 0
    private var transitionStarted = false
    private var crossfadeMs = 6_000L
    private var masterVolume = 1f
    /**
     * Ordre verrouillé : utilisé par les mixes préparés. L'utilisateur a choisi
     * l'ordre lui-même, l'adaptation automatique ne doit jamais le réordonner.
     */
    private var orderLocked = false
    private var titleByUri: Map<String, String> = emptyMap()
    // Niveau DJ 1 : calage de tempo. Niveau DJ 3 : échange des basses.
    private var beatmatchEnabled = false
    private var beatmatchMaxPercent = 8
    private var transitionEqEnabled = true
    private var alignBeatsEnabled = true
    private var phaseByUri: Map<String, Long> = emptyMap()
    private var transitionScheduled = false
    private var pendingTransition: Runnable? = null
    private var activeSpeed = 1f
    private var standbySpeed = 1f
    private val bassCutMillibels: Short = -1_200
    private var eqOutgoing: Equalizer? = null
    private var eqIncoming: Equalizer? = null
    private var activeGain = 1f
    private var standbyGain = 0f
    private lateinit var audioManager: AudioManager
    private lateinit var audioFocusRequest: AudioFocusRequest
    private var resumeAfterTransientFocusLoss = false
    private val preferences by lazy { getSharedPreferences("autopilot_preferences", MODE_PRIVATE) }
    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
                // Protection réelle lors du retrait d'un casque ou périphérique Bluetooth.
                active.pause()
                standby.pause()
            }
        }
    }

    private var tickerErrorReported = false
    private var transitionInfoReported = false

    private val ticker = object : Runnable {
        override fun run() {
            try {
                updateCrossfade()
            } catch (t: Throwable) {
                // Un plantage du ticker ferait tomber toute l'application : on l'isole
                // et on remonte la vraie raison à l'écran.
                t.printStackTrace()
                if (!tickerErrorReported) {
                    tickerErrorReported = true
                    sendBroadcast(Intent(ACTION_PLAYBACK_ERROR).setPackage(packageName)
                        .putExtra(EXTRA_TITLE, "Moteur de transition")
                        .putExtra(EXTRA_ERROR, "${t.javaClass.simpleName} : ${t.message}"))
                }
            }
            handler.postDelayed(this, 50L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(AudioManager::class.java)
        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setWillPauseWhenDucked(true)
            .setOnAudioFocusChangeListener { change -> handleAudioFocus(change) }
            .build()
        active = makePlayer(handleAudioFocus = false)
        standby = makePlayer(handleAudioFocus = false)
        observeErrors(active)
        observeErrors(standby)
        session = MediaSession.Builder(this, active)
            .setSessionActivity(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            .build()
        registerReceiver(noisyReceiver, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY))
        handler.post(ticker)
    }

    private fun makePlayer(handleAudioFocus: Boolean): ExoPlayer = ExoPlayer.Builder(this).build().apply {
        setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), handleAudioFocus)
    }

    private fun observeErrors(player: ExoPlayer) {
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                sendBroadcast(Intent(ACTION_PLAYBACK_ERROR).setPackage(packageName)
                    .putExtra(EXTRA_TITLE, player.currentMediaItem?.mediaMetadata?.title?.toString() ?: "Piste inconnue")
                    .putExtra(EXTRA_ERROR, error.errorCodeName))
                // Si la piste jouée échoue, l'autopilote tente la piste locale suivante.
                // Il n'essaie jamais de créer ou télécharger un contenu de remplacement.
                if (player === active) handler.post { advanceAfterActiveError() }
            }
        })
    }

    private fun handleAudioFocus(change: Int) {
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT, AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                resumeAfterTransientFocusLoss = active.isPlaying || standby.isPlaying
                active.pause(); standby.pause()
            }
            AudioManager.AUDIOFOCUS_LOSS -> { resumeAfterTransientFocusLoss = false; active.pause(); standby.pause() }
            AudioManager.AUDIOFOCUS_GAIN -> if (resumeAfterTransientFocusLoss) {
                active.play(); if (transitionStarted) standby.play(); resumeAfterTransientFocusLoss = false
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            // Android exige startForeground() dans les 5 secondes suivant
            // startForegroundService(), SINON il tue l'application. On l'appelle
            // donc tout de suite, avant même de savoir si la lecture va démarrer.
            if (intent?.action != ACTION_STOP) startForegroundNow("Préparation de la lecture…")
        when (intent?.action) {
            ACTION_PLAY_URI -> {
                val uri = intent.getStringExtra(EXTRA_URI) ?: return START_NOT_STICKY
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "Piste locale autorisée"
                startQueue(listOf(item(uri, title)))
            }
            ACTION_PLAY_QUEUE -> {
                crossfadeMs = intent.getLongExtra(EXTRA_CROSSFADE_MS, crossfadeMs).coerceIn(0L, 12_000L)
                masterVolume = intent.getFloatExtra(EXTRA_MASTER_VOLUME, masterVolume).coerceIn(0f, 1f)
                beatmatchEnabled = intent.getBooleanExtra(EXTRA_BEATMATCH, beatmatchEnabled)
                beatmatchMaxPercent = intent.getIntExtra(EXTRA_BEATMATCH_MAX, beatmatchMaxPercent).coerceIn(0, 50)
                transitionEqEnabled = intent.getBooleanExtra(EXTRA_TRANSITION_EQ, transitionEqEnabled)
                alignBeatsEnabled = intent.getBooleanExtra(EXTRA_ALIGN_BEATS, alignBeatsEnabled)
                val uris = intent.getStringArrayListExtra(EXTRA_URIS).orEmpty()
                val titles = intent.getStringArrayListExtra(EXTRA_TITLES).orEmpty()
                val bpms = intent.getIntegerArrayListExtra(EXTRA_BPMS).orEmpty()
                val phases = intent.getLongArrayExtra(EXTRA_BEAT_PHASES)
                orderLocked = intent.getBooleanExtra(EXTRA_LOCK_ORDER, false)
                titleByUri = uris.mapIndexedNotNull { index, uri -> titles.getOrNull(index)?.let { uri to it } }.toMap()
                bpmByUri = uris.mapIndexedNotNull { index, uri -> bpms.getOrNull(index)?.takeIf { it > 0 }?.let { uri to it } }.toMap()
                // Grille des temps : position du premier temps de chaque fichier, si elle a été mesurée.
                phaseByUri = if (phases == null) emptyMap()
                else uris.mapIndexedNotNull { index, uri -> phases.getOrNull(index)?.takeIf { it >= 0L }?.let { uri to it } }.toMap()
                startQueue(uris.mapIndexed { index, uri -> item(uri, titles.getOrElse(index) { "Piste locale autorisée" }) })
            }
            ACTION_ADAPT_CALMER -> adaptRemaining(moreFestive = false)
            ACTION_ADAPT_FESTIVE -> adaptRemaining(moreFestive = true)
            ACTION_MORE_DANCEABLE -> reorderByDanceRange(intent.getIntExtra(EXTRA_DANCE_MIN, 100), intent.getIntExtra(EXTRA_DANCE_MAX, 130))
            ACTION_STYLE_PRIORITY -> reorderByStyle(intent)
            ACTION_LIKE_URI -> intent.getStringExtra(EXTRA_URI)?.let { uri ->
                // Aimer annule un rejet précédent : le titre redevient jouable.
                preferences.edit().putStringSet("rejected_uris", preferences.getStringSet("rejected_uris", emptySet()).orEmpty() - uri).apply()
            }
            ACTION_SET_CROSSFADE -> crossfadeMs = intent.getLongExtra(EXTRA_CROSSFADE_MS, crossfadeMs).coerceIn(0L, 12_000L)
            ACTION_SET_MASTER_VOLUME -> { masterVolume = intent.getFloatExtra(EXTRA_MASTER_VOLUME, masterVolume).coerceIn(0f, 1f); applyVolumes(activeGain, standbyGain) }
            ACTION_PAUSE -> { active.pause(); standby.pause() }
            ACTION_RESUME -> { active.play(); if (transitionStarted) standby.play() }
            ACTION_SKIP_NEXT -> skipNext()
            ACTION_REJECT_CURRENT -> rejectCurrentAndSkip()
            ACTION_CLEAR_REJECTS -> {
                // Oublie les fichiers écartés par "PAS CELUI-LÀ" pour qu'un mix
                // préparé puisse être rejoué intégralement.
                preferences.edit().remove("rejected_uris").apply()
            }
            ACTION_STOP -> { stopPlayback(); stopSelf() }
        }
        } catch (t: Throwable) {
            t.printStackTrace()
            sendBroadcast(Intent(ACTION_PLAYBACK_ERROR).setPackage(packageName)
                .putExtra(EXTRA_TITLE, "Commande")
                .putExtra(EXTRA_ERROR, "${t.javaClass.simpleName} : ${t.message}"))
        }
        return START_NOT_STICKY
    }

    private fun item(uri: String, title: String) = MediaItem.Builder().setUri(uri).setMediaMetadata(MediaMetadata.Builder().setTitle(title).build()).build()

    private fun startQueue(items: List<MediaItem>) {
        val rejected = preferences.getStringSet("rejected_uris", emptySet()).orEmpty()
        val eligible = items.filter { it.localConfiguration?.uri.toString() !in rejected }
        if (eligible.isEmpty()) {
            sendBroadcast(Intent(ACTION_PLAYBACK_ERROR).setPackage(packageName).putExtra(EXTRA_TITLE, "Autopilote").putExtra(EXTRA_ERROR, "NO_ELIGIBLE_LOCAL_TRACK"))
            return
        }
        stopPlayback()
        if (audioManager.requestAudioFocus(audioFocusRequest) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
            sendBroadcast(Intent(ACTION_PLAYBACK_ERROR).setPackage(packageName).putExtra(EXTRA_TITLE, "Lecture").putExtra(EXTRA_ERROR, "AUDIO_FOCUS_DENIED"))
            return
        }
        queue = eligible
        playIndex(0)
    }

    private fun playIndex(index: Int) {
        active.stop(); active.clearMediaItems()
        standby.stop(); standby.clearMediaItems()
        activeIndex = index
        transitionStarted = false
        transitionInfoReported = false
        cancelPendingTransition()
        releaseTransitionEq()
        activeSpeed = 1f
        standbySpeed = 1f
        active.setMediaItem(queue[activeIndex])
        active.setPlaybackParameters(PlaybackParameters(1f, 1f))
        applyVolumes(1f, 0f)
        active.prepare()
        active.play()
        broadcastCurrentTrack()
        preloadNext()
    }

    /**
     * Adapte les pistes restantes exclusivement selon leurs BPM réellement calculés.
     * Sur un mix préparé, l'ordre est verrouillé : cette commande ne fait RIEN,
     * plutôt que de réorganiser ce que l'utilisateur a composé lui-même.
     */
    private fun adaptRemaining(moreFestive: Boolean) {
        if (orderLocked) return
        if (transitionStarted || activeIndex >= queue.lastIndex) return
        val passed = queue.take(activeIndex + 1)
        val remaining = queue.drop(activeIndex + 1)
        val known = remaining.filter { bpmByUri[it.localConfiguration?.uri.toString()] != null }
            .sortedBy { bpmByUri[it.localConfiguration?.uri.toString()]!! }
        val unknown = remaining.filter { bpmByUri[it.localConfiguration?.uri.toString()] == null }
        queue = passed + (if (moreFestive) known.reversed() else known) + unknown
        preloadNext()
    }

    /**
     * PLUS DANSANT : place en tête les pistes restantes dont le BPM RÉELLEMENT
     * mesuré tombe dans la plage choisie par l'utilisateur. Ce n'est pas une
     * analyse de style : seulement un tri de tempo.
     */
    private fun reorderByDanceRange(minBpm: Int, maxBpm: Int) {
        if (orderLocked || queue.isEmpty() || transitionStarted) return
        val passed = queue.take(activeIndex + 1).map(::uriOf)
        val remaining = queue.drop(activeIndex + 1).map(::uriOf)
        queue = buildQueue(passed + QueueReorder.byDanceRange(remaining, bpmByUri, minBpm, maxBpm))
        preloadNext()
    }

    /**
     * CHANGER DE STYLE : place en tête les pistes restantes auxquelles
     * l'utilisateur a lui-même attribué le style demandé. L'application ne
     * reconnaît aucun style à l'écoute.
     */
    private fun reorderByStyle(intent: Intent) {
        if (orderLocked || queue.isEmpty() || transitionStarted) return
        val wanted = intent.getStringExtra(EXTRA_STYLE)?.takeIf { it.isNotBlank() } ?: return
        val uris = intent.getStringArrayListExtra(EXTRA_STYLE_URIS).orEmpty()
        val styles = intent.getStringArrayListExtra(EXTRA_STYLES).orEmpty()
        val styleByUri = uris.mapIndexedNotNull { index, uri -> styles.getOrNull(index)?.takeIf { it.isNotBlank() }?.let { uri to it } }.toMap()
        val passed = queue.take(activeIndex + 1).map(::uriOf)
        val remaining = queue.drop(activeIndex + 1).map(::uriOf)
        queue = buildQueue(passed + QueueReorder.byStyle(remaining, styleByUri, wanted))
        preloadNext()
    }

    /**
     * NIVEAU DJ 1 — calage de tempo.
     * La piste entrante voit sa vitesse ajustée pour rejoindre le tempo de la piste
     * en cours, hauteur conservée. Uniquement avec des BPM RÉELLEMENT mesurés :
     * sans BPM, aucune vitesse n'est appliquée (1.0), jamais devinée.
     */
    private fun applyBeatmatchToIncoming() {
        if (!beatmatchEnabled) return
        val currentUri = active.currentMediaItem?.localConfiguration?.uri.toString()
        val incomingUri = standby.currentMediaItem?.localConfiguration?.uri.toString()
        val currentNatural = bpmByUri[currentUri] ?: return
        val incomingNatural = bpmByUri[incomingUri] ?: return
        val currentEffective = TempoMatcher.effectiveBpm(currentNatural, activeSpeed)
        standbySpeed = TempoMatcher.speedFor(currentEffective, incomingNatural, beatmatchMaxPercent)
        standby.setPlaybackParameters(PlaybackParameters(standbySpeed, 1f))
    }

    /**
     * NIVEAU DJ 3 — échange des basses.
     * Les basses du morceau sortant s'effacent pendant que celles du morceau
     * entrant s'ouvrent. Vrai réglage d'égaliseur système, pas un filtre simulé.
     * Si l'appareil refuse l'effet, les égaliseurs restent nuls et rien n'est annoncé.
     */
    private fun attachTransitionEq() {
        if (!transitionEqEnabled) return
        releaseTransitionEq()
        eqOutgoing = TransitionEq.create(active.audioSessionId)
        eqIncoming = TransitionEq.create(standby.audioSessionId)
    }

    private fun rampTransitionEq(progress: Float) {
        if (eqOutgoing == null && eqIncoming == null) return
        val fadeOut = (bassCutMillibels * progress).toInt().toShort()
        val fadeIn = (bassCutMillibels * (1f - progress)).toInt().toShort()
        TransitionEq.setBass(eqOutgoing, fadeOut)
        TransitionEq.setBass(eqIncoming, fadeIn)
    }

    private fun releaseTransitionEq() {
        TransitionEq.release(eqOutgoing)
        TransitionEq.release(eqIncoming)
        eqOutgoing = null
        eqIncoming = null
    }

    /** Crée le canal de notification (obligatoire depuis Android 8). */
    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Lecture DJ Yan-D", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Contrôle de la lecture en cours"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): android.app.Notification {
        val openApp = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("DJ Yan-D PRO")
            .setContentText(text)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    /**
     * Passe le service en avant-plan IMMÉDIATEMENT. Sans cet appel, Android
     * déclenche ForegroundServiceDidNotStartInTimeException et tue l'application.
     */
    private fun startForegroundNow(text: String) {
        try {
            ensureChannel()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, buildNotification(text), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIFICATION_ID, buildNotification(text))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateNotification(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(text))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /** Explique à l'écran ce que fait réellement le moteur de transition. */
    private fun reportTransitionInfo(info: String) {
        if (transitionInfoReported) return
        transitionInfoReported = true
        sendBroadcast(Intent(ACTION_TRANSITION_INFO).setPackage(packageName).putExtra(EXTRA_INFO, info))
    }

    private fun uriOf(item: MediaItem): String = item.localConfiguration?.uri.toString()
    private fun buildQueue(uris: List<String>): List<MediaItem> = uris.map { item(it, titleByUri[it] ?: "Piste locale autorisée") }

    /** Annonce la piste réellement en cours, pour que l'écran affiche la vérité. */
    private fun broadcastCurrentTrack() {
        val uri = active.currentMediaItem?.localConfiguration?.uri?.toString() ?: return
        val title = active.currentMediaItem?.mediaMetadata?.title?.toString() ?: "Piste locale autorisée"
        sendBroadcast(Intent(ACTION_TRACK_CHANGED).setPackage(packageName).putExtra(EXTRA_URI, uri).putExtra(EXTRA_TITLE, title))
        updateNotification(title)
    }

    /** Mémorise localement le refus, puis avance vers un vrai fichier restant. */
    private fun rejectCurrentAndSkip() {
        active.currentMediaItem?.localConfiguration?.uri?.toString()?.let { uri ->
            preferences.edit().putStringSet("rejected_uris", preferences.getStringSet("rejected_uris", emptySet()).orEmpty() + uri).apply()
        }
        skipNext()
    }

    /** Commande directe : avance vers le prochain fichier local réellement présent. */
    private fun skipNext() {
        val nextIndex = activeIndex + 1
        if (nextIndex <= queue.lastIndex) playIndex(nextIndex)
    }

    /** Remplacement autonome par un vrai fichier local suivant uniquement. */
    private fun advanceAfterActiveError() {
        if (transitionStarted) return // La piste de réserve est déjà en cours ; elle continue sans artifice.
        val nextIndex = activeIndex + 1
        if (nextIndex <= queue.lastIndex) playIndex(nextIndex) else { stopPlayback(); stopSelf() }
    }

    private fun preloadNext() {
        val next = queue.getOrNull(activeIndex + 1)
        standby.stop()
        standby.clearMediaItems()
        if (next != null) {
            standby.setMediaItem(next)
            standbySpeed = 1f
            standby.setPlaybackParameters(PlaybackParameters(1f, 1f))
            standbyGain = 0f
            standby.volume = 0f
            standby.prepare()
        }
    }

    private fun updateCrossfade() {
        if (queue.isEmpty()) return
        if (transitionStarted) { rampCrossfade(); return }
        if (active.playbackState == Player.STATE_ENDED && activeIndex < queue.lastIndex) { advanceWithoutCrossfade(); return }
        if (activeIndex >= queue.lastIndex) return
        if (crossfadeMs <= 0L) { reportTransitionInfo("Fondu réglé sur 0 s : passage direct d’un morceau à l’autre."); return }
        val duration = active.duration
        if (duration == C.TIME_UNSET) { reportTransitionInfo("Durée du morceau inconnue : le fondu ne peut pas être déclenché à l’avance."); return }
        if (duration <= crossfadeMs) { reportTransitionInfo("Morceau trop court pour un fondu de ${crossfadeMs / 1000} s."); return }
        if (standby.playbackState != Player.STATE_READY) { reportTransitionInfo("Morceau suivant pas encore prêt en mémoire : le fondu attendra le dernier moment."); return }
        val remaining = duration - active.currentPosition
        if (remaining > crossfadeMs) return
        if (transitionScheduled) return

        // NIVEAU DJ 2 : si on connaît la grille des temps, on programme le départ
        // du morceau entrant AU MOMENT EXACT du prochain temps, au lieu de le
        // lancer n'importe quand dans la mesure.
        val wait = beatAlignmentDelay(remaining)
        if (wait > 0L) {
            transitionScheduled = true
            val runnable = Runnable {
                pendingTransition = null
                if (!transitionStarted && queue.isNotEmpty() && active.playbackState != Player.STATE_ENDED) startTransition(aligned = true)
            }
            pendingTransition = runnable
            handler.postDelayed(runnable, wait)
            return
        }
        startTransition(aligned = false)
    }

    /** Temps à attendre avant le prochain temps, ou 0 si on ne peut pas aligner. */
    private fun beatAlignmentDelay(remainingMs: Long): Long {
        if (!alignBeatsEnabled) return 0L
        val uri = active.currentMediaItem?.localConfiguration?.uri.toString()
        val bpm = bpmByUri[uri] ?: return 0L
        val period = BeatGrid.periodMs(bpm)
        if (period <= 0L) return 0L
        val wait = BeatGrid.delayToNextBeat(active.currentPosition, phaseByUri[uri] ?: 0L, period)
        // On n'attend que s'il reste assez de musique derrière pour que le fondu serve à quelque chose.
        if (wait <= 0L || remainingMs - wait < period) return 0L
        return wait
    }

    private fun startTransition(aligned: Boolean) {
        transitionScheduled = false
        transitionStarted = true
        val seconds = crossfadeMs / 1000
        reportTransitionInfo(
            if (aligned) "Fondu calé sur le temps : $seconds s de mélange, les deux morceaux battent ensemble."
            else "Fondu en cours : $seconds s de mélange."
        )
        applyVolumes(1f, 0f)
        applyBeatmatchToIncoming()
        attachTransitionEq()
        alignIncomingOnItsFirstBeat()
        standby.play()
        rampCrossfade()
    }

    /** Le morceau entrant démarre sur SON premier temps, pas dans un silence. */
    private fun alignIncomingOnItsFirstBeat() {
        if (!alignBeatsEnabled) return
        val uri = standby.currentMediaItem?.localConfiguration?.uri.toString()
        val phase = phaseByUri[uri] ?: return
        if (phase <= 0L || phase > 30_000L) return
        try { standby.seekTo(phase) } catch (e: Exception) { e.printStackTrace() }
    }

    private fun cancelPendingTransition() {
        pendingTransition?.let { handler.removeCallbacks(it) }
        pendingTransition = null
        transitionScheduled = false
    }

    private fun rampCrossfade() {
        val duration = active.duration
        val remaining = duration - active.currentPosition
        val progress = (1f - remaining.toFloat() / crossfadeMs).coerceIn(0f, 1f)
        // Rampe à puissance constante (cosinus/sinus) : contrairement à une rampe
        // linéaire, le volume perçu ne s'écrase pas au milieu du fondu.
        val angle = progress * (kotlin.math.PI.toFloat() / 2f)
        applyVolumes(kotlin.math.cos(angle), kotlin.math.sin(angle))
        rampTransitionEq(progress)
        if (progress >= 1f || active.playbackState == Player.STATE_ENDED) completeCrossfade()
    }

    private fun completeCrossfade() {
        releaseTransitionEq()
        active.stop()
        val previous = active
        active = standby
        standby = previous
        // Le morceau entrant conserve la vitesse de calage : le tempo de la soirée
        // reste là où il a été verrouillé, exactement comme un DJ qui laisse le pitch.
        activeSpeed = standbySpeed
        activeIndex++
        transitionStarted = false
        applyVolumes(1f, 0f)
        session?.setPlayer(active)
        broadcastCurrentTrack()
        preloadNext()
    }

    /** Cas court / format sans durée fiable : passage sans fondu, jamais avec son artificiel. */
    private fun advanceWithoutCrossfade() {
        cancelPendingTransition()
        applyBeatmatchToIncoming()
        active.stop()
        val previous = active
        active = standby
        standby = previous
        activeSpeed = standbySpeed
        activeIndex++
        applyVolumes(1f, 0f)
        active.play()
        session?.setPlayer(active)
        broadcastCurrentTrack()
        preloadNext()
    }

    private fun applyVolumes(activeLevel: Float, standbyLevel: Float) {
        activeGain = activeLevel.coerceIn(0f, 1f)
        standbyGain = standbyLevel.coerceIn(0f, 1f)
        active.volume = activeGain * masterVolume
        standby.volume = standbyGain * masterVolume
    }

    private fun stopPlayback() {
        cancelPendingTransition()
        releaseTransitionEq()
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(Service.STOP_FOREGROUND_REMOVE)
            else @Suppress("DEPRECATION") stopForeground(true)
            getSystemService(NotificationManager::class.java).cancel(NOTIFICATION_ID)
        }
        activeSpeed = 1f
        standbySpeed = 1f
        active.stop(); active.clearMediaItems()
        standby.stop(); standby.clearMediaItems()
        audioManager.abandonAudioFocusRequest(audioFocusRequest)
        queue = emptyList(); activeIndex = 0; transitionStarted = false
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        releaseTransitionEq()
        handler.removeCallbacksAndMessages(null)
        unregisterReceiver(noisyReceiver)
        session?.release()
        active.release()
        standby.release()
        super.onDestroy()
    }

    companion object {
        const val NOTIFICATION_ID = 4271
        const val CHANNEL_ID = "djyand_lecture"
        const val ACTION_PLAY_URI = "re.djyan.pro.PLAY_URI"
        const val ACTION_PLAY_QUEUE = "re.djyan.pro.PLAY_QUEUE"
        const val EXTRA_URIS = "uris"
        const val EXTRA_TITLES = "titles"
        const val EXTRA_BPMS = "bpms"
        const val EXTRA_CROSSFADE_MS = "crossfade_ms"
        const val EXTRA_MASTER_VOLUME = "master_volume"
        const val EXTRA_LOCK_ORDER = "lock_order"
        const val EXTRA_BEATMATCH = "beatmatch"
        const val EXTRA_BEATMATCH_MAX = "beatmatch_max"
        const val EXTRA_TRANSITION_EQ = "transition_eq"
        const val EXTRA_ALIGN_BEATS = "align_beats"
        const val EXTRA_BEAT_PHASES = "beat_phases"
        const val ACTION_PAUSE = "re.djyan.pro.PAUSE"
        const val ACTION_RESUME = "re.djyan.pro.RESUME"
        const val ACTION_SKIP_NEXT = "re.djyan.pro.SKIP_NEXT"
        const val ACTION_REJECT_CURRENT = "re.djyan.pro.REJECT_CURRENT"
        const val ACTION_CLEAR_REJECTS = "re.djyan.pro.CLEAR_REJECTS"
        const val ACTION_ADAPT_CALMER = "re.djyan.pro.ADAPT_CALMER"
        const val ACTION_ADAPT_FESTIVE = "re.djyan.pro.ADAPT_FESTIVE"
        const val ACTION_MORE_DANCEABLE = "re.djyan.pro.MORE_DANCEABLE"
        const val ACTION_STYLE_PRIORITY = "re.djyan.pro.STYLE_PRIORITY"
        const val ACTION_LIKE_URI = "re.djyan.pro.LIKE_URI"
        const val ACTION_TRACK_CHANGED = "re.djyan.pro.TRACK_CHANGED"
        const val ACTION_TRANSITION_INFO = "re.djyan.pro.TRANSITION_INFO"
        const val EXTRA_INFO = "info"
        const val EXTRA_DANCE_MIN = "dance_min"
        const val EXTRA_DANCE_MAX = "dance_max"
        const val EXTRA_STYLE = "style"
        const val EXTRA_STYLE_URIS = "style_uris"
        const val EXTRA_STYLES = "styles"
        const val ACTION_SET_CROSSFADE = "re.djyan.pro.SET_CROSSFADE"
        const val ACTION_SET_MASTER_VOLUME = "re.djyan.pro.SET_MASTER_VOLUME"
        const val ACTION_STOP = "re.djyan.pro.STOP"
        const val ACTION_PLAYBACK_ERROR = "re.djyan.pro.PLAYBACK_ERROR"
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
        const val EXTRA_ERROR = "error"
    }
}
