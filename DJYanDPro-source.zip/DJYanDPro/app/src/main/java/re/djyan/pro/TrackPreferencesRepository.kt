package re.djyan.pro

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Préférences attribuées par l'utilisateur à SES fichiers.
 *
 * Rien n'est déduit automatiquement : l'application ne reconnaît ni le style ni
 * l'ambiance d'un morceau. « J'aime » est un choix de l'utilisateur, « style » est
 * une étiquette qu'il pose lui-même. Aucune recommandation n'est générée à partir
 * de ces données au-delà d'un simple ordre de lecture.
 */
data class TrackPreferences(
    val likedUris: Set<String> = emptySet(),
    val styleByUri: Map<String, String> = emptyMap()
)

internal object TrackPreferencesCodec {
    private const val FIELD = "|"
    private const val ENTRY = "\u001F"
    private const val PART = "\u0002"

    fun encode(prefs: TrackPreferences): String = listOf(
        enc(prefs.likedUris.joinToString(ENTRY) { enc(it) }),
        enc(prefs.styleByUri.entries.joinToString(ENTRY) { enc(it.key) + PART + enc(it.value) })
    ).joinToString(FIELD)

    fun decode(line: String): TrackPreferences? = try {
        val parts = line.split(FIELD)
        if (parts.size != 2) null else TrackPreferences(decodeSet(dec(parts[0])), decodeMap(dec(parts[1])))
    } catch (_: Exception) { null }

    private fun decodeSet(blob: String): Set<String> =
        blob.split(ENTRY).filter { it.isNotBlank() }.map { dec(it) }.toSet()

    private fun decodeMap(blob: String): Map<String, String> =
        blob.split(ENTRY).filter { it.isNotBlank() }.mapNotNull { raw ->
            val p = raw.split(PART, limit = 2)
            if (p.size != 2) null else dec(p[0]) to dec(p[1])
        }.toMap()

    private fun enc(value: String): String = Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP)
    private fun dec(value: String): String = String(Base64.decode(value, Base64.URL_SAFE), Charsets.UTF_8)
}

private val TRACK_PREFERENCES = stringPreferencesKey("track_preferences_v1")

class TrackPreferencesRepository(private val context: Context) {

    val preferences: Flow<TrackPreferences> = context.sourceStore.data.map { prefs ->
        prefs[TRACK_PREFERENCES]?.let { TrackPreferencesCodec.decode(it) } ?: TrackPreferences()
    }

    private suspend fun update(transform: (TrackPreferences) -> TrackPreferences) {
        context.sourceStore.edit { store ->
            val current = store[TRACK_PREFERENCES]?.let { TrackPreferencesCodec.decode(it) } ?: TrackPreferences()
            store[TRACK_PREFERENCES] = TrackPreferencesCodec.encode(transform(current))
        }
    }

    suspend fun replaceAll(prefs: TrackPreferences) {
        context.sourceStore.edit { store -> store[TRACK_PREFERENCES] = TrackPreferencesCodec.encode(prefs) }
    }

    suspend fun toggleLike(uri: String) = update { current ->
        current.copy(likedUris = if (uri in current.likedUris) current.likedUris - uri else current.likedUris + uri)
    }

    suspend fun setStyle(uri: String, style: String) = update { current ->
        current.copy(styleByUri = current.styleByUri + (uri to style))
    }

    suspend fun clearStyle(uri: String) = update { current ->
        current.copy(styleByUri = current.styleByUri - uri)
    }
}
