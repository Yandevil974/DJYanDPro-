package re.djyan.pro

/**
 * Calage de tempo (beatmatch) — partie calculable et testable.
 *
 * Règle : la piste ENTRANTE est ralentie ou accélérée pour que son tempo
 * rejoigne celui de la piste EN COURS. La hauteur (la voix) est conservée par le
 * lecteur (time-stretching), ce n'est pas un simple changement de vitesse.
 *
 * Une limite est appliquée : au-delà d'un certain écart, accélérer déforme trop
 * le morceau. La vitesse est alors bloquée à la limite et le calage est partiel —
 * jamais silencieusement parfait.
 */
object TempoMatcher {

    /**
     * @param currentBpm tempo effectif de la piste en cours (déjà mesuré)
     * @param nextBpm tempo naturel de la piste entrante (déjà mesuré)
     * @param maxPercent écart maximal accepté, en pourcentage (8 % par défaut)
     * @return la vitesse à appliquer au lecteur de la piste entrante
     */
    fun speedFor(currentBpm: Int, nextBpm: Int, maxPercent: Int): Float {
        if (currentBpm <= 0 || nextBpm <= 0) return 1f
        val ratio = currentBpm.toFloat() / nextBpm.toFloat()
        val tolerance = maxPercent.coerceIn(0, 50) / 100f
        return ratio.coerceIn(1f - tolerance, 1f + tolerance)
    }

    /** Tempo réellement entendu quand un morceau tourne à une vitesse donnée. */
    fun effectiveBpm(naturalBpm: Int, speed: Float): Int = if (naturalBpm <= 0) 0 else (naturalBpm * speed).toInt()

    /** Vrai si le calage a pu être fait complètement, faux s'il a été bridé. */
    fun isExact(currentBpm: Int, nextBpm: Int, maxPercent: Int): Boolean {
        if (currentBpm <= 0 || nextBpm <= 0) return false
        val tolerance = maxPercent.coerceIn(0, 50) / 100f
        val ratio = currentBpm.toFloat() / nextBpm.toFloat()
        return ratio in (1f - tolerance)..(1f + tolerance)
    }
}

/**
 * NIVEAU DJ 2 — grille des temps et alignement.
 *
 * Une fois qu'on connaît la cadence (BPM) et la position du premier temps, on
 * peut calculer EXACTEMENT quand tombe le prochain temps, et faire démarrer le
 * morceauentrant sur ce temps-là. C'est la différence entre « deux morceaux qui
 * se chevauchent » et « deux morceaux qui battent ensemble ».
 *
 * Ces calculs sont purs et testables.
 */
object BeatGrid {

    /** Durée d'un temps, en millisecondes. 0 si le tempo est inconnu. */
    fun periodMs(bpm: Int): Long = if (bpm <= 0) 0L else (60_000.0 / bpm).toLong()

    /** Position dans le temps courant (0 = on vient de frapper un temps). */
    fun phaseAt(positionMs: Long, firstBeatMs: Long, periodMs: Long): Long {
        if (periodMs <= 0L) return 0L
        val raw = (positionMs - firstBeatMs) % periodMs
        return if (raw < 0) raw + periodMs else raw
    }

    /** Temps restant avant le prochain temps, en millisecondes. */
    fun delayToNextBeat(positionMs: Long, firstBeatMs: Long, periodMs: Long): Long {
        if (periodMs <= 0L) return 0L
        val phase = phaseAt(positionMs, firstBeatMs, periodMs)
        val wait = periodMs - phase
        return if (wait == periodMs) 0L else wait
    }
}
