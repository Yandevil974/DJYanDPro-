package re.djyan.pro

/**
 * Calage de tempo (beatmatch) — partie calculable et testable.
 *
 * Règle : la piste ENTRANTE est ralentie ou accélérée pour que son tempo
 * rejoigne celui de la piste EN COURS. La hauteur (la voix) est conservée par le
 * lecteur (time-stretching), ce n'est pas un simple changement de vitesse.
 *
 * Une limite est appliquée : au-delà d'un certain écart, accélérer déforme trop
 * le morceau. La vitesse est alors bloquée à la limite et le calage est partiel —
 * jamais silencieusement parfait.
 */
object TempoMatcher {

    /**
     * @param currentBpm tempo effectif de la piste en cours (déjà mesuré)
     * @param nextBpm tempo naturel de la piste entrante (déjà mesuré)
     * @param maxPercent écart maximal accepté, en pourcentage (8 % par défaut)
     * @return la vitesse à appliquer au lecteur de la piste entrante
     */
    fun speedFor(currentBpm: Int, nextBpm: Int, maxPercent: Int): Float {
        if (currentBpm <= 0 || nextBpm <= 0) return 1f
        val ratio = currentBpm.toFloat() / nextBpm.toFloat()
        val tolerance = maxPercent.coerceIn(0, 50) / 100f
        return ratio.coerceIn(1f - tolerance, 1f + tolerance)
    }

    /** Tempo réellement entendu quand un morceau tourne à une vitesse donnée. */
    fun effectiveBpm(naturalBpm: Int, speed: Float): Int = if (naturalBpm <= 0) 0 else (naturalBpm * speed).toInt()

    /** Vrai si le calage a pu être fait complètement, faux s'il a été bridé. */
    fun isExact(currentBpm: Int, nextBpm: Int, maxPercent: Int): Boolean {
        if (currentBpm <= 0 || nextBpm <= 0) return false
        val tolerance = maxPercent.coerceIn(0, 50) / 100f
        val ratio = currentBpm.toFloat() / nextBpm.toFloat()
        return ratio in (1f - tolerance)..(1f + tolerance)
    }
}
