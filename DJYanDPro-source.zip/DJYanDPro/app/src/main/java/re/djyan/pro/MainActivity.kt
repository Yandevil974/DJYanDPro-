package re.djyan.pro

@file:OptIn(ExperimentalMaterial3Api::class)

import androidx.compose.material3.ExperimentalMaterial3Api
import android.os.Bundle
import android.app.DownloadManager
import android.os.Environment
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.Preferences
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

private val Night = Color(0xFF080A12)
private val Surface = Color(0xFF121625)
private val Cyan = Color(0xFF75E6FF)
private val Violet = Color(0xFFAB7CFF)

/** Styles proposés à l'utilisateur. L'application ne les détecte pas : il les attribue lui-même. */
private val AVAILABLE_STYLES = listOf("Ragga", "Dancehall", "Reggae", "Zouk Love", "Kompa", "R&B", "Afrobeat", "Amapiano", "Séga", "Maloya", "House", "Années 80")

enum class SourceState { NOT_CONFIGURED, NOT_AVAILABLE }
data class MusicSource(val name: String, val state: SourceState, val detail: String)
data class LocalTrack(val uri: String, val title: String)
val Context.sourceStore by preferencesDataStore("music_source")
private val LOCAL_URI = stringPreferencesKey("local_uri")
private val LOCAL_TITLE = stringPreferencesKey("local_title")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YanDTheme { YanDApp() } }
    }
}

@Composable private fun YanDTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Violet, background = Night, surface = Surface,
        onPrimary = Color(0xFF001F27), onBackground = Color(0xFFF4F6FF), onSurface = Color(0xFFF4F6FF)
    ), content = content)
}

@Composable private fun YanDApp() {
    val nav = rememberNavController()
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val localTracks by LocalLibraryRepository(context).tracks.catch { emit(emptyList()) }.collectAsState(initial = emptyList())
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val crossfadeSeconds by PlaybackSettingsRepository(context).crossfadeSeconds.collectAsState(initial = 6)
    val masterVolumePercent by PlaybackSettingsRepository(context).masterVolumePercent.collectAsState(initial = 100)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val tracks = uris.map { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) { }
                val title = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "Piste locale autorisée"
                LocalTrack(uri.toString(), title)
            }
            scope.launch { LocalLibraryRepository(context).replace(tracks) }
        }
    }
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(nav, localTracks) }
        composable("party") { PartyBuilder(nav, context) }
        composable("sources") { SourcesScreen(nav, localTracks, crossfadeSeconds, masterVolumePercent, { picker.launch(arrayOf("audio/*")) }, context) }
        composable("mixes") { PreparedMixScreen(nav, context) }
        composable("live") { LiveScreen(nav, context, localTracks) }
        composable("jamendo") { JamendoScreen(nav, context) }
        composable("settings") { SettingsScreen(nav, context) }
        composable("events") { PartiesScreen(nav, context) }
        composable("search") { InfoScreen(nav, "Rechercher une musique", "La recherche n’est pas encore active : aucune source de catalogue autorisée n’est configurée. Aucun résultat fictif n’est affiché.") }
        composable("news") { InfoScreen(nav, "Nouveautés", "Aucun catalogue connecté. Les nouveautés et tendances ne seront affichées que depuis une source officiellement intégrée.") }
    }
}
@Composable private fun Page(nav: NavHostController, title: String, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(containerColor = Night, topBar = {
        TopAppBar(title = { Text(title, fontWeight = FontWeight.Black) }, navigationIcon = {
            Text("‹", modifier = Modifier.padding(horizontal = 20.dp).clickable { nav.popBackStack() }, style = MaterialTheme.typography.headlineMedium, color = Cyan)
        }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Night))
    }) { padding -> Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), content = content) }
}

@Composable private fun HomeScreen(nav: NavHostController, localTracks: List<LocalTrack>) {
    Scaffold(containerColor = Night) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text("🎧 DJ AI PRO", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black) }
            item { Text("JE CHOISIS MA SOIRÉE. Yan-D s’occupe du reste.", color = Color(0xFFBFC6DD)) }
            item { Button(onClick = { nav.navigate("party") }, modifier = Modifier.fillMaxWidth().height(64.dp)) { Text("🎉  CRÉER MA SOIRÉE", fontWeight = FontWeight.Black) } }
            item { HomeButton("🎚️", "MIX PRÉPARÉ", "Tes fichiers, dans l’ordre que tu choisis", { nav.navigate("mixes") }) }
            item { HomeButton("🎛️", "COMMANDES LIVE", "J’aime · Dansant · Changer de style", { nav.navigate("live") }) }
            item { HomeButton("🌍", "CATALOGUE JAMENDO", "Musique libre de droits en ligne — en plus", { nav.navigate("jamendo") }) }
            item { StatusCard(localTracks) }
            item { HomeButton("🎵", "RECHERCHER UNE MUSIQUE", "Aucun catalogue simulé", { nav.navigate("search") }) }
            item { HomeButton("💾", "MES SOIRÉES", "Sauvegardes locales — phase 1B", { nav.navigate("events") }) }
            item { HomeButton("🔥", "NOUVEAUTÉS", "Dépend d’une source réellement connectée", { nav.navigate("news") }) }
            item { HomeButton("🎧", "SOURCES MUSICALES", "État réel des intégrations", { nav.navigate("sources") }) }
            item { HomeButton("⚙️", "PARAMÈTRES", "Audio, confidentialité et diagnostics", { nav.navigate("settings") }) }
        }
    }
}

@Composable private fun StatusCard(localTracks: List<LocalTrack>) = Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
    Column(Modifier.padding(16.dp)) {
        Text("ÉTAT DU MOTEUR", color = Cyan, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        if (localTracks.isEmpty()) {
            Text("Aucune source audio compatible configurée")
            Text("La lecture et le mode DJ restent désactivés. Aucun son ni morceau n’est simulé.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
        } else {
            Text("Bibliothèque locale autorisée prête — ${localTracks.size} piste(s)")
            Text("Lecture de fichier réel disponible. Mix et analyse restent volontairement désactivés.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
        }
    }
}

@Composable private fun HomeButton(icon: String, label: String, sub: String, click: () -> Unit) = Card(
    modifier = Modifier.fillMaxWidth().clickable(onClick = click), colors = CardDefaults.cardColors(containerColor = Surface)
) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(icon, style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.width(14.dp)); Column { Text(label, fontWeight = FontWeight.Bold); Text(sub, style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD)) } } }

@Composable private fun SourcesScreen(nav: NavHostController, tracks: List<LocalTrack>, crossfadeSeconds: Int, masterVolumePercent: Int, pickAudio: () -> Unit, context: Context) = Page(nav, "Sources musicales") {
    val scope = rememberCoroutineScope()
    var sliderSeconds by remember(crossfadeSeconds) { mutableFloatStateOf(crossfadeSeconds.toFloat()) }
    var volumePercent by remember(masterVolumePercent) { mutableFloatStateOf(masterVolumePercent.toFloat()) }
    var playbackError by remember { mutableStateOf<String?>(null) }
    val technicalInfo = remember { mutableStateMapOf<String, String>() }
    val inspectionErrors = remember { mutableStateMapOf<String, String>() }
    val bpmInfo = remember { mutableStateMapOf<String, String>() }
    val bpmValues = remember { mutableStateMapOf<String, Int>() }
    // Les BPM mesurés sont relus depuis le stockage : ils ne sont plus perdus en quittant l'écran.
    LaunchedEffect(Unit) { LocalBpmRepository(context).bpmByUri.collect { map -> bpmValues.clear(); bpmValues.putAll(map) } }
    val bpmErrors = remember { mutableStateMapOf<String, String>() }
    val comparisonSelection = remember { mutableStateListOf<String>() }
    var autopilotPlanning by remember { mutableStateOf(false) }
    var autopilotPlanStatus by remember { mutableStateOf<String?>(null) }
    val beatmatchStored by PlaybackSettingsRepository(context).beatmatchEnabled.collectAsState(initial = false)
    val beatmatchPercentStored by PlaybackSettingsRepository(context).beatmatchMaxPercent.collectAsState(initial = 8)
    val transitionEqStored by PlaybackSettingsRepository(context).transitionEqEnabled.collectAsState(initial = true)
    var beatmatchOn by remember(beatmatchStored) { mutableStateOf(beatmatchStored) }
    var beatmatchPercent by remember(beatmatchPercentStored) { mutableFloatStateOf(beatmatchPercentStored.toFloat()) }
    var transitionEqOn by remember(transitionEqStored) { mutableStateOf(transitionEqStored) }
    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(receiverContext: Context?, intent: Intent?) {
                if (intent?.action == YanDPlaybackService.ACTION_PLAYBACK_ERROR) {
                    val title = intent.getStringExtra(YanDPlaybackService.EXTRA_TITLE) ?: "Piste inconnue"
                    val error = intent.getStringExtra(YanDPlaybackService.EXTRA_ERROR) ?: "Erreur Media3 inconnue"
                    playbackError = "Lecture impossible : $title ($error). Aucun remplacement audio n’a été lancé."
                }
            }
        }
        ContextCompat.registerReceiver(context, receiver, IntentFilter(YanDPlaybackService.ACTION_PLAYBACK_ERROR), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { context.unregisterReceiver(receiver) }
    }
    Text("MUSIC SOURCE ENGINE", color = Cyan, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Text("Les états ci-dessous reflètent uniquement les intégrations réellement disponibles dans cette version.", color = Color(0xFFBFC6DD))
    Spacer(Modifier.height(18.dp))
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface)) {
        Column(Modifier.padding(16.dp)) {
            Text("Bibliothèque audio autorisée", fontWeight = FontWeight.Bold)
            Text(if (tracks.isEmpty()) "NON CONFIGURÉ" else "PRÊTE — ${tracks.size} PISTE(S)", color = if (tracks.isEmpty()) Color(0xFFFFC86B) else Color(0xFF8EF2B0), style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(6.dp))
            Text("Choisissez un ou plusieurs fichiers audio via le sélecteur Android. L’application ne copie ni ne télécharge les fichiers.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
            Spacer(Modifier.height(8.dp))
            Text("Volume DJ Yan-D : ${volumePercent.toInt()}%", color = Cyan, style = MaterialTheme.typography.bodySmall)
            Slider(value = volumePercent, onValueChange = { volumePercent = it }, valueRange = 0f..100f, onValueChangeFinished = {
                val percent = volumePercent.toInt()
                scope.launch { PlaybackSettingsRepository(context).setMasterVolumePercent(percent) }
                context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_SET_MASTER_VOLUME).putExtra(YanDPlaybackService.EXTRA_MASTER_VOLUME, percent / 100f))
            })
            Text("Ce gain agit sur les lecteurs Yan-D uniquement ; il ne modifie pas le volume système Android.", style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD))
            Text("Durée crossfade : ${sliderSeconds.toInt()} s", color = Cyan, style = MaterialTheme.typography.bodySmall)
            Slider(value = sliderSeconds, onValueChange = { sliderSeconds = it }, valueRange = 0f..12f, steps = 11, onValueChangeFinished = {
                val seconds = sliderSeconds.toInt()
                scope.launch { PlaybackSettingsRepository(context).setCrossfadeSeconds(seconds) }
            })
            Text(if (sliderSeconds.toInt() == 0) "Passage simple : aucun crossfade demandé." else "Le crossfade est tenté si la piste suivante est préchargée et que la durée le permet.", style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD))
            Spacer(Modifier.height(12.dp))
            Text("NIVEAU DJ", color = Cyan, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = beatmatchOn, onCheckedChange = { beatmatchOn = it; scope.launch { PlaybackSettingsRepository(context).setBeatmatchEnabled(it) } })
                Text("Calage de tempo (beatmatch)", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            }
            Text("Écart de tempo accepté : ${beatmatchPercent.toInt()} %", color = Cyan, style = MaterialTheme.typography.bodySmall)
            Slider(value = beatmatchPercent, onValueChange = { beatmatchPercent = it }, valueRange = 0f..30f, steps = 29, onValueChangeFinished = { scope.launch { PlaybackSettingsRepository(context).setBeatmatchMaxPercent(beatmatchPercent.toInt()) } })
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = transitionEqOn, onCheckedChange = { transitionEqOn = it; scope.launch { PlaybackSettingsRepository(context).setTransitionEqEnabled(it) } })
                Text("Échange des basses à la transition", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            }
            Text("Ces deux réglages n’agissent QUE si les BPM ont été mesurés (🧠 PRÉPARER L’ORDRE AUTOPILOTE). Sans BPM mesuré, aucune vitesse n’est appliquée et aucune basse n’est touchée.", style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD))
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = pickAudio, modifier = Modifier.fillMaxWidth()) { Text("CHOISIR DES FICHIERS AUDIO") }
            if (tracks.isNotEmpty()) {
                Button(onClick = { playbackError = null; ContextCompat.startForegroundService(context, Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_PLAY_QUEUE).putStringArrayListExtra(YanDPlaybackService.EXTRA_URIS, ArrayList(tracks.map { it.uri })).putStringArrayListExtra(YanDPlaybackService.EXTRA_TITLES, ArrayList(tracks.map { it.title })).putIntegerArrayListExtra(YanDPlaybackService.EXTRA_BPMS, ArrayList(tracks.map { bpmValues[it.uri] ?: -1 })).putExtra(YanDPlaybackService.EXTRA_CROSSFADE_MS, crossfadeSeconds * 1000L).putExtra(YanDPlaybackService.EXTRA_MASTER_VOLUME, masterVolumePercent / 100f).putExtra(YanDPlaybackService.EXTRA_BEATMATCH, beatmatchOn).putExtra(YanDPlaybackService.EXTRA_BEATMATCH_MAX, beatmatchPercent.toInt()).putExtra(YanDPlaybackService.EXTRA_TRANSITION_EQ, transitionEqOn)) }, modifier = Modifier.fillMaxWidth()) { Text("🤖 LANCER L’AUTOPILOTE LOCAL") }
                OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_PAUSE)) }, modifier = Modifier.fillMaxWidth()) { Text("⏸ PAUSE") }
                OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_RESUME)) }, modifier = Modifier.fillMaxWidth()) { Text("▶ REPRENDRE") }
                OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_SKIP_NEXT)) }, modifier = Modifier.fillMaxWidth()) { Text("⏭ SUIVANT") }
                OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_REJECT_CURRENT)) }, modifier = Modifier.fillMaxWidth()) { Text("🚫 PAS CELUI-LÀ") }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_ADAPT_CALMER)) }, enabled = bpmValues.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("🌙 PLUS CALME") }
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_ADAPT_FESTIVE)) }, enabled = bpmValues.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("🔥 PLUS FESTIF") }
                }
                Text("AUTOPILOTE LOCAL", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text("Après lancement, Yan-D lit, précharge et enchaîne automatiquement la file. Vous n’avez pas à manipuler les volumes ou le crossfade.", style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD))
                OutlinedButton(onClick = { scope.launch {
                    autopilotPlanning = true
                    autopilotPlanStatus = "Analyse BPM locale en cours : 0/${tracks.size}"
                    tracks.forEachIndexed { index, track ->
                        val analysis = LocalBpmAnalyzer.analyze(context, track)
                        analysis.onSuccess {
                            bpmValues[track.uri] = it.bpm
                            bpmInfo[track.uri] = "BPM local : ${it.bpm} · confiance ${it.confidencePercent}% · ${it.analysedMs / 1000}s analysées"
                            LocalBpmRepository(context).save(track.uri, it.bpm)
                        }
                        analysis.onFailure { bpmValues.remove(track.uri); bpmErrors[track.uri] = it.message ?: it.javaClass.simpleName }
                        autopilotPlanStatus = "Analyse BPM locale en cours : ${index + 1}/${tracks.size}"
                    }
                    val plan = AutopilotPlanner.plan(tracks, bpmValues)
                    LocalLibraryRepository(context).replace(plan.orderedTracks)
                    autopilotPlanning = false
                    autopilotPlanStatus = "Ordre autopilote créé : ${plan.analyzedTrackCount} BPM établis sur ${tracks.size}. Tri progressif par BPM uniquement."
                } }, enabled = !autopilotPlanning, modifier = Modifier.fillMaxWidth()) { Text(if (autopilotPlanning) "ANALYSE BPM EN COURS…" else "🧠 PRÉPARER L’ORDRE AUTOPILOTE") }
                autopilotPlanStatus?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD)) }
                Text("File locale sélectionnée", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                tracks.forEachIndexed { index, track ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}.", modifier = Modifier.width(28.dp), color = Color(0xFFBFC6DD))
                        Column(Modifier.weight(1f)) {
                            Text(track.title, style = MaterialTheme.typography.bodySmall)
                            technicalInfo[track.uri]?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD)) }
                            inspectionErrors[track.uri]?.let { Text("Inspection impossible : $it", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFFB4B4)) }
                            bpmInfo[track.uri]?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF8EF2B0)) }
                            bpmErrors[track.uri]?.let { Text("BPM non établi : $it", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFFB4B4)) }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            TextButton(onClick = { scope.launch {
                                inspectionErrors.remove(track.uri)
                                LocalAudioInspector.inspect(context, track).fold(
                                    onSuccess = { technicalInfo[track.uri] = it.summary() },
                                    onFailure = { inspectionErrors[track.uri] = it.javaClass.simpleName }
                                )
                            } }) { Text("INFOS") }
                            TextButton(onClick = { scope.launch {
                                bpmErrors.remove(track.uri)
                                val analysis = LocalBpmAnalyzer.analyze(context, track)
                                analysis.onSuccess {
                                    bpmValues[track.uri] = it.bpm
                                    bpmInfo[track.uri] = "BPM local : ${it.bpm} · confiance ${it.confidencePercent}% · ${it.analysedMs / 1000}s analysées"
                                    LocalBpmRepository(context).save(track.uri, it.bpm)
                                }
                                analysis.onFailure { bpmValues.remove(track.uri); bpmErrors[track.uri] = it.message ?: it.javaClass.simpleName }
                            } }) { Text("BPM") }
                            TextButton(onClick = {
                                if (comparisonSelection.contains(track.uri)) comparisonSelection.remove(track.uri)
                                else if (comparisonSelection.size < 2) comparisonSelection.add(track.uri)
                            }, enabled = bpmValues.containsKey(track.uri) && (comparisonSelection.contains(track.uri) || comparisonSelection.size < 2)) { Text(if (comparisonSelection.contains(track.uri)) "RETENUE" else "COMPARER") }
                            TextButton(onClick = { scope.launch { comparisonSelection.remove(track.uri); LocalLibraryRepository(context).remove(track.uri) } }) { Text("RETIRER", color = Color(0xFFFF8A8A)) }
                        }
                    }
                }
                OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_STOP)) }, modifier = Modifier.fillMaxWidth()) { Text("■ ARRÊTER") }
            }
        }
    }
    if (comparisonSelection.size == 2) {
        val first = comparisonSelection[0]
        val second = comparisonSelection[1]
        val firstBpm = bpmValues[first]
        val secondBpm = bpmValues[second]
        if (firstBpm != null && secondBpm != null) {
            val tempo = BpmCompatibility.compare(firstBpm, secondBpm)
            Spacer(Modifier.height(10.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF183334))) {
                Column(Modifier.padding(14.dp)) {
                    Text("COMPATIBILITÉ TEMPO", color = Cyan, fontWeight = FontWeight.Bold)
                    Text("${tempo.scorePercent}% — ${tempo.firstBpm} BPM → ${tempo.secondBpm} BPM · écart ${tempo.difference} BPM")
                    Text("Score calculé seulement à partir de l’écart BPM relatif. Il n’analyse ni tonalité, ni structure, ni style, ni énergie ; aucune transition audio n’est appliquée.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                }
            }
        }
    }
    if (playbackError != null) {
        Spacer(Modifier.height(10.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF4A1D27))) {
            Column(Modifier.padding(14.dp)) {
                Text("ERREUR DE LECTURE RÉELLE", color = Color(0xFFFFB4B4), fontWeight = FontWeight.Bold)
                Text(playbackError!!, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    SourceCard(MusicSource("Spotify", SourceState.NOT_CONFIGURED, "Connecteur de métadonnées non configuré : OAuth PKCE et identifiants Developer requis. Spotify n’est pas une source de mix interne."))
    SourceCard(MusicSource("Musify", SourceState.NOT_AVAILABLE, "Aucune API publique officielle de partenaire validée pour la recherche et la lecture tierce. Intégration volontairement désactivée."))
}
@Composable private fun SourceCard(source: MusicSource) = Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Surface)) {
    Column(Modifier.padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(source.name, fontWeight = FontWeight.Bold)
            val label = if (source.state == SourceState.NOT_CONFIGURED) "NON CONFIGURÉ" else "NON DISPONIBLE"
            Text(label, color = if (source.state == SourceState.NOT_CONFIGURED) Color(0xFFFFC86B) else Color(0xFFFF8A8A), style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(6.dp)); Text(source.detail, style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
    }
}

@Composable private fun PartyBuilder(nav: NavHostController, context: Context) {
    val styles = AVAILABLE_STYLES
    val moods = listOf("Chill", "Romantique", "Festive", "Très dansante", "Explosive", "Tropicale", "Club")
    val selectedStyles = remember { mutableStateListOf<String>() }
    var partyName by remember { mutableStateOf("") }
    var saveMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    var mood by remember { mutableStateOf("Festive") }
    var duration by remember { mutableStateOf("5 heures") }
    var energy by remember { mutableStateOf("💥 EXPLOSIVE") }
    Page(nav, "Créer ma soirée") {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { OutlinedTextField(value = partyName, onValueChange = { partyName = it }, label = { Text("Nom de la soirée (facultatif)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { Text("1. STYLES", color = Cyan, fontWeight = FontWeight.Bold) }
            items(styles.size) { i -> ChoiceRow(styles[i], selectedStyles.contains(styles[i])) { checked -> if (checked) selectedStyles.add(styles[i]) else selectedStyles.remove(styles[i]) } }
            item { Text("2. AMBIANCE", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp)) }
            items(moods.size) { i -> FilterChip(selected = mood == moods[i], onClick = { mood = moods[i] }, label = { Text(moods[i]) }, modifier = Modifier.padding(end = 6.dp)) }
            item { Text("3. DURÉE", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp)) }
            item { SingleSelect(listOf("1 heure", "2 heures", "3 heures", "4 heures", "5 heures", "6 heures", "8 heures"), duration) { duration = it } }
            item { Text("4. ÉNERGIE", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp)) }
            item { SingleSelect(listOf("🌙 CALME", "🎶 NORMALE", "🔥 FESTIVE", "💥 EXPLOSIVE"), energy) { energy = it } }
            item { Button(onClick = { }, enabled = false, modifier = Modifier.fillMaxWidth().padding(top = 18.dp)) { Text("✨ PRÉPARER MA SOIRÉE") } }
            item { Text("La préparation reste indisponible : aucune recherche/catalogue autorisé n’est connecté. Aucune playlist ou disponibilité n’est inventée.", color = Color(0xFFFFCACA), style = MaterialTheme.typography.bodySmall) }
            item { OutlinedButton(onClick = {
                val now = System.currentTimeMillis()
                val defaultName = "Soirée du " + java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.FRANCE).format(java.util.Date(now))
                scope.launch {
                    PartyRepository(context).save(PartyDraft(now, partyName.trim().ifBlank { defaultName }, selectedStyles.toList(), mood, duration, energy, now))
                    saveMessage = "Projet de soirée enregistré localement — aucune playlist n’a été créée."
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("💾 ENREGISTRER LE PROJET DE SOIRÉE") } }
            if (saveMessage != null) item { Text(saveMessage!!, color = Color(0xFF8EF2B0), style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable private fun ChoiceRow(text: String, checked: Boolean, change: (Boolean) -> Unit) = Row(Modifier.fillMaxWidth().toggleable(value = checked, onValueChange = change).padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = checked, onCheckedChange = null); Text(text, modifier = Modifier.padding(start = 8.dp)) }
@Composable private fun SingleSelect(values: List<String>, selected: String, update: (String) -> Unit) = Column { values.forEach { value -> Row(Modifier.fillMaxWidth().clickable { update(value) }, verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = selected == value, onClick = { update(value) }); Text(value) } } }
@Composable private fun PartiesScreen(nav: NavHostController, context: Context) {
    val scope = rememberCoroutineScope()
    val parties by PartyRepository(context).parties.collectAsState(initial = emptyList())
    Page(nav, "Mes soirées") {
        if (parties.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Surface)) { Text("Aucun projet enregistré. Les projets sauvegardent vos choix, pas une playlist fictive.", Modifier.padding(18.dp), color = Color(0xFFBFC6DD)) }
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(parties.size) { index ->
                val party = parties[index]
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) { Column(Modifier.padding(16.dp)) {
                    Text(party.name, fontWeight = FontWeight.Bold)
                    Text(listOf(party.styles.ifEmpty { listOf("Aucun style") }.joinToString(", "), party.mood, party.duration, party.energy).joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                    Text("Projet enregistré — aucune playlist générée", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFFC86B), modifier = Modifier.padding(top = 7.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { scope.launch { PartyRepository(context).save(party.copy(id = System.currentTimeMillis(), name = party.name + " (copie)", createdAt = System.currentTimeMillis())) } }) { Text("DUPLIQUER") }
                        TextButton(onClick = { scope.launch { PartyRepository(context).delete(party.id) } }) { Text("SUPPRIMER", color = Color(0xFFFF8A8A)) }
                    }
                } }
            }
        }
    }
}

/**
 * Écran CATALOGUE JAMENDO — EN PLUS du reste, en aucun cas à la place.
 *
 * Telles quelles, les fonctions sont réelles : recherche via l'API officielle
 * Jamendo v3.0, lecture en flux (streaming) et téléchargement autorisé par
 * l'artiste. Sans identifiant valide, l'écran le dit et n'affiche rien d'inventé.
 */
@Composable private fun JamendoScreen(nav: NavHostController, context: Context) {
    val scope = rememberCoroutineScope()
    val storedClientId by JamendoRepository(context).clientId.catch { emit("") }.collectAsState(initial = "")
    val crossfadeSeconds by PlaybackSettingsRepository(context).crossfadeSeconds.collectAsState(initial = 6)
    val masterVolumePercent by PlaybackSettingsRepository(context).masterVolumePercent.collectAsState(initial = 100)
    var clientId by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("house") }
    var name by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<JamendoTrack>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var playbackError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(storedClientId) { if (clientId.isBlank()) clientId = storedClientId }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(receiverContext: Context?, intent: Intent?) {
                if (intent?.action == YanDPlaybackService.ACTION_PLAYBACK_ERROR) {
                    val title = intent.getStringExtra(YanDPlaybackService.EXTRA_TITLE) ?: "Piste inconnue"
                    val error = intent.getStringExtra(YanDPlaybackService.EXTRA_ERROR) ?: "Erreur Media3 inconnue"
                    playbackError = "Lecture impossible : $title ($error). Vérifie ta connexion."
                }
            }
        }
        ContextCompat.registerReceiver(context, receiver, IntentFilter(YanDPlaybackService.ACTION_PLAYBACK_ERROR), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { context.unregisterReceiver(receiver) }
    }

    fun playTracks(tracks: List<JamendoTrack>) {
        if (tracks.isEmpty()) return
        playbackError = null
        ContextCompat.startForegroundService(context, Intent(context, YanDPlaybackService::class.java)
            .setAction(YanDPlaybackService.ACTION_PLAY_QUEUE)
            .putStringArrayListExtra(YanDPlaybackService.EXTRA_URIS, ArrayList(tracks.map { it.streamUrl }))
            .putStringArrayListExtra(YanDPlaybackService.EXTRA_TITLES, ArrayList(tracks.map { "${it.name} — ${it.artistName}" }))
            .putIntegerArrayListExtra(YanDPlaybackService.EXTRA_BPMS, ArrayList(tracks.map { -1 }))
            .putExtra(YanDPlaybackService.EXTRA_CROSSFADE_MS, crossfadeSeconds * 1000L)
            .putExtra(YanDPlaybackService.EXTRA_MASTER_VOLUME, masterVolumePercent / 100f)
            .putExtra(YanDPlaybackService.EXTRA_LOCK_ORDER, false))
    }

    fun download(track: JamendoTrack) {
        if (!track.canDownload()) { message = "Téléchargement non autorisé par l’artiste pour ce titre."; return }
        try {
            val safe = track.name.replace(Regex("[^A-Za-z0-9]+"), "_").take(60)
            val request = DownloadManager.Request(android.net.Uri.parse(track.downloadUrl))
                .setTitle(track.name)
                .setDescription(track.artistName)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setMimeType("audio/mpeg")
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "DJYanD/$safe.mp3")
            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            message = "Téléchargement lancé : DJYanD/$safe.mp3. Ensuite, ajoute le fichier depuis SOURCES MUSICALES."
        } catch (e: Exception) { message = "Téléchargement impossible : ${e.javaClass.simpleName}" }
    }

    Page(nav, "Catalogue Jamendo") {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("CE CATALOGUE EST EN PLUS", color = Cyan, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Tes fichiers, tes mixes, l’autopilote et les commandes live restent exactement comme avant. Cet onglet ajoute simplement une source en ligne.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                        Spacer(Modifier.height(8.dp))
                        Text("Ce sont des artistes indépendants sous licence Creative Commons : tu n’y trouveras ni les hits du Top 50, ni les sets du Tomorrowland. Le streaming demande une connexion.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFFFC86B))
                    }
                }
            }
            item { Text("1. MON IDENTIFIANT GRATUIT", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
            item { Text("Crée-le en 5 minutes sur " + JamendoClient.DOCS_URL + " (« Create an application »), puis colle le Client ID ci-dessous.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD)) }
            item { OutlinedTextField(value = clientId, onValueChange = { clientId = it }, label = { Text("Client ID Jamendo") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { OutlinedButton(onClick = { scope.launch { JamendoRepository(context).setClientId(clientId); message = "Identifiant enregistré sur cet appareil." } }, modifier = Modifier.fillMaxWidth()) { Text("💾 ENREGISTRER L’IDENTIFIANT") } }
            item { Text("2. CHERCHER", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
            item { OutlinedTextField(value = tags, onValueChange = { tags = it }, label = { Text("Style / ambiance (anglais : house, edm, chill…)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nom d’un titre (facultatif)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item {
                Button(onClick = {
                    scope.launch {
                        searching = true
                        message = null
                        JamendoClient.search(clientId.trim(), tags, name).fold(
                            onSuccess = { found -> results = found; message = if (found.isEmpty()) "Aucun résultat renvoyé par Jamendo." else "${found.size} titre(s) renvoyé(s) par l’API officielle." },
                            onFailure = { results = emptyList(); message = "Recherche impossible : ${it.message ?: it.javaClass.simpleName}" }
                        )
                        searching = false
                    }
                }, enabled = !searching, modifier = Modifier.fillMaxWidth()) { Text(if (searching) "RECHERCHE EN COURS…" else "🔎 CHERCHER") }
            }
            message?.let { item { Text(it, style = MaterialTheme.typography.bodySmall, color = Color(0xFF8EF2B0)) } }
            if (results.isNotEmpty()) {
                item { Button(onClick = { playTracks(results) }, modifier = Modifier.fillMaxWidth()) { Text("▶ ÉCOUTER LES ${results.size} RÉSULTATS") } }
                items(results.size) { index ->
                    val track = results[index]
                    Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                        Column(Modifier.padding(14.dp)) {
                            Text(track.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            Text("${track.artistName} · ${track.durationText()}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD))
                            if (track.licenseUrl.isNotBlank()) Text("Licence Creative Commons", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8EF2B0))
                            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { playTracks(listOf(track)) }, modifier = Modifier.weight(1f)) { Text("▶ ÉCOUTER") }
                                OutlinedButton(onClick = { download(track) }, enabled = track.canDownload(), modifier = Modifier.weight(1f)) { Text(if (track.canDownload()) "💾 MP3" else "💾 REFUSÉ") }
                            }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("HONNÊTEMENT", color = Color(0xFFFFC86B), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("• Le BPM n’est pas analysé sur les titres en ligne (analyse locale uniquement).\n• Le fondu fonctionne, le calage de tempo aussi s’il a été activé dans SOURCES MUSICALES — mais il demande deux BPM mesurés.\n• Les titres téléchargés apparaissent dans tes Téléchargements : ajoute-les dans SOURCES MUSICALES pour les mixer avec le reste.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                    }
                }
            }
            playbackError?.let { error ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF4A1D27))) {
                        Column(Modifier.padding(14.dp)) {
                            Text("ERREUR DE LECTURE", color = Color(0xFFFFB4B4), fontWeight = FontWeight.Bold)
                            Text(error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Écran PARAMÈTRES : sauvegarde et restauration complètes des réglages.
 *
 * La sauvegarde ne contient AUCUN fichier audio : seulement des références (URI),
 * des choix personnels et des réglages. Après restauration, chaque fichier est
 * réellement testé pour savoir s'il est encore exploitable sur cet appareil.
 */
@Composable private fun SettingsScreen(nav: NavHostController, context: Context) {
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val library by LocalLibraryRepository(context).tracks.catch { emit(emptyList()) }.collectAsState(initial = emptyList())
    val mixes by PreparedMixRepository(context).mixes.catch { emit(emptyList()) }.collectAsState(initial = emptyList())
    val parties by PartyRepository(context).parties.catch { emit(emptyList()) }.collectAsState(initial = emptyList())
    val prefs by TrackPreferencesRepository(context).preferences.catch { emit(TrackPreferences()) }.collectAsState(initial = TrackPreferences())
    val bpmByUri by LocalBpmRepository(context).bpmByUri.catch { emit(emptyMap()) }.collectAsState(initial = emptyMap())

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            BackupManager.exportTo(context, uri).fold(
                onSuccess = { data -> message = "✅ Sauvegarde écrite : ${data.summary()}" },
                onFailure = { message = "❌ Sauvegarde impossible : ${it.message ?: it.javaClass.simpleName}" }
            )
            busy = false
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            BackupManager.importFrom(context, uri).fold(
                onSuccess = { data ->
                    val (readable, total) = BackupManager.countReadable(context, data)
                    message = "✅ Restauration terminée : ${data.summary()}.\n$readable fichier(s) relisible(s) sur $total. Les autres doivent être re-sélectionnés dans SOURCES MUSICALES."
                },
                onFailure = { message = "❌ Restauration impossible : ${it.message ?: it.javaClass.simpleName}" }
            )
            busy = false
        }
    }

    Page(nav, "Paramètres") {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("SAUVEGARDE COMPLÈTE", color = Cyan, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("${library.size} fichier(s) · ${mixes.size} mix préparé(s) · ${parties.size} soirée(s) · ${prefs.likedUris.size} coup(s) de cœur · ${prefs.styleByUri.size} étiquette(s) · ${bpmByUri.size} BPM mesuré(s)", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                    }
                }
            }
            item {
                Button(onClick = {
                    val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.FRANCE).format(java.util.Date())
                    exportLauncher.launch("dj-yand-sauvegarde-$stamp.txt")
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "OPÉRATION EN COURS…" else "💾 SAUVEGARDER MES RÉGLAGES") }
            }
            item {
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("text/plain", "*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("📂 RESTAURER UNE SAUVEGARDE") }
            }
            message?.let { text ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("RÉSULTAT", color = Cyan, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(text, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("À SAVOIR AVANT DE RESTAURER", color = Color(0xFFFFC86B), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("• La sauvegarde ne contient AUCUNE musique : seulement des références vers tes fichiers. Garde tes fichiers audio de ton côté.\n• Sur un autre téléphone, les références ne pointeront plus vers rien : il faudra re-sélectionner tes fichiers dans SOURCES MUSICALES.\n• Après une restauration, chaque fichier est réellement testé : le message te dit combien sont encore exploitables.\n• Restaurer REMPLACE ce qui existe déjà : les mixes et soirées absents du fichier sont supprimés.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("CONNEXIONS", color = Cyan, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Les paramètres audio et les connexions ne sont activés que lorsqu’un fournisseur compatible est configuré. Aucun catalogue en ligne n’est connecté pour l’instant.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                    }
                }
            }
        }
    }
}

/**
 * Écran COMMANDES LIVE.
 *
 * Trois commandes ajoutées le 28/08/2026, toutes basées sur des données réelles :
 *  - ❤️ J'AIME : mémorise le choix de l'utilisateur (et annule un rejet précédent).
 *  - 💃 PLUS DANSANT : trie la file restante selon les BPM RÉELLEMENT mesurés,
 *    dans la plage que l'utilisateur a lui-même réglée.
 *  - 🎵 CHANGER DE STYLE : utilise les étiquettes posées PAR l'utilisateur sur ses
 *    fichiers. L'application ne reconnaît aucun style à l'écoute.
 */
@Composable private fun LiveScreen(nav: NavHostController, context: Context, library: List<LocalTrack>) {
    val scope = rememberCoroutineScope()
    val prefs by TrackPreferencesRepository(context).preferences.catch { emit(TrackPreferences()) }.collectAsState(initial = TrackPreferences())
    val bpmByUri by LocalBpmRepository(context).bpmByUri.catch { emit(emptyMap()) }.collectAsState(initial = emptyMap())
    val crossfadeSeconds by PlaybackSettingsRepository(context).crossfadeSeconds.collectAsState(initial = 6)
    val masterVolumePercent by PlaybackSettingsRepository(context).masterVolumePercent.collectAsState(initial = 100)
    val danceMin by PlaybackSettingsRepository(context).danceMinBpm.collectAsState(initial = 100)
    val danceMax by PlaybackSettingsRepository(context).danceMaxBpm.collectAsState(initial = 130)
    var minSlider by remember(danceMin) { mutableFloatStateOf(danceMin.toFloat()) }
    var maxSlider by remember(danceMax) { mutableFloatStateOf(danceMax.toFloat()) }
    var currentUri by remember { mutableStateOf<String?>(null) }
    var currentTitle by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var playbackError by remember { mutableStateOf<String?>(null) }
    var taggingUri by remember { mutableStateOf<String?>(null) }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(receiverContext: Context?, intent: Intent?) {
                when (intent?.action) {
                    YanDPlaybackService.ACTION_TRACK_CHANGED -> {
                        currentUri = intent.getStringExtra(YanDPlaybackService.EXTRA_URI)
                        currentTitle = intent.getStringExtra(YanDPlaybackService.EXTRA_TITLE)
                    }
                    YanDPlaybackService.ACTION_PLAYBACK_ERROR -> {
                        val title = intent.getStringExtra(YanDPlaybackService.EXTRA_TITLE) ?: "Piste inconnue"
                        val error = intent.getStringExtra(YanDPlaybackService.EXTRA_ERROR) ?: "Erreur Media3 inconnue"
                        playbackError = "Lecture impossible : $title ($error). Aucun remplacement audio n’a été lancé."
                    }
                }
            }
        }
        val filter = IntentFilter(YanDPlaybackService.ACTION_TRACK_CHANGED)
        filter.addAction(YanDPlaybackService.ACTION_PLAYBACK_ERROR)
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { context.unregisterReceiver(receiver) }
    }

    fun likeCurrent() {
        val uri = currentUri ?: return
        val wasLiked = uri in prefs.likedUris
        scope.launch {
            TrackPreferencesRepository(context).toggleLike(uri)
            context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_LIKE_URI).putExtra(YanDPlaybackService.EXTRA_URI, uri))
            message = if (wasLiked) "Retiré de tes coups de cœur." else "Ajouté à tes coups de cœur."
        }
    }

    fun chooseStyle(style: String) {
        val matching = library.count { prefs.styleByUri[it.uri] == style }
        if (matching == 0) {
            message = "Aucun fichier étiqueté « $style ». Étiquette d’abord tes fichiers plus bas."
            return
        }
        context.startService(Intent(context, YanDPlaybackService::class.java)
            .setAction(YanDPlaybackService.ACTION_STYLE_PRIORITY)
            .putExtra(YanDPlaybackService.EXTRA_STYLE, style)
            .putStringArrayListExtra(YanDPlaybackService.EXTRA_STYLE_URIS, ArrayList(library.map { it.uri }))
            .putStringArrayListExtra(YanDPlaybackService.EXTRA_STYLES, ArrayList(library.map { prefs.styleByUri[it.uri] ?: "" })))
        message = "STYLE « $style » : $matching fichier(s) passent en tête de la file restante. Ce sont tes étiquettes, aucun son n’est ajouté."
    }

    fun launchFavourites() {
        val favourites = library.filter { it.uri in prefs.likedUris }
        if (favourites.isEmpty()) { message = "Aucun coup de cœur enregistré."; return }
        playbackError = null
        ContextCompat.startForegroundService(context, Intent(context, YanDPlaybackService::class.java)
            .setAction(YanDPlaybackService.ACTION_PLAY_QUEUE)
            .putStringArrayListExtra(YanDPlaybackService.EXTRA_URIS, ArrayList(favourites.map { it.uri }))
            .putStringArrayListExtra(YanDPlaybackService.EXTRA_TITLES, ArrayList(favourites.map { it.title }))
            .putIntegerArrayListExtra(YanDPlaybackService.EXTRA_BPMS, ArrayList(favourites.map { bpmByUri[it.uri] ?: -1 }))
            .putExtra(YanDPlaybackService.EXTRA_CROSSFADE_MS, crossfadeSeconds * 1000L)
            .putExtra(YanDPlaybackService.EXTRA_MASTER_VOLUME, masterVolumePercent / 100f))
        message = "Lecture de ${favourites.size} coup(s) de cœur, dans l’ordre de ta bibliothèque."
    }

    Page(nav, "Commandes live") {
        val uri = currentUri
        val liked = uri != null && uri in prefs.likedUris
        val favourites = library.filter { it.uri in prefs.likedUris }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("EN COURS DE LECTURE", color = Cyan, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(currentTitle ?: "Aucune lecture en cours. Lance l’autopilote depuis SOURCES MUSICALES, ou un mix préparé.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { likeCurrent() }, enabled = uri != null, modifier = Modifier.weight(1f)) { Text(if (liked) "❤️ AIMÉ" else "🤍 J’AIME") }
                            OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_REJECT_CURRENT)) }, enabled = uri != null, modifier = Modifier.weight(1f)) { Text("🚫 PAS CELUI-LÀ") }
                        }
                    }
                }
            }
            item { Text("COMMANDES", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_PAUSE)) }, modifier = Modifier.weight(1f)) { Text("⏸ PAUSE") }
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_RESUME)) }, modifier = Modifier.weight(1f)) { Text("▶ REPRENDRE") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_SKIP_NEXT)) }, modifier = Modifier.weight(1f)) { Text("⏭ SUIVANT") }
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_STOP)) }, modifier = Modifier.weight(1f)) { Text("■ ARRÊTER") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_ADAPT_CALMER)) }, enabled = bpmByUri.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("🌙 PLUS CALME") }
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_ADAPT_FESTIVE)) }, enabled = bpmByUri.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("🔥 PLUS FESTIF") }
                }
            }
            item {
                OutlinedButton(onClick = {
                    context.startService(Intent(context, YanDPlaybackService::class.java)
                        .setAction(YanDPlaybackService.ACTION_MORE_DANCEABLE)
                        .putExtra(YanDPlaybackService.EXTRA_DANCE_MIN, danceMin)
                        .putExtra(YanDPlaybackService.EXTRA_DANCE_MAX, danceMax))
                    val count = library.count { (bpmByUri[it.uri] ?: 0) in danceMin..danceMax }
                    message = "PLUS DANSANT : $count fichier(s) dont le BPM mesuré est entre $danceMin et $danceMax passent en tête. Les autres suivent, les BPM inconnus finissent la file."
                }, enabled = bpmByUri.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("💃 PLUS DANSANT") }
            }
            item {
                Text(
                    if (bpmByUri.isEmpty()) "Analyse d’abord les BPM dans SOURCES MUSICALES (🧠 PRÉPARER L’ORDRE AUTOPILOTE) : sans BPM mesuré, PLUS CALME / PLUS FESTIF / PLUS DANSANT restent sans effet."
                    else "${bpmByUri.size} BPM mesuré(s) disponible(s).",
                    style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD)
                )
            }
            item { Text("PLAGE DANSANTE (TON réglage)", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Plage : ${minSlider.toInt()} → ${maxSlider.toInt()} BPM", color = Cyan, style = MaterialTheme.typography.bodySmall)
                        Text("Ce n’est pas une analyse musicale : c’est la plage de tempo que TU considères comme dansante.", style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD))
                        Slider(value = minSlider, onValueChange = { minSlider = it }, valueRange = 60f..200f, onValueChangeFinished = { scope.launch { PlaybackSettingsRepository(context).setDanceMinBpm(minSlider.toInt()) } })
                        Slider(value = maxSlider, onValueChange = { maxSlider = it }, valueRange = 60f..200f, onValueChangeFinished = { scope.launch { PlaybackSettingsRepository(context).setDanceMaxBpm(maxSlider.toInt()) } })
                    }
                }
            }
            item { Text("🎵 CHANGER DE STYLE", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            item { Text("Yan-D ne reconnaît aucun style à l’écoute : il utilise les étiquettes que TU poses sur tes fichiers, plus bas.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD)) }
            item {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AVAILABLE_STYLES.forEach { style ->
                        val count = library.count { prefs.styleByUri[it.uri] == style }
                        FilterChip(selected = false, onClick = { chooseStyle(style) }, label = { Text("$style ($count)") })
                    }
                }
            }
            item { Text("ÉTIQUETER MES FICHIERS", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            if (library.isEmpty()) {
                item { Card(colors = CardDefaults.cardColors(containerColor = Surface)) { Text("Ta bibliothèque est vide. Ajoute des fichiers dans SOURCES MUSICALES.", Modifier.padding(16.dp), color = Color(0xFFBFC6DD), style = MaterialTheme.typography.bodySmall) } }
            } else {
                items(library.size) { index ->
                    val track = library[index]
                    val style = prefs.styleByUri[track.uri]
                    Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                        Column(Modifier.padding(12.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(track.title, style = MaterialTheme.typography.bodySmall, maxLines = 1, modifier = Modifier.weight(1f))
                                TextButton(onClick = { scope.launch { TrackPreferencesRepository(context).toggleLike(track.uri) } }) { Text(if (track.uri in prefs.likedUris) "❤️" else "🤍", style = MaterialTheme.typography.bodySmall) }
                                TextButton(onClick = { taggingUri = if (taggingUri == track.uri) null else track.uri }) { Text(style ?: "＋ STYLE", style = MaterialTheme.typography.bodySmall, color = if (style == null) Color(0xFFBFC6DD) else Cyan) }
                            }
                            if (taggingUri == track.uri) {
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    AVAILABLE_STYLES.forEach { candidate ->
                                        FilterChip(selected = candidate == style, onClick = { scope.launch { TrackPreferencesRepository(context).setStyle(track.uri, candidate); taggingUri = null } }, label = { Text(candidate) })
                                    }
                                    if (style != null) FilterChip(selected = false, onClick = { scope.launch { TrackPreferencesRepository(context).clearStyle(track.uri); taggingUri = null } }, label = { Text("Retirer") })
                                }
                            }
                        }
                    }
                }
            }
            item { Text("❤️ MES COUPS DE CŒUR (${prefs.likedUris.size})", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            if (favourites.isEmpty()) {
                item { Card(colors = CardDefaults.cardColors(containerColor = Surface)) { Text("Aucun coup de cœur. Pendant la lecture, touche 🤍 J’AIME.", Modifier.padding(16.dp), color = Color(0xFFBFC6DD), style = MaterialTheme.typography.bodySmall) } }
            } else {
                item { Button(onClick = { launchFavourites() }, modifier = Modifier.fillMaxWidth()) { Text("▶ LANCER MES COUPS DE CŒUR (${favourites.size})") } }
                items(favourites.size) { index ->
                    val favourite = favourites[index]
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(favourite.title, style = MaterialTheme.typography.bodySmall, maxLines = 1, modifier = Modifier.weight(1f))
                        TextButton(onClick = { scope.launch { TrackPreferencesRepository(context).toggleLike(favourite.uri) } }) { Text("RETIRER", style = MaterialTheme.typography.labelSmall, color = Color(0xFFFF8A8A)) }
                    }
                }
            }
            message?.let { item { Text(it, color = Color(0xFF8EF2B0), style = MaterialTheme.typography.bodySmall) } }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("CE QUE CES COMMANDES NE FONT PAS", color = Color(0xFFFFC86B), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("• ❤️ J’AIME n’ajoute aucune musique et ne cherche aucun « titre similaire » : il mémorise ton choix et annule un rejet.\n• 💃 PLUS DANSANT trie uniquement sur les BPM réellement mesurés, dans TA plage.\n• 🎵 CHANGER DE STYLE ne devine rien : il n’utilise que tes étiquettes.\n• Aucune de ces commandes ne réorganise un MIX PRÉPARÉ (ordre verrouillé).", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                    }
                }
            }
            playbackError?.let { error ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF4A1D27))) {
                        Column(Modifier.padding(14.dp)) {
                            Text("ERREUR DE LECTURE RÉELLE", color = Color(0xFFFFB4B4), fontWeight = FontWeight.Bold)
                            Text(error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Écran MIX PRÉPARÉ.
 *
 * L'utilisateur compose une liste ordonnée à partir des fichiers qu'il possède,
 * l'enregistre, puis la lance. L'ordre est verrouillé : Yan-D ne le réorganise jamais.
 * Un mix peut être un seul fichier long (set d'une heure, vidéo dont on ne garde que
 * le son) ou une suite de fichiers enchaînés avec le fondu réglé.
 */
@Composable private fun PreparedMixScreen(nav: NavHostController, context: Context) {
    val scope = rememberCoroutineScope()
    val mixes by PreparedMixRepository(context).mixes.catch { emit(emptyList()) }.collectAsState(initial = emptyList())
    val library by LocalLibraryRepository(context).tracks.catch { emit(emptyList()) }.collectAsState(initial = emptyList())
    val crossfadeSeconds by PlaybackSettingsRepository(context).crossfadeSeconds.collectAsState(initial = 6)
    val masterVolumePercent by PlaybackSettingsRepository(context).masterVolumePercent.collectAsState(initial = 100)
    val beatmatchEnabled by PlaybackSettingsRepository(context).beatmatchEnabled.collectAsState(initial = false)
    val beatmatchMaxPercent by PlaybackSettingsRepository(context).beatmatchMaxPercent.collectAsState(initial = 8)
    val transitionEqEnabled by PlaybackSettingsRepository(context).transitionEqEnabled.collectAsState(initial = true)
    val selection = remember { mutableStateListOf<LocalTrack>() }
    val formatInfo = remember { mutableStateMapOf<String, String>() }
    val formatBad = remember { mutableStateMapOf<String, Boolean>() }
    var mixName by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    var playbackError by remember { mutableStateOf<String?>(null) }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(receiverContext: Context?, intent: Intent?) {
                if (intent?.action == YanDPlaybackService.ACTION_PLAYBACK_ERROR) {
                    val title = intent.getStringExtra(YanDPlaybackService.EXTRA_TITLE) ?: "Piste inconnue"
                    val error = intent.getStringExtra(YanDPlaybackService.EXTRA_ERROR) ?: "Erreur Media3 inconnue"
                    playbackError = "Lecture impossible : $title ($error). Aucun remplacement audio n’a été lancé."
                }
            }
        }
        ContextCompat.registerReceiver(context, receiver, IntentFilter(YanDPlaybackService.ACTION_PLAYBACK_ERROR), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { context.unregisterReceiver(receiver) }
    }

    fun launchMix(mix: PreparedMix) {
        playbackError = null
        ContextCompat.startForegroundService(context, Intent(context, YanDPlaybackService::class.java)
            .setAction(YanDPlaybackService.ACTION_PLAY_QUEUE)
            .putStringArrayListExtra(YanDPlaybackService.EXTRA_URIS, ArrayList(mix.tracks.map { it.uri }))
            .putStringArrayListExtra(YanDPlaybackService.EXTRA_TITLES, ArrayList(mix.tracks.map { it.title }))
            .putIntegerArrayListExtra(YanDPlaybackService.EXTRA_BPMS, ArrayList(mix.tracks.map { -1 }))
            .putExtra(YanDPlaybackService.EXTRA_CROSSFADE_MS, crossfadeSeconds * 1000L)
            .putExtra(YanDPlaybackService.EXTRA_MASTER_VOLUME, masterVolumePercent / 100f)
            .putExtra(YanDPlaybackService.EXTRA_BEATMATCH, beatmatchEnabled)
            .putExtra(YanDPlaybackService.EXTRA_BEATMATCH_MAX, beatmatchMaxPercent)
            .putExtra(YanDPlaybackService.EXTRA_TRANSITION_EQ, transitionEqEnabled)
            .putExtra(YanDPlaybackService.EXTRA_LOCK_ORDER, true))
    }

    Page(nav, "Mix préparé") {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("MIX PRÉPARÉ", color = Cyan, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Tu choisis tes fichiers, tu les mets dans l’ordre, tu lances. Yan-D lit et enchaîne — il n’ajoute aucun son, ne télécharge rien et ne réorganise jamais ton ordre.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                    }
                }
            }
            item { Text("1. COMPOSER UN NOUVEAU MIX", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
            item { OutlinedTextField(value = mixName, onValueChange = { mixName = it }, label = { Text("Nom du mix (facultatif)") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
            item { Text(if (selection.isEmpty()) "Touche les fichiers dans l’ordre où tu veux les entendre." else "Ordre du mix : ${selection.size} fichier(s) sélectionné(s), dans l’ordre où tu les as touchés.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD)) }
            if (library.isEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                        Text("Ta bibliothèque est vide. Va dans SOURCES MUSICALES puis « CHOISIR DES FICHIERS AUDIO ». Les formats acceptés : MP3, M4A/AAC, WAV, OGG/Opus, FLAC, MP4/MKV/WebM (son seul).", Modifier.padding(16.dp), color = Color(0xFFBFC6DD), style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                items(library.size) { index ->
                    val track = library[index]
                    val position = selection.indexOf(track) + 1
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = position > 0, onCheckedChange = { checked -> if (checked) selection.add(track) else selection.remove(track) })
                        Text(if (position > 0) "$position." else "—", modifier = Modifier.width(30.dp), color = if (position > 0) Cyan else Color(0xFFBFC6DD), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                        Column(Modifier.weight(1f)) {
                            Text(track.title, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            formatInfo[track.uri]?.let { info ->
                                Text(info, style = MaterialTheme.typography.labelSmall, color = if (formatBad[track.uri] == true) Color(0xFFFFB4B4) else Color(0xFF8EF2B0))
                            }
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            checking = true
                            library.forEach { track ->
                                val result = LocalFormatCheck.check(context, track)
                                formatInfo[track.uri] = result.detail
                                formatBad[track.uri] = !result.readable
                            }
                            checking = false
                        }
                    }, enabled = library.isNotEmpty() && !checking, modifier = Modifier.weight(1f)) { Text(if (checking) "VÉRIFICATION…" else "🔎 VÉRIFIER LA LISIBILITÉ") }
                    OutlinedButton(onClick = { selection.clear() }, enabled = selection.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("VIDER LA SÉLECTION") }
                }
            }
            item {
                Button(onClick = {
                    scope.launch {
                        val now = System.currentTimeMillis()
                        val defaultName = "Mix du " + java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.FRANCE).format(java.util.Date(now))
                        val name = mixName.trim().ifBlank { defaultName }
                        PreparedMixRepository(context).save(PreparedMix(now, name, selection.toList(), now))
                        message = "Mix « $name » enregistré : ${selection.size} fichier(s), ordre conservé exactement."
                        selection.clear()
                        mixName = ""
                    }
                }, enabled = selection.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("💾 ENREGISTRER LE MIX (${selection.size})") }
            }
            message?.let { item { Text(it, color = Color(0xFF8EF2B0), style = MaterialTheme.typography.bodySmall) } }
            item { Text("2. MES MIX PRÉPARÉS", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            if (mixes.isEmpty()) {
                item { Card(colors = CardDefaults.cardColors(containerColor = Surface)) { Text("Aucun mix préparé enregistré pour l’instant.", Modifier.padding(16.dp), color = Color(0xFFBFC6DD), style = MaterialTheme.typography.bodySmall) } }
            } else {
                items(mixes.size) { index ->
                    val mix = mixes[index]
                    Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(mix.name, fontWeight = FontWeight.Bold)
                            Text(
                                if (mix.isSingleLongFile()) "${mix.fileCount()} fichier — set long : lecture continue d’un bout à l’autre, aucun fondu interne."
                                else "${mix.fileCount()} fichiers — enchaînés avec le fondu réglé (${crossfadeSeconds} s).",
                                style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD)
                            )
                            mix.tracks.take(5).forEachIndexed { i, track -> Text("${i + 1}. ${track.title}", style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD), maxLines = 1) }
                            if (mix.fileCount() > 5) Text("… et ${mix.fileCount() - 5} autre(s) fichier(s)", style = MaterialTheme.typography.labelSmall, color = Color(0xFFBFC6DD))
                            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = { launchMix(mix) }, modifier = Modifier.weight(1f)) { Text("▶ LANCER LE MIX") }
                                TextButton(onClick = { scope.launch { PreparedMixRepository(context).delete(mix.id); message = "Mix supprimé : ${mix.name}" } }) { Text("SUPPRIMER", color = Color(0xFFFF8A8A)) }
                            }
                        }
                    }
                }
            }
            item { Text("3. PENDANT LE MIX", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp)) }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_PAUSE)) }, modifier = Modifier.weight(1f)) { Text("⏸ PAUSE") }
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_RESUME)) }, modifier = Modifier.weight(1f)) { Text("▶ REPRENDRE") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_SKIP_NEXT)) }, modifier = Modifier.weight(1f)) { Text("⏭ SUIVANT") }
                    OutlinedButton(onClick = { context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_STOP)) }, modifier = Modifier.weight(1f)) { Text("■ ARRÊTER") }
                }
            }
            item {
                OutlinedButton(onClick = {
                    context.startService(Intent(context, YanDPlaybackService::class.java).setAction(YanDPlaybackService.ACTION_CLEAR_REJECTS))
                    message = "Fichiers écartés oubliés : tes mixes peuvent être rejoués en entier."
                }, modifier = Modifier.fillMaxWidth()) { Text("↺ RÉINITIALISER LES REFUS « PAS CELUI-LÀ »") }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("CE QUE CE MODE NE FAIT PAS", color = Color(0xFFFFC86B), fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("• Il ne télécharge rien, n’ajoute aucun son et n’invente aucun morceau.\n• Ton ordre est verrouillé : « PLUS CALME / PLUS FESTIF » n’ont aucun effet sur un mix préparé.\n• Il lit uniquement les fichiers que tu as ajoutés dans SOURCES MUSICALES.\n• Aucun format n’est garanti avant un test réel sur ton téléphone.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFBFC6DD))
                    }
                }
            }
            playbackError?.let { error ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF4A1D27))) {
                        Column(Modifier.padding(14.dp)) {
                            Text("ERREUR DE LECTURE RÉELLE", color = Color(0xFFFFB4B4), fontWeight = FontWeight.Bold)
                            Text(error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun InfoScreen(nav: NavHostController, title: String, message: String) = Page(nav, title) { Card(colors = CardDefaults.cardColors(containerColor = Surface)) { Text(message, Modifier.padding(18.dp), color = Color(0xFFBFC6DD)) } }
