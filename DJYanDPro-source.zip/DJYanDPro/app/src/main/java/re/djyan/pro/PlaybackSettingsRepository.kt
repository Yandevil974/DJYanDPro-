package re.djyan.pro

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val CROSSFADE_SECONDS = intPreferencesKey("crossfade_seconds")
private val MASTER_VOLUME_PERCENT = intPreferencesKey("master_volume_percent")
private val DANCE_MIN_BPM = intPreferencesKey("dance_min_bpm")
private val DANCE_MAX_BPM = intPreferencesKey("dance_max_bpm")
private val BEATMATCH_ENABLED = booleanPreferencesKey("beatmatch_enabled")
private val BEATMATCH_MAX_PERCENT = intPreferencesKey("beatmatch_max_percent")
private val TRANSITION_EQ_ENABLED = booleanPreferencesKey("transition_eq_enabled")
private val ALIGN_BEATS_ENABLED = booleanPreferencesKey("align_beats_enabled")

class PlaybackSettingsRepository(private val context: Context) {
    val crossfadeSeconds: Flow<Int> = context.sourceStore.data.map { (it[CROSSFADE_SECONDS] ?: 6).coerceIn(0, 60) }
    val masterVolumePercent: Flow<Int> = context.sourceStore.data.map { (it[MASTER_VOLUME_PERCENT] ?: 100).coerceIn(0, 100) }

    /**
     * Plage de tempo considérée comme « dansante ». Ce n'est PAS une analyse
     * musicale : c'est un réglage laissé à l'utilisateur, appliqué uniquement aux
     * BPM réellement calculés par LocalBpmAnalyzer.
     */
    val danceMinBpm: Flow<Int> = context.sourceStore.data.map { (it[DANCE_MIN_BPM] ?: 100).coerceIn(60, 200) }
    val danceMaxBpm: Flow<Int> = context.sourceStore.data.map { (it[DANCE_MAX_BPM] ?: 130).coerceIn(60, 200) }

    val beatmatchEnabled: Flow<Boolean> = context.sourceStore.data.map { it[BEATMATCH_ENABLED] ?: false }
    val beatmatchMaxPercent: Flow<Int> = context.sourceStore.data.map { (it[BEATMATCH_MAX_PERCENT] ?: 8).coerceIn(0, 50) }
    val transitionEqEnabled: Flow<Boolean> = context.sourceStore.data.map { it[TRANSITION_EQ_ENABLED] ?: true }
    val alignBeatsEnabled: Flow<Boolean> = context.sourceStore.data.map { it[ALIGN_BEATS_ENABLED] ?: false }

    suspend fun setBeatmatchEnabled(enabled: Boolean) { context.sourceStore.edit { it[BEATMATCH_ENABLED] = enabled } }
    suspend fun setBeatmatchMaxPercent(percent: Int) { context.sourceStore.edit { it[BEATMATCH_MAX_PERCENT] = percent.coerceIn(0, 50) } }
    suspend fun setTransitionEqEnabled(enabled: Boolean) { context.sourceStore.edit { it[TRANSITION_EQ_ENABLED] = enabled } }
    suspend fun setAlignBeatsEnabled(enabled: Boolean) { context.sourceStore.edit { it[ALIGN_BEATS_ENABLED] = enabled } }

    suspend fun setMasterVolumePercent(percent: Int) { context.sourceStore.edit { it[MASTER_VOLUME_PERCENT] = percent.coerceIn(0, 100) } }
    suspend fun setCrossfadeSeconds(seconds: Int) { context.sourceStore.edit { it[CROSSFADE_SECONDS] = seconds.coerceIn(0, 60) } }
    suspend fun setDanceMinBpm(bpm: Int) { context.sourceStore.edit { prefs -> prefs[DANCE_MIN_BPM] = bpm.coerceIn(60, 200).coerceAtMost(prefs[DANCE_MAX_BPM] ?: 130) } }
    suspend fun setDanceMaxBpm(bpm: Int) { context.sourceStore.edit { prefs -> prefs[DANCE_MAX_BPM] = bpm.coerceIn(60, 200).coerceAtLeast(prefs[DANCE_MIN_BPM] ?: 100) } }
}
