package re.djyan.pro

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Écriture et lecture d'un fichier de sauvegarde choisi par l'utilisateur.
 *
 * Aucun fichier audio n'est copié : seules les références (URI) et les préférences
 * sont exportées. C'est pourquoi la restauration vérifie ensuite, fichier par
 * fichier, si l'appareil arrive encore à les ouvrir.
 */
object BackupManager {

    private const val AUTOPILOT_PREFS = "autopilot_preferences"
    private const val REJECTED_KEY = "rejected_uris"

    suspend fun exportTo(context: Context, destination: Uri): Result<YanDBackup> = withContext(Dispatchers.IO) {
        runCatching {
            val settings = PlaybackSettingsRepository(context)
            val trackPrefs = TrackPreferencesRepository(context).preferences.first()
            val data = YanDBackup(
                crossfadeSeconds = settings.crossfadeSeconds.first(),
                masterVolumePercent = settings.masterVolumePercent.first(),
                danceMinBpm = settings.danceMinBpm.first(),
                danceMaxBpm = settings.danceMaxBpm.first(),
                tracks = LocalLibraryRepository(context).tracks.first(),
                bpmByUri = LocalBpmRepository(context).bpmByUri.first(),
                likedUris = trackPrefs.likedUris,
                styleByUri = trackPrefs.styleByUri,
                rejectedUris = context.getSharedPreferences(AUTOPILOT_PREFS, Context.MODE_PRIVATE).getStringSet(REJECTED_KEY, emptySet()).orEmpty(),
                mixes = PreparedMixRepository(context).mixes.first(),
                parties = PartyRepository(context).parties.first()
            )
            val stream = context.contentResolver.openOutputStream(destination)
                ?: throw IllegalStateException("Le système n’a pas fourni de flux d’écriture")
            stream.use { it.write(BackupCodec.encode(data).toByteArray(Charsets.UTF_8)) }
            data
        }
    }

    suspend fun importFrom(context: Context, source: Uri): Result<YanDBackup> = withContext(Dispatchers.IO) {
        runCatching {
            val bytes = context.contentResolver.openInputStream(source)?.use { it.readBytes() }
                ?: throw IllegalStateException("Fichier illisible")
            val data = BackupCodec.decode(String(bytes, Charsets.UTF_8))
                ?: throw IllegalStateException("Ce fichier n’est pas une sauvegarde DJ Yan-D PRO")

            LocalLibraryRepository(context).replace(data.tracks)
            LocalBpmRepository(context).replaceAll(data.bpmByUri)
            TrackPreferencesRepository(context).replaceAll(TrackPreferences(data.likedUris, data.styleByUri))

            val mixRepository = PreparedMixRepository(context)
            val backupMixIds = data.mixes.map { it.id }.toSet()
            mixRepository.mixes.first().filter { it.id !in backupMixIds }.forEach { mixRepository.delete(it.id) }
            data.mixes.forEach { mixRepository.save(it) }

            val partyRepository = PartyRepository(context)
            val backupPartyIds = data.parties.map { it.id }.toSet()
            partyRepository.parties.first().filter { it.id !in backupPartyIds }.forEach { partyRepository.delete(it.id) }
            data.parties.forEach { partyRepository.save(it) }

            val settings = PlaybackSettingsRepository(context)
            settings.setCrossfadeSeconds(data.crossfadeSeconds)
            settings.setMasterVolumePercent(data.masterVolumePercent)
            settings.setDanceMinBpm(data.danceMinBpm)
            settings.setDanceMaxBpm(data.danceMaxBpm)

            context.getSharedPreferences(AUTOPILOT_PREFS, Context.MODE_PRIVATE).edit().putStringSet(REJECTED_KEY, data.rejectedUris).apply()
            data
        }
    }

    /** Vérifie combien de fichiers de la sauvegarde sont réellement exploitables ici. */
    suspend fun countReadable(context: Context, data: YanDBackup): Pair<Int, Int> = withContext(Dispatchers.IO) {
        var readable = 0
        data.tracks.forEach { if (LocalFormatCheck.check(context, it).readable) readable++ }
        readable to data.tracks.size
    }
}
