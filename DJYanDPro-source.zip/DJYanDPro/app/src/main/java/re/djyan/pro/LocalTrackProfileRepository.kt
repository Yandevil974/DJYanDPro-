package re.djyan.pro

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Profil réel d'un fichier, tel que l'analyse l'a mesuré.
 *
 * ATTENTION : aucune valeur n'est estimée « à l'instinct ». Tout ce qui n'a pas
 * pu être mesuré reste vide, et l'ordonnanceur en tient compte au lieu de
 * combler les trous avec des suppositions.
 */
data class TrackProfile(
    val bpm: Int?,
    val firstBeatMs: Long,
    /** Niveau sonore moyen du morceau, 0 (très calme) à 100 (très fort). */
    val loudness: Int,
    /** Niveau sonore des premières secondes. */
    val intro: Int,
    /** Niveau sonore des dernières secondes — null si la fin n'a pas pu être lue. */
    val outro: Int?
) {
    /** Niveau perçu à la sortie du morceau : la fin si on la connaît, sinon la moyenne. */
    fun exitLevel(): Int = outro ?: loudness
    /** Niveau perçu à l'entrée du morceau. */
    fun entryLevel(): Int = intro
}

internal object ProfileCodec {
    private const val ENTRY = "\u001F"
    private const val PART = "\u0002"

    fun encode(map: Map<String, TrackProfile>): String = map.entries.joinToString(ENTRY) { (uri, p) ->
        listOf(enc(uri), p.bpm?.toString() ?: "", p.firstBeatMs.toString(), p.loudness.toString(), p.intro.toString(), p.outro?.toString() ?: "").joinToString(PART)
    }

    fun decode(line: String): Map<String, TrackProfile> = line.split(ENTRY).filter { it.isNotBlank() }.mapNotNull { raw ->
        val f = raw.split(PART)
        if (f.size != 6) null else dec(f[0]) to TrackProfile(
            bpm = f[1].toIntOrNull(),
            firstBeatMs = f[2].toLongOrNull() ?: 0L,
            loudness = f[3].toIntOrNull() ?: 50,
            intro = f[4].toIntOrNull() ?: 50,
            outro = f[5].toIntOrNull()
        )
    }.toMap()

    private fun enc(value: String): String = Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP)
    private fun dec(value: String): String = String(Base64.decode(value, Base64.URL_SAFE), Charsets.UTF_8)
}

private val LOCAL_PROFILES = stringPreferencesKey("local_profiles_v1")

class LocalTrackProfileRepository(private val context: Context) {
    val profiles: Flow<Map<String, TrackProfile>> = context.sourceStore.data.map { prefs ->
        prefs[LOCAL_PROFILES]?.let { ProfileCodec.decode(it) } ?: emptyMap()
    }

    suspend fun save(uri: String, profile: TrackProfile) {
        context.sourceStore.edit { store ->
            val current = store[LOCAL_PROFILES]?.let { ProfileCodec.decode(it) } ?: emptyMap()
            store[LOCAL_PROFILES] = ProfileCodec.encode(current + (uri to profile))
        }
    }

    suspend fun clear(uri: String) {
        context.sourceStore.edit { store ->
            val current = store[LOCAL_PROFILES]?.let { ProfileCodec.decode(it) } ?: emptyMap()
            store[LOCAL_PROFILES] = ProfileCodec.encode(current - uri)
        }
    }
}
