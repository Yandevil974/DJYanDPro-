package re.djyan.pro

import java.util.Base64

/**
 * Sauvegarde complète des réglages et des données de l'utilisateur.
 *
 * ATTENTION — ce que cette sauvegarde NE contient PAS :
 *  - aucun fichier audio (les données restent sur l'appareil, l'application ne les copie jamais) ;
 *  - aucune musique, aucune playlist, aucun catalogue.
 *
 * Elle contient uniquement des références (URI) et des choix personnels. Après une
 * restauration sur un autre appareil, les URI peuvent ne plus exister : l'écran
 * vérifie alors la lisibilité de chaque fichier et annonce le résultat.
 */
data class YanDBackup(
    val formatVersion: Int = 1,
    val crossfadeSeconds: Int = 6,
    val masterVolumePercent: Int = 100,
    val danceMinBpm: Int = 100,
    val danceMaxBpm: Int = 130,
    val tracks: List<LocalTrack> = emptyList(),
    val bpmByUri: Map<String, Int> = emptyMap(),
    val likedUris: Set<String> = emptySet(),
    val styleByUri: Map<String, String> = emptyMap(),
    val rejectedUris: Set<String> = emptySet(),
    val mixes: List<PreparedMix> = emptyList(),
    val parties: List<PartyDraft> = emptyList()
) {
    fun summary(): String = buildList {
        add("${tracks.size} fichier(s)")
        if (mixes.isNotEmpty()) add("${mixes.size} mix préparé(s)")
        if (parties.isNotEmpty()) add("${parties.size} soirée(s)")
        if (likedUris.isNotEmpty()) add("${likedUris.size} coup(s) de cœur")
        if (styleByUri.isNotEmpty()) add("${styleByUri.size} étiquette(s) de style")
        if (bpmByUri.isNotEmpty()) add("${bpmByUri.size} BPM mesuré(s)")
        add("fondu ${crossfadeSeconds}s")
        add("volume $masterVolumePercent%")
    }.joinToString(" · ")
}

/**
 * Format texte lisible, versionné, testable sans Android (java.util.Base64 est
 * disponible sur le JVM et sur Android API 26+).
 */
object BackupCodec {
    private const val HEADER = "DJYANDPRO_BACKUP"
    private const val SUPPORTED_VERSION = 1
    private const val TRACK = "\u001F"
    private const val PART = "\u0002"

    fun encode(data: YanDBackup): String = buildList {
        add(HEADER)
        add("FORMAT|${SUPPORTED_VERSION}")
        add("CROSSFADE|${data.crossfadeSeconds}")
        add("VOLUME|${data.masterVolumePercent}")
        add("DANCE_MIN|${data.danceMinBpm}")
        add("DANCE_MAX|${data.danceMaxBpm}")
        data.tracks.forEach { add("TRACK|${enc(it.uri)}|${enc(it.title)}") }
        data.bpmByUri.forEach { (uri, bpm) -> add("BPM|${enc(uri)}|$bpm") }
        data.likedUris.forEach { add("LIKE|${enc(it)}") }
        data.styleByUri.forEach { (uri, style) -> add("STYLE|${enc(uri)}|${enc(style)}") }
        data.rejectedUris.forEach { add("REJECT|${enc(it)}") }
        data.mixes.forEach { mix -> add("MIX|${mix.id}|${enc(mix.name)}|${mix.createdAt}|${enc(encodeTracks(mix.tracks))}") }
        data.parties.forEach { party -> add("PARTY|${party.id}|${enc(party.name)}|${enc(party.styles.joinToString(TRACK))}|${enc(party.mood)}|${enc(party.duration)}|${enc(party.energy)}|${party.createdAt}") }
    }.joinToString("\n")

    fun decode(text: String): YanDBackup? {
        val lines = text.lineSequence().map { it.trim() }.filter { it.isNotBlank() }.toList()
        if (lines.isEmpty() || lines.first() != HEADER) return null
        var version = 1
        var crossfade = 6
        var volume = 100
        var danceMin = 100
        var danceMax = 130
        val tracks = mutableListOf<LocalTrack>()
        val bpms = mutableMapOf<String, Int>()
        val likes = mutableSetOf<String>()
        val styles = mutableMapOf<String, String>()
        val rejects = mutableSetOf<String>()
        val mixes = mutableListOf<PreparedMix>()
        val parties = mutableListOf<PartyDraft>()
        for (line in lines.drop(1)) {
            val fields = line.split("|")
            when (fields.firstOrNull()) {
                "FORMAT" -> version = fields.getOrNull(1)?.toIntOrNull() ?: return null
                "CROSSFADE" -> crossfade = fields.getOrNull(1)?.toIntOrNull() ?: crossfade
                "VOLUME" -> volume = fields.getOrNull(1)?.toIntOrNull() ?: volume
                "DANCE_MIN" -> danceMin = fields.getOrNull(1)?.toIntOrNull() ?: danceMin
                "DANCE_MAX" -> danceMax = fields.getOrNull(1)?.toIntOrNull() ?: danceMax
                "TRACK" -> if (fields.size >= 3) tracks += LocalTrack(dec(fields[1]), dec(fields[2]))
                "BPM" -> fields.getOrNull(2)?.toIntOrNull()?.let { bpms[dec(fields[1])] = it }
                "LIKE" -> fields.getOrNull(1)?.let { likes += dec(it) }
                "STYLE" -> if (fields.size >= 3) styles[dec(fields[1])] = dec(fields[2])
                "REJECT" -> fields.getOrNull(1)?.let { rejects += dec(it) }
                "MIX" -> if (fields.size >= 5) fields.getOrNull(1)?.toLongOrNull()?.let { id ->
                    mixes += PreparedMix(id, dec(fields[2]), decodeTracks(dec(fields[4])), fields[3].toLongOrNull() ?: 0L)
                }
                "PARTY" -> if (fields.size >= 8) fields.getOrNull(1)?.toLongOrNull()?.let { id ->
                    parties += PartyDraft(id, dec(fields[2]), dec(fields[3]).split(TRACK).filter { it.isNotEmpty() }, dec(fields[4]), dec(fields[5]), dec(fields[6]), fields[7].toLongOrNull() ?: 0L)
                }
            }
        }
        if (version != SUPPORTED_VERSION) return null
        return YanDBackup(version, crossfade.coerceIn(0, 60), volume.coerceIn(0, 100), danceMin.coerceIn(60, 200), danceMax.coerceIn(60, 200),
            tracks, bpms, likes, styles, rejects, mixes, parties)
    }

    private fun encodeTracks(tracks: List<LocalTrack>): String = tracks.joinToString(TRACK) { enc(it.uri) + PART + enc(it.title) }

    private fun decodeTracks(blob: String): List<LocalTrack> = blob.split(TRACK).filter { it.isNotBlank() }.mapNotNull { raw ->
        val p = raw.split(PART, limit = 2)
        if (p.size != 2) null else LocalTrack(dec(p[0]), dec(p[1]))
    }

    private fun enc(value: String): String = Base64.getUrlEncoder().encodeToString(value.toByteArray(Charsets.UTF_8))
    private fun dec(value: String): String = String(Base64.getUrlDecoder().decode(value), Charsets.UTF_8)
}
