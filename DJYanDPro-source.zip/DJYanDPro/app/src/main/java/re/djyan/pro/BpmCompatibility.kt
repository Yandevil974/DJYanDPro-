package re.djyan.pro

import kotlin.math.abs
import kotlin.math.roundToInt

/** Compatibilité strictement limitée au tempo mesuré, sans prétendre analyser tonalité ou style. */
data class TempoCompatibility(val firstBpm: Int, val secondBpm: Int, val difference: Int, val scorePercent: Int)

object BpmCompatibility {
    fun compare(firstBpm: Int, secondBpm: Int): TempoCompatibility {
        require(firstBpm > 0 && secondBpm > 0)
        val difference = abs(firstBpm - secondBpm)
        val reference = maxOf(firstBpm, secondBpm).toDouble()
        val score = (100.0 - difference / reference * 100.0).roundToInt().coerceIn(0, 100)
        return TempoCompatibility(firstBpm, secondBpm, difference, score)
    }
}
