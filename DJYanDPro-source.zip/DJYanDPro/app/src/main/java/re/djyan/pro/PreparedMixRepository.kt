package re.djyan.pro

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Mix préparé : une liste ORDONNÉE de fichiers locaux que l'utilisateur possède,
 * enregistrée exactement telle qu'il l'a composée.
 *
 * Rien n'est généré, téléchargé, analysé ou inventé ici : c'est uniquement la
 * mémorisation d'un ordre choisi par l'utilisateur sur SES fichiers.
 */
data class PreparedMix(
    val id: Long,
    val name: String,
    val tracks: List<LocalTrack>,
    val createdAt: Long
) {
    /** Un mix d'un seul fichier long est joué d'un bout à l'autre, sans coupure interne. */
    fun isSingleLongFile(): Boolean = tracks.size == 1
    fun fileCount(): Int = tracks.size
}

/**
 * Encodage/décodage texte d'un mix, volontairement séparé du repository pour
 * pouvoir être testé sans Android. L'ORDRE de la liste doit être strictement
 * conservé à l'aller comme au retour.
 */
internal object PreparedMixCodec {
    private const val FIELD = "|"
    private const val TRACK = "\u001F"
    private const val PART = "\u0002"

    fun encode(mix: PreparedMix): String = listOf(
        mix.id.toString(),
        enc(mix.name),
        enc(mix.tracks.joinToString(TRACK) { enc(it.uri) + PART + enc(it.title) }),
        mix.createdAt.toString()
    ).joinToString(FIELD)

    fun decode(line: String): PreparedMix? = try {
        val parts = line.split(FIELD)
        if (parts.size != 4) null else PreparedMix(parts[0].toLong(), dec(parts[1]), decodeTracks(dec(parts[2])), parts[3].toLong())
    } catch (_: Exception) { null }

    private fun decodeTracks(blob: String): List<LocalTrack> = blob.split(TRACK).filter { it.isNotBlank() }.mapNotNull { raw ->
        val p = raw.split(PART, limit = 2)
        if (p.size != 2) null else LocalTrack(dec(p[0]), dec(p[1]))
    }

    private fun enc(value: String): String = Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP)
    private fun dec(value: String): String = String(Base64.decode(value, Base64.URL_SAFE), Charsets.UTF_8)
}

private val PREPARED_MIXES = stringPreferencesKey("prepared_mixes_v1")

class PreparedMixRepository(private val context: Context) {

    val mixes: Flow<List<PreparedMix>> = context.sourceStore.data.map { prefs ->
        prefs[PREPARED_MIXES].orEmpty()
            .lineSequence()
            .filter { it.isNotBlank() }
            .mapNotNull(PreparedMixCodec::decode)
            .sortedByDescending { it.createdAt }
            .toList()
    }

    suspend fun save(mix: PreparedMix) {
        context.sourceStore.edit { prefs ->
            val existing = prefs[PREPARED_MIXES].orEmpty()
                .lineSequence()
                .filter { it.isNotBlank() }
                .mapNotNull(PreparedMixCodec::decode)
                .filter { it.id != mix.id }
            prefs[PREPARED_MIXES] = (listOf(mix) + existing).joinToString("\n", transform = PreparedMixCodec::encode)
        }
    }

    suspend fun delete(id: Long) {
        context.sourceStore.edit { prefs ->
            prefs[PREPARED_MIXES] = prefs[PREPARED_MIXES].orEmpty()
                .lineSequence()
                .filter { it.isNotBlank() }
                .mapNotNull(PreparedMixCodec::decode)
                .filter { it.id != id }
                .joinToString("\n", transform = PreparedMixCodec::encode)
        }
    }
}
