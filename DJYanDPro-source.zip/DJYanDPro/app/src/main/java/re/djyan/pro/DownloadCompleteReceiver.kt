package re.djyan.pro

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Ajoute AUTOMATIQUEMENT à la bibliothèque chaque titre Jamendo téléchargé.
 *
 * Sans ça, il faudrait retourner chercher le fichier à la main dans le
 * gestionnaire de fichiers. Ici, dès que le téléchargement se termine, le
 * morceau apparaît dans SOURCES MUSICALES et la préparation de soirée le prend
 * comme n'importe quel autre fichier local — donc plus de streaming, donc plus
 * de coupure réseau pendant la soirée.
 */
class DownloadCompleteReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        if (id < 0L) return
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager ?: return

        manager.query(DownloadManager.Query().setFilterById(id))?.use { cursor ->
            if (!cursor.moveToFirst()) return
            val statusIndex = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val uriIndex = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
            val titleIndex = cursor.getColumnIndex(DownloadManager.COLUMN_TITLE)
            if (statusIndex < 0 || uriIndex < 0) return
            if (cursor.getInt(statusIndex) != DownloadManager.STATUS_SUCCESSFUL) return
            val uri = cursor.getString(uriIndex) ?: return
            val title = if (titleIndex >= 0) cursor.getString(titleIndex)?.takeIf { it.isNotBlank() } else null
            val track = LocalTrack(uri, title ?: "Titre Jamendo")

            // goAsync() laisse le temps au travail asynchrone de se terminer.
            val pending = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    LocalLibraryRepository(context.applicationContext).add(track)
                } finally {
                    pending.finish()
                }
            }
        }
    }
}
