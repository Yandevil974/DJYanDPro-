package re.djyan.pro

import android.media.audiofx.Equalizer

/**
 * Égaliseur de transition (niveau « DJ » : échange des basses).
 *
 * Utilise l'égaliseur système Android attaché à la session audio du lecteur.
 * Ce n'est PAS un filtre simulé : ce sont de vrais réglages appliqués au flux.
 *
 * Si l'appareil refuse l'effet (session indisponible, matériel non compatible,
 * ROM bridée), l'égaliseur reste null et AUCUNE transition n'est annoncée comme
 * traitée : l'échec est silencieux côté audio, jamais prétendu réussi.
 */
object TransitionEq {

    /** Bande haute considérée comme « basses » : 250 Hz (exprimé en millihertz par Android). */
    private const val BASS_LIMIT_MILLIHERTZ = 250_000

    fun create(sessionId: Int): Equalizer? {
        if (sessionId == 0) return null
        return try {
            val eq = Equalizer(0, sessionId)
            eq.enabled = true
            eq
        } catch (_: Throwable) { null }
    }

    /**
     * Applique un niveau (en millibels, négatif = coupure) sur les bandes de basses.
     * La valeur est bridée à ce que l'appareil accepte réellement.
     */
    fun setBass(eq: Equalizer?, millibels: Short) {
        val effect = eq ?: return
        try {
            val range = effect.bandLevelRange
            val minimum = range[0]
            val level = millibels.coerceIn(minimum, 0.toShort())
            repeat(bassBandCount(effect)) { index -> effect.setBandLevel(index.toShort(), level) }
        } catch (_: Throwable) { }
    }

    /** Remet les basses à plat, puis libère l'effet. */
    fun release(eq: Equalizer?) {
        val effect = eq ?: return
        try { setBass(effect, 0); effect.enabled = false; effect.release() } catch (_: Throwable) { }
    }

    private fun bassBandCount(eq: Equalizer): Int = try {
        var count = 0
        for (index in 0 until eq.numberOfBands) {
            if (eq.getCenterFreq(index.toShort()) <= BASS_LIMIT_MILLIHERTZ) count++ else break
        }
        count.coerceAtLeast(1)
    } catch (_: Throwable) { 1 }
}
