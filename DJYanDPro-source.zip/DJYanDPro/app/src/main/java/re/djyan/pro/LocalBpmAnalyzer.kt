package re.djyan.pro

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Analyse locale d'attaque rythmique. Le résultat n'existe que si un flux PCM
 * a été réellement décodé et si l'autocorrélation présente un pic exploitable.
 */
data class BpmAnalysis(val bpm: Int, val confidencePercent: Int, val analysedMs: Long)

object LocalBpmAnalyzer {
    suspend fun analyze(context: Context, track: LocalTrack): Result<BpmAnalysis> = withContext(Dispatchers.IO) {
        runCatching {
            val extractor = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                extractor.setDataSource(context, Uri.parse(track.uri), null)
                val index = (0 until extractor.trackCount).firstOrNull { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                    ?: error("Aucune piste audio décodable")
                val format = extractor.getTrackFormat(index)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: error("MIME audio absent")
                val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                require(sampleRate > 0 && channels > 0) { "Format audio incomplet" }
                extractor.selectTrack(index)
                codec = MediaCodec.createDecoderByType(mime)
                codec.configure(format, null, null, 0)
                codec.start()

                val energies = ArrayList<Double>()
                val frameSamples = 1024
                var accumulator = 0.0
                var count = 0
                var inputEnded = false
                var outputEnded = false
                var analysedUs = 0L
                val info = MediaCodec.BufferInfo()
                // Borné à 180 s : l'utilisateur peut lancer l'analyse sur une piste longue sans bloquer indéfiniment.
                val maximumUs = 180_000_000L
                while (!outputEnded && analysedUs < maximumUs) {
                    if (!inputEnded) {
                        val inputIndex = codec.dequeueInputBuffer(10_000)
                        if (inputIndex >= 0) {
                            val input = codec.getInputBuffer(inputIndex) ?: error("Buffer de décodage absent")
                            input.clear()
                            val size = extractor.readSampleData(input, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputEnded = true
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val outputFormat = codec.outputFormat
                            val encoding = if (outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
                            require(encoding == 2) { "PCM 16 bits requis pour l’analyse" }
                        }
                        in 0..Int.MAX_VALUE -> {
                            val output = codec.getOutputBuffer(outputIndex)
                            if (output != null && info.size > 1) {
                                output.position(info.offset)
                                output.limit(info.offset + info.size)
                                while (output.remaining() >= 2) {
                                    val lo = output.get().toInt() and 0xFF
                                    val hi = output.get().toInt()
                                    val sample = ((hi shl 8) or lo).toShort().toInt() / 32768.0
                                    accumulator += sample * sample
                                    count++
                                    if (count >= frameSamples * channels) {
                                        energies.add(accumulator / count)
                                        accumulator = 0.0; count = 0
                                    }
                                }
                            }
                            analysedUs = max(analysedUs, info.presentationTimeUs)
                            codec.releaseOutputBuffer(outputIndex, false)
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputEnded = true
                        }
                    }
                }
                require(energies.size >= 64) { "Signal insuffisant pour estimer le BPM" }
                val onset = energies.mapIndexed { i, value -> if (i == 0) 0.0 else max(0.0, value - energies[i - 1]) }
                val frameSeconds = frameSamples.toDouble() / sampleRate
                val minLag = max(1, (60.0 / 200.0 / frameSeconds).toInt())
                val maxLag = min(onset.size / 2, (60.0 / 60.0 / frameSeconds).toInt())
                require(maxLag > minLag) { "Durée analysée insuffisante" }
                val mean = onset.average()
                val centered = onset.map { it - mean }
                val denominator = centered.sumOf { it * it }
                require(denominator > 0.0) { "Aucune pulsation détectable" }
                var bestLag = minLag
                var bestScore = Double.NEGATIVE_INFINITY
                for (lag in minLag..maxLag) {
                    var score = 0.0
                    for (i in lag until centered.size) score += centered[i] * centered[i - lag]
                    if (score > bestScore) { bestScore = score; bestLag = lag }
                }
                val rawBpm = 60.0 / (bestLag * frameSeconds)
                val normalizedBpm = when {
                    rawBpm < 80.0 -> rawBpm * 2
                    rawBpm > 170.0 -> rawBpm / 2
                    else -> rawBpm
                }
                val confidence = min(100, max(0, (bestScore / denominator * 100.0).toInt()))
                require(confidence >= 8) { "Pic rythmique non fiable" }
                BpmAnalysis(normalizedBpm.toInt(), confidence, analysedUs / 1000)
            } finally {
                codec?.runCatching { stop() }; codec?.release(); extractor.release()
            }
        }
    }
}
