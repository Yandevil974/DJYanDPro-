package re.djyan.pro

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Analyse locale d'attaque rythmique. Le résultat n'existe que si un flux PCM
 * a été réellement décodé et si l'autocorrélation présente un pic exploitable.
 */
data class BpmAnalysis(
    val bpm: Int,
    val confidencePercent: Int,
    val analysedMs: Long,
    /** Position du premier temps dans le morceau, en millisecondes. Sert à aligner deux morceaux entre eux. */
    val firstBeatMs: Long = 0L,
    /** Niveau sonore moyen mesuré, de 0 (très calme) à 100 (très fort). */
    val loudness: Int = 50,
    /** Niveau sonore des premières secondes (l'entrée du morceau). */
    val introLoudness: Int = 50,
    /** Niveau sonore des dernières secondes (la sortie). Null si la fin n'a pas pu être lue. */
    val outroLoudness: Int? = null
)

object LocalBpmAnalyzer {
    suspend fun analyze(context: Context, track: LocalTrack): Result<BpmAnalysis> = withContext(Dispatchers.IO) {
        runCatching {
            val extractor = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                extractor.setDataSource(context, Uri.parse(track.uri), null)
                val index = (0 until extractor.trackCount).firstOrNull { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                    ?: error("Aucune piste audio décodable")
                val format = extractor.getTrackFormat(index)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: error("MIME audio absent")
                val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                require(sampleRate > 0 && channels > 0) { "Format audio incomplet" }
                extractor.selectTrack(index)
                codec = MediaCodec.createDecoderByType(mime)
                codec.configure(format, null, null, 0)
                codec.start()

                val energies = ArrayList<Double>()
                val frameSamples = 1024
                var accumulator = 0.0
                var count = 0
                var inputEnded = false
                var outputEnded = false
                var analysedUs = 0L
                val info = MediaCodec.BufferInfo()
                // Borné à 180 s : l'utilisateur peut lancer l'analyse sur une piste longue sans bloquer indéfiniment.
                val maximumUs = 180_000_000L
                while (!outputEnded && analysedUs < maximumUs) {
                    if (!inputEnded) {
                        val inputIndex = codec.dequeueInputBuffer(10_000)
                        if (inputIndex >= 0) {
                            val input = codec.getInputBuffer(inputIndex) ?: error("Buffer de décodage absent")
                            input.clear()
                            val size = extractor.readSampleData(input, 0)
                            if (size < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputEnded = true
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val outputFormat = codec.outputFormat
                            val encoding = if (outputFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) outputFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
                            require(encoding == 2) { "PCM 16 bits requis pour l’analyse" }
                        }
                        in 0..Int.MAX_VALUE -> {
                            val output = codec.getOutputBuffer(outputIndex)
                            if (output != null && info.size > 1) {
                                output.position(info.offset)
                                output.limit(info.offset + info.size)
                                while (output.remaining() >= 2) {
                                    val lo = output.get().toInt() and 0xFF
                                    val hi = output.get().toInt()
                                    val sample = ((hi shl 8) or lo).toShort().toInt() / 32768.0
                                    accumulator += sample * sample
                                    count++
                                    if (count >= frameSamples * channels) {
                                        energies.add(accumulator / count)
                                        accumulator = 0.0; count = 0
                                    }
                                }
                            }
                            analysedUs = max(analysedUs, info.presentationTimeUs)
                            codec.releaseOutputBuffer(outputIndex, false)
                            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputEnded = true
                        }
                    }
                }
                require(energies.size >= 64) { "Signal insuffisant pour estimer le BPM" }
                val onset = energies.mapIndexed { i, value -> if (i == 0) 0.0 else max(0.0, value - energies[i - 1]) }
                val frameSeconds = frameSamples.toDouble() / sampleRate
                val minLag = max(1, (60.0 / 200.0 / frameSeconds).toInt())
                val maxLag = min(onset.size / 2, (60.0 / 60.0 / frameSeconds).toInt())
                require(maxLag > minLag) { "Durée analysée insuffisante" }
                val mean = onset.average()
                val centered = onset.map { it - mean }
                val denominator = centered.sumOf { it * it }
                require(denominator > 0.0) { "Aucune pulsation détectable" }
                var bestLag = minLag
                var bestScore = Double.NEGATIVE_INFINITY
                for (lag in minLag..maxLag) {
                    var score = 0.0
                    for (i in lag until centered.size) score += centered[i] * centered[i - lag]
                    if (score > bestScore) { bestScore = score; bestLag = lag }
                }
                val rawBpm = 60.0 / (bestLag * frameSeconds)
                val normalizedBpm = when {
                    rawBpm < 80.0 -> rawBpm * 2
                    rawBpm > 170.0 -> rawBpm / 2
                    else -> rawBpm
                }
                val confidence = min(100, max(0, (bestScore / denominator * 100.0).toInt()))
                require(confidence >= 8) { "Pic rythmique non fiable" }

                // NIVEAU DJ 2 — grille des temps.
                // On connaît la cadence (BPM). Il reste à savoir OU tombent les temps.
                // On teste 24 décalages possibles dans la période et on garde celui qui
                // capte le plus d'énergie rythmique : c'est la position réelle du premier temps.
                val frameMs = frameSeconds * 1000.0
                val periodFrames = (60.0 / normalizedBpm) / frameSeconds
                var bestOffset = 0.0
                var bestEnergy = Double.NEGATIVE_INFINITY
                if (periodFrames >= 1.0) {
                    for (step in 0 until 24) {
                        val offset = periodFrames * step / 24.0
                        var energy = 0.0
                        var beat = 0
                        while (true) {
                            val index = (offset + beat * periodFrames).toInt()
                            if (index >= onset.size) break
                            energy += onset[index]
                            beat++
                        }
                        if (energy > bestEnergy) { bestEnergy = energy; bestOffset = offset }
                    }
                }
                val firstBeatMs = (bestOffset * frameMs).toLong().coerceIn(0L, (60000.0 / normalizedBpm).toLong())

                // Niveaux sonores mesurés sur le signal décodé (pas une estimation).
                val introFrames = (15.0 / frameSeconds).toInt().coerceIn(1, energies.size)
                val introLevel = loudnessPercent(energies.take(introFrames).average())
                val overallLevel = loudnessPercent(energies.average())
                val outroLevel = analyzeOutroLoudness(context, track)

                BpmAnalysis(normalizedBpm.toInt(), confidence, analysedUs / 1000, firstBeatMs, overallLevel, introLevel, outroLevel)
            } finally {
                codec?.runCatching { stop() }; codec?.release(); extractor.release()
            }
        }
    }

    /** Convertit une énergie moyenne en niveau perceptible de 0 à 100. */
    private fun loudnessPercent(meanSquare: Double): Int {
        if (meanSquare <= 0.0) return 0
        val db = 20.0 * kotlin.math.log10(sqrt(meanSquare))
        return ((db + 60.0) / 60.0 * 100.0).toInt().coerceIn(0, 100)
    }

    /**
     * Mesure le niveau sonore des 20 dernières secondes, en allant lire la fin du
     * fichier. Indispensable pour savoir si un morceau se termine en douceur ou
     * en plein volume. Renvoie null si la fin n'est pas accessible — jamais une
     * valeur inventée.
     */
    private fun analyzeOutroLoudness(context: Context, track: LocalTrack): Int? {
        var extractor: MediaExtractor? = null
        var codec: MediaCodec? = null
        return try {
            val local = MediaExtractor()
            extractor = local
            local.setDataSource(context, Uri.parse(track.uri), null)
            val index = (0 until local.trackCount)
                .firstOrNull { local.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
                ?: return null
            val format = local.getTrackFormat(index)
            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else -1L
            if (durationUs <= 0L) return null
            local.selectTrack(index)
            local.seekTo((durationUs - 20_000_000L).coerceAtLeast(0L), MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            val decoder = MediaCodec.createDecoderByType(mime)
            codec = decoder
            decoder.configure(format, null, null, 0)
            decoder.start()

            var sum = 0.0
            var count = 0
            var inputEnded = false
            var outputEnded = false
            val info = MediaCodec.BufferInfo()
            while (!outputEnded) {
                if (!inputEnded) {
                    val inputIndex = decoder.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val input = decoder.getInputBuffer(inputIndex) ?: break
                        input.clear()
                        val size = local.readSampleData(input, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputEnded = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, size, local.sampleTime, 0)
                            local.advance()
                        }
                    }
                }
                when (val outputIndex = decoder.dequeueOutputBuffer(info, 10_000)) {
                    in 0..Int.MAX_VALUE -> {
                        val output = decoder.getOutputBuffer(outputIndex)
                        if (output != null && info.size > 1) {
                            output.position(info.offset)
                            output.limit(info.offset + info.size)
                            while (output.remaining() >= 2) {
                                val lo = output.get().toInt() and 0xFF
                                val hi = output.get().toInt()
                                val sample = ((hi shl 8) or lo).toShort().toInt() / 32768.0
                                sum += sample * sample
                                count++
                            }
                        }
                        decoder.releaseOutputBuffer(outputIndex, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputEnded = true
                    }
                }
            }
            if (count == 0) null else loudnessPercent(sum / count)
        } catch (e: Exception) {
            null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor?.release() }
        }
    }
}
