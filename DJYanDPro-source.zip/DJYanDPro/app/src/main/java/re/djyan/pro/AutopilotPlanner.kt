package re.djyan.pro

import kotlin.math.abs

/** Planificateur déterministe : seulement les données réellement mesurées sont utilisées. */
data class AutopilotPlan(val orderedTracks: List<LocalTrack>, val analyzedTrackCount: Int)

object AutopilotPlanner {

    /** Tri simple par BPM croissant. Les BPM inconnus finissent la file. */
    fun plan(tracks: List<LocalTrack>, bpmByUri: Map<String, Int>): AutopilotPlan {
        val ordered = tracks.sortedWith(
            compareBy<LocalTrack> { bpmByUri[it.uri] ?: Int.MAX_VALUE }
                .thenBy { it.title.lowercase() }
        )
        return AutopilotPlan(ordered, tracks.count { bpmByUri[it.uri] != null })
    }

    /**
     * Ordonnancement par AFFINITÉ RÉELLE.
     *
     * Au lieu de ranger bêtement par BPM, on cherche un chemin où chaque
     * enchaînement est le plus doux possible :
     *  - les tempos restent proches ;
     *  - le niveau sonore de la FIN d'un morceau rejoint celui du DÉBUT du suivant ;
     *  - le niveau général ne fait pas de sauts brutaux.
     *
     * On part du morceau le plus calme et on remonte : la soirée monte en énergie
     * au lieu de faire des montagnes russes.
     *
     * Toutes les valeurs utilisées ont été MESURÉES. Un morceau non analysé n'est
     * pas deviné : il part en fin de file.
     */
    fun planByAffinity(tracks: List<LocalTrack>, profileByUri: Map<String, TrackProfile>): AutopilotPlan {
        val known = tracks.filter { profileByUri[it.uri] != null }
        val unknown = tracks.filter { profileByUri[it.uri] == null }
        val analyzed = known.count { profileByUri[it.uri]?.bpm != null }
        if (known.size < 2) return AutopilotPlan(known + unknown, analyzed)

        val remaining = known.toMutableList()
        val first = remaining.minByOrNull { profileByUri[it.uri]!!.loudness }!!
        remaining.remove(first)
        val ordered = mutableListOf(first)

        while (remaining.isNotEmpty()) {
            val last = ordered.last()
            val from = profileByUri[last.uri]!!
            val next = remaining.minByOrNull { candidate -> affinityDistance(from, profileByUri[candidate.uri]!!) }!!
            remaining.remove(next)
            ordered.add(next)
        }
        return AutopilotPlan(ordered + unknown, analyzed)
    }

    /**
     * Distance entre deux morceaux : plus elle est petite, mieux ils s'enchaînent.
     * Poids : le tempo domine, puis le raccord de niveau, puis l'écart général.
     */
    fun affinityDistance(from: TrackProfile, to: TrackProfile): Double {
        val tempoTerm = if (from.bpm != null && to.bpm != null) abs(from.bpm - to.bpm).toDouble() / 30.0 else 0.4
        val junctionTerm = abs(from.exitLevel() - to.entryLevel()).toDouble() / 100.0
        val bodyTerm = abs(from.loudness - to.loudness).toDouble() / 200.0
        return tempoTerm.coerceAtMost(3.0) + junctionTerm + bodyTerm
    }
}
