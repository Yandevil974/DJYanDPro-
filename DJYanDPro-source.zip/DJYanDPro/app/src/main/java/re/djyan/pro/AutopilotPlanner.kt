package re.djyan.pro

/** Planificateur déterministe : seulement les BPM réellement établis sont utilisés. */
data class AutopilotPlan(val orderedTracks: List<LocalTrack>, val analyzedTrackCount: Int)

object AutopilotPlanner {
    fun plan(tracks: List<LocalTrack>, bpmByUri: Map<String, Int>): AutopilotPlan {
        val ordered = tracks.sortedWith(
            compareBy<LocalTrack> { bpmByUri[it.uri] ?: Int.MAX_VALUE }
                .thenBy { it.title.lowercase() }
        )
        return AutopilotPlan(ordered, tracks.count { bpmByUri[it.uri] != null })
    }
}
