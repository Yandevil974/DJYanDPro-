package re.djyan.pro

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Mémorise les BPM RÉELLEMENT calculés par LocalBpmAnalyzer, par fichier.
 * Aucun BPM n'est estimé, arrondi d'office ou inventé : seul le résultat d'une
 * analyse ayant abouti est enregistré. Un fichier absent de cette liste est un
 * fichier dont le tempo n'a pas pu être établi, et il reste traité comme tel.
 */
internal object BpmCodec {
    private const val ENTRY = "\u001F"
    private const val PART = "\u0002"

    fun encode(bpmByUri: Map<String, Int>): String =
        bpmByUri.entries.joinToString(ENTRY) { enc(it.key) + PART + it.value.toString() }

    fun decode(line: String): Map<String, Int> =
        line.split(ENTRY).filter { it.isNotBlank() }.mapNotNull { raw ->
            val p = raw.split(PART, limit = 2)
            val bpm = p.getOrNull(1)?.toIntOrNull()
            if (p.size != 2 || bpm == null) null else dec(p[0]) to bpm
        }.toMap()

    private fun enc(value: String): String = Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP)
    private fun dec(value: String): String = String(Base64.decode(value, Base64.URL_SAFE), Charsets.UTF_8)
}

private val LOCAL_BPMS = stringPreferencesKey("local_bpms_v1")

/**
 * Position du premier temps de chaque fichier (millisecondes), mesurée par
 * LocalBpmAnalyzer. Sans cette donnée, impossible d'aligner deux morceaux.
 */
internal object PhaseCodec {
    private const val ENTRY = "\u001F"
    private const val PART = "\u0002"

    fun encode(phaseByUri: Map<String, Long>): String =
        phaseByUri.entries.joinToString(ENTRY) { enc(it.key) + PART + it.value.toString() }

    fun decode(line: String): Map<String, Long> =
        line.split(ENTRY).filter { it.isNotBlank() }.mapNotNull { raw ->
            val p = raw.split(PART, limit = 2)
            val phase = p.getOrNull(1)?.toLongOrNull()
            if (p.size != 2 || phase == null) null else dec(p[0]) to phase
        }.toMap()

    private fun enc(value: String): String = Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP)
    private fun dec(value: String): String = String(Base64.decode(value, Base64.URL_SAFE), Charsets.UTF_8)
}

private val LOCAL_PHASES = stringPreferencesKey("local_beat_phases_v1")

class LocalBpmRepository(private val context: Context) {

    val bpmByUri: Flow<Map<String, Int>> = context.sourceStore.data.map { prefs ->
        prefs[LOCAL_BPMS]?.let { BpmCodec.decode(it) } ?: emptyMap()
    }

    suspend fun save(uri: String, bpm: Int) {
        context.sourceStore.edit { store ->
            val current = store[LOCAL_BPMS]?.let { BpmCodec.decode(it) } ?: emptyMap()
            store[LOCAL_BPMS] = BpmCodec.encode(current + (uri to bpm))
        }
    }

    suspend fun replaceAll(bpmByUri: Map<String, Int>) {
        context.sourceStore.edit { store -> store[LOCAL_BPMS] = BpmCodec.encode(bpmByUri) }
    }

    suspend fun clear(uri: String) {
        context.sourceStore.edit { store ->
            val current = store[LOCAL_BPMS]?.let { BpmCodec.decode(it) } ?: emptyMap()
            store[LOCAL_BPMS] = BpmCodec.encode(current - uri)
            val phases = store[LOCAL_PHASES]?.let { PhaseCodec.decode(it) } ?: emptyMap()
            store[LOCAL_PHASES] = PhaseCodec.encode(phases - uri)
        }
    }

    val beatPhaseByUri: Flow<Map<String, Long>> = context.sourceStore.data.map { prefs ->
        prefs[LOCAL_PHASES]?.let { PhaseCodec.decode(it) } ?: emptyMap()
    }

    suspend fun savePhase(uri: String, firstBeatMs: Long) {
        context.sourceStore.edit { store ->
            val current = store[LOCAL_PHASES]?.let { PhaseCodec.decode(it) } ?: emptyMap()
            store[LOCAL_PHASES] = PhaseCodec.encode(current + (uri to firstBeatMs))
        }
    }

    suspend fun replaceAllPhases(phaseByUri: Map<String, Long>) {
        context.sourceStore.edit { store -> store[LOCAL_PHASES] = PhaseCodec.encode(phaseByUri) }
    }
}
