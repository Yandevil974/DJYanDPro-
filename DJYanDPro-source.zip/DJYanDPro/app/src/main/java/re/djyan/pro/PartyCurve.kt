package re.djyan.pro

/**
 * COURBE DE SOIRÉE — le déroulé que tu veux donner à ta soirée.
 *
 * Ce n'est pas un filtre de genre : c'est une façon de SÉLECTIONNER et d'ORDONNER
 * les morceaux à partir de valeurs RÉELLEMENT mesurées (tempo, niveau sonore).
 */
enum class PartyCurve(val label: String, val description: String) {
    CALME("🌙 Calme", "Morceaux doux, niveau régulier. Ambiance posée du début à la fin."),
    PROGRESSIF("📈 Progressif", "On commence doucement et on monte jusqu’au pic. Le déroulé classique d’un DJ."),
    RYTHMIQUE("🥁 Rythmique", "Tempos soutenus. Ça danse du début à la fin, sans temps mort."),
    EXPLOSIF("💥 Explosif", "On attaque fort dès le début et on reste haut."),
    ALEATOIRE("🎲 Aléatoire", "Ordre mélangé — aucune logique de tempo ni de niveau.")
}

object PartyCurves {

    val all: List<PartyCurve> = PartyCurve.values().toList()

    /**
     * Profil d'un morceau déduit de ses MESURES.
     *
     * HONNÊTETÉ : ceci ne détecte PAS un genre (Séga, Zouk, Maloya…). Reconnaître
     * un genre demande un modèle entraîné : ce serait mentir que de prétendre
     * l'inventer ici. Le profil décrit un RYTHME et une ÉNERGIE, mesurés, point.
     */
    fun profileOf(profile: TrackProfile): String {
        val bpm = profile.bpm
        val loud = profile.loudness
        return when {
            bpm == null -> if (loud >= 65) "Explosif" else "Doux"
            bpm < 100 && loud < 60 -> "Calme"
            bpm >= 100 && loud < 68 -> "Rythmique"
            loud >= 68 -> "Explosif"
            else -> "Doux"
        }
    }

    fun measuredCount(tracks: List<LocalTrack>, profiles: Map<String, TrackProfile>): Int =
        tracks.count { profiles[it.uri] != null }

    /**
     * Choisit les morceaux qui correspondent à la courbe.
     * Si le filtre laisse trop peu de monde, on prend les plus représentatifs
     * au lieu de tout reprendre — sinon « Explosif » et « Calme » donneraient
     * la même chose quand la bibliothèque est homogène.
     */
    private fun pool(
        curve: PartyCurve,
        measured: List<LocalTrack>,
        profiles: Map<String, TrackProfile>
    ): List<LocalTrack> {
        if (measured.isEmpty()) return emptyList()
        val half = (measured.size / 2).coerceAtLeast(1)
        return when (curve) {
            PartyCurve.CALME -> {
                val quiet = measured.filter { profiles[it.uri]!!.loudness <= 55 }
                if (quiet.size >= half) quiet else measured.sortedBy { profiles[it.uri]!!.loudness }.take(half)
            }
            PartyCurve.EXPLOSIF -> {
                val loud = measured.filter { profiles[it.uri]!!.loudness >= 60 }
                if (loud.size >= half) loud else measured.sortedByDescending { profiles[it.uri]!!.loudness }.take(half)
            }
            PartyCurve.RYTHMIQUE -> {
                val fast = measured.filter { (profiles[it.uri]!!.bpm ?: 0) >= 100 }
                if (fast.size >= half) fast else measured
            }
            PartyCurve.PROGRESSIF -> measured
            PartyCurve.ALEATOIRE -> measured
        }
    }

    /**
     * Construit la file selon la courbe choisie.
     * Les morceaux non mesurés ne sont jamais exclus : ils rejoignent la fin.
     */
    fun build(
        tracks: List<LocalTrack>,
        profiles: Map<String, TrackProfile>,
        curve: PartyCurve,
        maxTracks: Int,
        seed: Long = System.currentTimeMillis()
    ): List<LocalTrack> {
        if (tracks.isEmpty()) return emptyList()
        val measured = tracks.filter { profiles[it.uri] != null }
        val unmeasured = tracks.filter { profiles[it.uri] == null }
        if (measured.isEmpty()) return tracks.take(maxTracks)

        val selected = pool(curve, measured, profiles)
        val ordered: List<LocalTrack> = when (curve) {
            PartyCurve.PROGRESSIF -> selected.sortedBy { profiles[it.uri]!!.loudness } + unmeasured
            PartyCurve.CALME -> selected.sortedBy { profiles[it.uri]!!.loudness } + unmeasured
            PartyCurve.EXPLOSIF -> selected.sortedByDescending { profiles[it.uri]!!.loudness } + unmeasured
            PartyCurve.RYTHMIQUE -> AutopilotPlanner.planByAffinity(selected, profiles).orderedTracks + unmeasured
            PartyCurve.ALEATOIRE -> tracks.shuffled(kotlin.random.Random(seed))
        }
        return ordered.take(maxTracks)
    }

    /** Compte-rendu honnête : ce que la courbe va réellement faire. */
    fun describe(tracks: List<LocalTrack>, profiles: Map<String, TrackProfile>, curve: PartyCurve): String {
        if (tracks.isEmpty()) return "Aucun fichier dans ta bibliothèque."
        val measured = measuredCount(tracks, profiles)
        if (measured == 0) {
            return "⚠️ Aucun morceau analysé : la courbe ne peut PAS s’appliquer, l’ordre restera celui de ta bibliothèque. Lance 🧠 PRÉPARER L’AUTOPILOTE."
        }
        val selected = pool(curve, tracks.filter { profiles[it.uri] != null }, profiles)
        return "$measured analysé(s) sur ${tracks.size} · ${selected.size} retenu(s) par « ${curve.label} ». ${curve.description}"
    }
}
