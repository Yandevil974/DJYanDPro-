package re.djyan.pro

/**
 * COURBE DE SOIRÉE — le déroulé que tu veux donner à ta soirée.
 *
 * ⚠️ PRINCIPE CORRIGÉ APRÈS RETOUR TERRAIN :
 * l'axe principal est le **TEMPO (BPM)**, PAS le volume sonore.
 * « Un son fort ne veut pas forcément dire qu'on danse plus » — c'est le rythme
 * qui fait danser. Le niveau sonore ne sert plus que de critère secondaire,
 * et uniquement quand le tempo est inconnu.
 *
 * Ce n'est pas un filtre de genre : c'est une façon de SÉLECTIONNER et d'ORDONNER
 * les morceaux à partir de valeurs RÉELLEMENT mesurées.
 */
enum class PartyCurve(val label: String, val description: String) {
    CALME("🌙 Calme", "Tempos lents (moins de 100 BPM). Ambiance posée."),
    PROGRESSIF("📈 Progressif", "Le tempo monte : du plus lent au plus rapide. Le déroulé classique d’un DJ."),
    RYTHMIQUE("🥁 Rythmique", "Tempos dansants (100 à 124 BPM), réguliers, sans temps mort."),
    EXPLOSIF("💥 Explosif", "Tempos rapides (125 BPM et plus) — ça pulse tout de suite."),
    ALEATOIRE("🎲 Aléatoire", "Ordre mélangé — aucune logique de tempo.")
}

object PartyCurves {

    val all: List<PartyCurve> = PartyCurve.values().toList()

    private const val CALME_MAX = 100
    private const val RYTHMIQUE_MAX = 125

    /**
     * Profil d'un morceau, classé sur son TEMPO mesuré.
     * Le volume ne départage que les morceaux dont le tempo est inconnu.
     */
    fun profileOf(profile: TrackProfile): String {
        val bpm = profile.bpm
        if (bpm == null) return if (profile.loudness >= 65) "Soutenu" else "Doux"
        return when {
            bpm < CALME_MAX -> "Calme"
            bpm < RYTHMIQUE_MAX -> "Rythmique"
            else -> "Explosif"
        }
    }

    fun measuredCount(tracks: List<LocalTrack>, profiles: Map<String, TrackProfile>): Int =
        tracks.count { profiles[it.uri] != null }

    /** Sélectionne les morceaux dont le TEMPO correspond à la courbe. */
    private fun pool(
        curve: PartyCurve,
        measured: List<LocalTrack>,
        profiles: Map<String, TrackProfile>
    ): List<LocalTrack> {
        if (measured.isEmpty()) return emptyList()
        val half = (measured.size / 2).coerceAtLeast(1)
        return when (curve) {
            PartyCurve.CALME -> {
                val slow = measured.filter { (profiles[it.uri]!!.bpm ?: CALME_MAX) < CALME_MAX }
                if (slow.size >= half) slow else measured.sortedBy { profiles[it.uri]!!.bpm ?: 0 }.take(half)
            }
            PartyCurve.EXPLOSIF -> {
                val fast = measured.filter { (profiles[it.uri]!!.bpm ?: 0) >= RYTHMIQUE_MAX }
                if (fast.size >= half) fast else measured.sortedByDescending { profiles[it.uri]!!.bpm ?: 0 }.take(half)
            }
            PartyCurve.RYTHMIQUE -> {
                val dance = measured.filter { track ->
                    val bpm = profiles[track.uri]!!.bpm
                    bpm != null && bpm >= CALME_MAX && bpm < RYTHMIQUE_MAX
                }
                if (dance.size >= half) dance else measured
            }
            PartyCurve.PROGRESSIF -> measured
            PartyCurve.ALEATOIRE -> measured
        }
    }

    /** Construit la file selon la courbe : l'ordre suit le TEMPO. */
    fun build(
        tracks: List<LocalTrack>,
        profiles: Map<String, TrackProfile>,
        curve: PartyCurve,
        maxTracks: Int,
        seed: Long = System.currentTimeMillis()
    ): List<LocalTrack> {
        if (tracks.isEmpty()) return emptyList()
        val measured = tracks.filter { profiles[it.uri] != null }
        val unmeasured = tracks.filter { profiles[it.uri] == null }
        if (measured.isEmpty()) return tracks.take(maxTracks)

        val selected = pool(curve, measured, profiles)
        val ordered: List<LocalTrack> = when (curve) {
            // Progressif : le tempo MONTE, du lent vers le rapide.
            PartyCurve.PROGRESSIF -> selected.sortedBy { profiles[it.uri]!!.bpm ?: Int.MAX_VALUE } + unmeasured
            PartyCurve.CALME -> selected.sortedBy { profiles[it.uri]!!.bpm ?: Int.MAX_VALUE } + unmeasured
            PartyCurve.EXPLOSIF -> selected.sortedByDescending { profiles[it.uri]!!.bpm ?: 0 } + unmeasured
            PartyCurve.RYTHMIQUE -> AutopilotPlanner.planByAffinity(selected, profiles).orderedTracks + unmeasured
            PartyCurve.ALEATOIRE -> tracks.shuffled(kotlin.random.Random(seed))
        }
        return ordered.take(maxTracks)
    }

    /** Compte-rendu honnête : ce que la courbe va réellement faire. */
    fun describe(tracks: List<LocalTrack>, profiles: Map<String, TrackProfile>, curve: PartyCurve): String {
        if (tracks.isEmpty()) return "Aucun fichier dans ta bibliothèque."
        val measured = measuredCount(tracks, profiles)
        if (measured == 0) {
            return "⚠️ Aucun morceau analysé : la courbe ne peut PAS s’appliquer, l’ordre restera celui de ta bibliothèque. Lance 🧠 PRÉPARER L’AUTOPILOTE."
        }
        val selected = pool(curve, tracks.filter { profiles[it.uri] != null }, profiles)
        return "$measured analysé(s) sur ${tracks.size} · ${selected.size} retenu(s) par « ${curve.label} ». ${curve.description}"
    }
}
