package re.djyan.pro

/**
 * Catalogue des ambiances.
 *
 * Chaque ambiance porte des valeurs RÉELLEMENT exploitables :
 *  - une plage de tempo (pour filtrer tes fichiers mesurés) ;
 *  - une plage de niveau sonore (idem) ;
 *  - des mots-clés Jamendo (en anglais, seul langage que l'API comprend) ;
 *  - une période de sortie, pour les décennies (l'API Jamendo sait filtrer par date).
 *
 * Aucune ambiance ne promet un résultat : si un style n'existe pas dans le
 * catalogue, la recherche renverra zéro et ce sera dit, pas comblé.
 */
data class AmbianceSpec(
    val label: String,
    val bpmRange: IntRange,
    val loudnessRange: IntRange,
    val jamendoTags: List<String>,
    val fromDate: String? = null,
    val toDate: String? = null
)

object PartyMood {

    val ambiances: List<AmbianceSpec> = listOf(
        AmbianceSpec("Chill", 60..105, 0..70, listOf("chillout", "ambient", "lounge")),
        AmbianceSpec("Romantique", 60..115, 0..75, listOf("soul", "jazz", "ballad")),
        AmbianceSpec("Festive", 108..142, 30..100, listOf("dance", "pop", "party")),
        AmbianceSpec("Très dansante", 116..138, 45..100, listOf("dance", "electronic", "house")),
        AmbianceSpec("Explosive", 122..165, 60..100, listOf("electronic", "techno", "trance")),
        AmbianceSpec("Tropicale", 88..128, 25..100, listOf("latin", "reggae", "world")),
        AmbianceSpec("Club", 118..140, 50..100, listOf("house", "club", "electronic")),
        AmbianceSpec("Mashup", 95..140, 35..100, listOf("mashup", "remix", "electronic")),
        AmbianceSpec("Disco", 105..130, 35..100, listOf("disco", "funk")),
        AmbianceSpec("Funk", 100..125, 35..100, listOf("funk", "soul")),
        AmbianceSpec("Années 80", 100..130, 30..100, listOf("80s", "pop", "disco"), "1980-01-01", "1989-12-31"),
        AmbianceSpec("Années 90", 95..140, 30..100, listOf("90s", "dance", "pop"), "1990-01-01", "1999-12-31"),
        AmbianceSpec("Années 2000", 100..140, 30..100, listOf("2000s", "pop", "dance"), "2000-01-01", "2009-12-31"),
        AmbianceSpec("Années 2010", 110..142, 35..100, listOf("2010s", "dance", "electronic"), "2010-01-01", "2019-12-31"),
        AmbianceSpec("Années 2020", 110..150, 35..100, listOf("2020s", "electronic", "pop"), "2020-01-01", "2026-12-31"),
        AmbianceSpec("Nouveautés 2025-2027", 100..150, 30..100, listOf("pop", "electronic", "dance"), "2025-01-01", "2027-12-31")
    )

    val labels: List<String> = ambiances.map { it.label }

    fun specFor(label: String): AmbianceSpec = ambiances.firstOrNull { it.label == label }
        ?: AmbianceSpec(label, 0..400, 0..100, listOf("pop"))

    /** Traduit un style de l'application en mot-clé Jamendo (anglais). */
    fun styleTag(style: String): String = when (style) {
        "Ragga" -> "ragga"
        "Dancehall" -> "dancehall"
        "Reggae" -> "reggae"
        "Zouk Love" -> "zouk"
        "Kompa" -> "kompa"
        "R&B" -> "rnb"
        "Afrobeat" -> "afrobeat"
        "Amapiano" -> "amapiano"
        "Séga" -> "sega"
        "Maloya" -> "maloya"
        "House" -> "house"
        "Années 80" -> "80s"
        "Années 90" -> "90s"
        "Années 2000" -> "2000s"
        "Années 2010" -> "2010s"
        "Années 2020" -> "2020s"
        "Nouveautés 2025-2027" -> "pop"
        "Mashup" -> "mashup"
        "Disco" -> "disco"
        "Funk" -> "funk"
        else -> style.lowercase()
    }
}
