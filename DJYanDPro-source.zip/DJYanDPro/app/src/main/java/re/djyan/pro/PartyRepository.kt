package re.djyan.pro

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Sauvegarde locale de paramètres de soirée. Aucune playlist ou piste n'est créée ici. */
data class PartyDraft(
    val id: Long,
    val name: String,
    val styles: List<String>,
    val mood: String,
    val duration: String,
    val energy: String,
    val createdAt: Long
)

private val PARTY_DRAFTS = stringPreferencesKey("party_drafts_v1")

class PartyRepository(private val context: Context) {
    val parties: Flow<List<PartyDraft>> = context.sourceStore.data.map { prefs ->
        prefs[PARTY_DRAFTS].orEmpty().lineSequence().filter { it.isNotBlank() }.mapNotNull(::decode).sortedByDescending { it.createdAt }.toList()
    }

    suspend fun save(draft: PartyDraft) {
        context.sourceStore.edit { prefs ->
            val existing = prefs[PARTY_DRAFTS].orEmpty().lineSequence().filter { it.isNotBlank() }.mapNotNull(::decode).filter { it.id != draft.id }
            prefs[PARTY_DRAFTS] = (listOf(draft) + existing).joinToString("\n", transform = ::encode)
        }
    }

    suspend fun delete(id: Long) {
        context.sourceStore.edit { prefs ->
            prefs[PARTY_DRAFTS] = prefs[PARTY_DRAFTS].orEmpty().lineSequence().filter { it.isNotBlank() }.mapNotNull(::decode).filter { it.id != id }.joinToString("\n", transform = ::encode)
        }
    }

    private fun enc(value: String) = Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP)
    private fun dec(value: String) = String(Base64.decode(value, Base64.URL_SAFE), Charsets.UTF_8)
    private fun encode(d: PartyDraft) = listOf(d.id.toString(), enc(d.name), enc(d.styles.joinToString("\u001F")), enc(d.mood), enc(d.duration), enc(d.energy), d.createdAt.toString()).joinToString("|")
    private fun decode(line: String): PartyDraft? = try {
        val p = line.split("|")
        if (p.size != 7) null else PartyDraft(p[0].toLong(), dec(p[1]), dec(p[2]).split("\u001F").filter { it.isNotEmpty() }, dec(p[3]), dec(p[4]), dec(p[5]), p[6].toLong())
    } catch (_: Exception) { null }
}
