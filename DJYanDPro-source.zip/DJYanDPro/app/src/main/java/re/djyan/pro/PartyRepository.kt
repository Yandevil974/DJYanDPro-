package re.djyan.pro

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Sauvegarde locale de paramètres de soirée. Aucune playlist ou piste n'est créée ici. */
data class PartyDraft(
    val id: Long,
    val name: String,
    val styles: List<String>,
    val mood: String,
    val duration: String,
    val energy: String,
    val createdAt: Long,
    /** Morceaux réellement retenus. Vide = projet sans file. */
    val tracks: List<LocalTrack> = emptyList(),
    /** Compte-rendu honnête de ce qui a été trouvé. */
    val summary: String = ""
)

private val PARTY_DRAFTS = stringPreferencesKey("party_drafts_v1")

class PartyRepository(private val context: Context) {
    val parties: Flow<List<PartyDraft>> = context.sourceStore.data.map { prefs ->
        prefs[PARTY_DRAFTS].orEmpty().lineSequence().filter { it.isNotBlank() }.mapNotNull(::decode).sortedByDescending { it.createdAt }.toList()
    }

    suspend fun save(draft: PartyDraft) {
        context.sourceStore.edit { prefs ->
            val existing = prefs[PARTY_DRAFTS].orEmpty().lineSequence().filter { it.isNotBlank() }.mapNotNull(::decode).filter { it.id != draft.id }
            prefs[PARTY_DRAFTS] = (listOf(draft) + existing).joinToString("\n", transform = ::encode)
        }
    }

    suspend fun delete(id: Long) {
        context.sourceStore.edit { prefs ->
            prefs[PARTY_DRAFTS] = prefs[PARTY_DRAFTS].orEmpty().lineSequence().filter { it.isNotBlank() }.mapNotNull(::decode).filter { it.id != id }.joinToString("\n", transform = ::encode)
        }
    }

    private fun enc(value: String) = Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP)
    private fun dec(value: String) = String(Base64.decode(value, Base64.URL_SAFE), Charsets.UTF_8)
    private fun encode(d: PartyDraft) = listOf(
        d.id.toString(), enc(d.name), enc(d.styles.joinToString("\u001F")), enc(d.mood), enc(d.duration), enc(d.energy), d.createdAt.toString(),
        enc(d.summary), enc(d.tracks.joinToString("\u001F") { enc(it.uri) + "\u0002" + enc(it.title) })
    ).joinToString("|")

    private fun decode(line: String): PartyDraft? = try {
        val p = line.split("|")
        if (p.size != 9) null else PartyDraft(
            p[0].toLong(), dec(p[1]), dec(p[2]).split("\u001F").filter { it.isNotEmpty() }, dec(p[3]), dec(p[4]), dec(p[5]), p[6].toLong(),
            dec(p[7]), dec(p[8]).split("\u001F").filter { it.isNotBlank() }.mapNotNull { raw ->
                val f = raw.split("\u0002", limit = 2)
                if (f.size != 2) null else LocalTrack(dec(f[0]), dec(f[1]))
            }
        )
    } catch (_: Exception) { null }
}
