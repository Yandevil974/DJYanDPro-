package re.djyan.pro

/**
 * Détection du style à partir d'informations DÉJÀ ÉCRITES dans le fichier :
 *  - la métadonnée « genre » (ID3, Vorbis…), posée par l'artiste ou le label ;
 *  - le nom du fichier, quand il contient le style (« Zouk Love 2024.mp3 »).
 *
 * Ce n'est PAS une analyse du son : on lit une information existante et vérifiable.
 * Si rien n'est écrit, on ne devine rien — on renvoie null.
 *
 * SÉCURITÉ : la comparaison se fait sur des MOTS ENTIERS, jamais sur un simple
 * « contient ». Sinon « parapluie » serait classé en Rap (pa-rap-luie).
 */
object StyleDetector {

    private val KEYWORDS: List<Pair<List<String>, String>> = listOf(
        listOf("zouklove", "zouk") to "Zouk Love",
        listOf("ragga") to "Ragga",
        listOf("dancehall") to "Dancehall",
        listOf("reggae") to "Reggae",
        listOf("kompa", "kompas") to "Kompa",
        listOf("afrobeat", "afrobeats", "afro") to "Afrobeat",
        listOf("amapiano") to "Amapiano",
        listOf("sega") to "Séga",
        listOf("maloya") to "Maloya",
        listOf("hiphop", "rap", "trap") to "Rap",
        listOf("rnb", "rb") to "R&B",
        listOf("house", "deephouse", "techhouse") to "House",
        listOf("mashup") to "Mashup",
        listOf("disco") to "Disco",
        listOf("funk") to "Funk",
        listOf("pop") to "Pop",
        listOf("80s") to "Années 80",
        listOf("90s") to "Années 90",
        listOf("2000s") to "Années 2000",
        listOf("2010s") to "Années 2010",
        listOf("2020s") to "Années 2020"
    )

    /** Minuscules, sans accents, tout ce qui n'est pas lettre/chiffre devient un espace. */
    fun normalize(text: String): String {
        val spaced = text.replace(Regex("([a-z])([A-Z])"), "$1 $2")
        return spaced.lowercase()
            .replace('é', 'e').replace('è', 'e').replace('ê', 'e').replace('ë', 'e')
            .replace('à', 'a').replace('â', 'a').replace('ä', 'a')
            .replace('î', 'i').replace('ï', 'i')
            .replace('ô', 'o').replace('ö', 'o')
            .replace('û', 'u').replace('ù', 'u').replace('ü', 'u')
            .replace('ç', 'c')
            .map { if (it.isLetterOrDigit()) it else ' ' }
            .joinToString("")
    }

    /**
     * Découpe en mots entiers. On sépare seulement lettre→chiffre
     * (« zouklove2024 » → « zouklove 2024 »), en gardant « 90s » et « 2000s » intacts.
     */
    fun tokenize(text: String): Set<String> = normalize(text)
        .replace(Regex("([a-z])([0-9])"), "$1 $2")
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }
        .toSet()

    /** Cherche un style dans plusieurs textes, dans l'ordre. null si rien d'identifiable. */
    fun detect(vararg texts: String?): String? {
        for (text in texts) {
            if (text.isNullOrBlank()) continue
            val tokenSet = tokenize(text)
            for ((keys, style) in KEYWORDS) {
                if (keys.any { it in tokenSet }) return style
            }
        }
        return null
    }
}
