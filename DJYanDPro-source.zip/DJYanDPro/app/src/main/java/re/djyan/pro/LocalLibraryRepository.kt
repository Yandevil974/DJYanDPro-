package re.djyan.pro

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Liste de références URI choisies par l'utilisateur, pas une copie ni un catalogue musical. */
private val LOCAL_LIBRARY = stringPreferencesKey("local_library_v1")

class LocalLibraryRepository(private val context: Context) {
    val tracks: Flow<List<LocalTrack>> = context.sourceStore.data.map { prefs ->
        prefs[LOCAL_LIBRARY].orEmpty().lineSequence().mapNotNull(::decode).toList()
    }

    suspend fun replace(items: List<LocalTrack>) {
        context.sourceStore.edit { it[LOCAL_LIBRARY] = items.distinctBy { track -> track.uri }.joinToString("\n", transform = ::encode) }
    }
    /** Ajoute un fichier sans jamais écraser la liste existante. */
    suspend fun add(track: LocalTrack) {
        context.sourceStore.edit { prefs ->
            val current = prefs[LOCAL_LIBRARY].orEmpty().lineSequence().mapNotNull(::decode).toMutableList()
            if (current.none { it.uri == track.uri }) current += track
            prefs[LOCAL_LIBRARY] = current.distinctBy { it.uri }.joinToString("\n", transform = ::encode)
        }
    }

    suspend fun remove(uri: String) {
        context.sourceStore.edit { prefs -> prefs[LOCAL_LIBRARY] = prefs[LOCAL_LIBRARY].orEmpty().lineSequence().mapNotNull(::decode).filterNot { it.uri == uri }.joinToString("\n", transform = ::encode) }
    }

    private fun encode(t: LocalTrack) = Base64.encodeToString(t.uri.toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP) + "|" + Base64.encodeToString(t.title.toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP)
    private fun decode(line: String): LocalTrack? = try {
        val p = line.split("|", limit = 2)
        if (p.size != 2) null else LocalTrack(String(Base64.decode(p[0], Base64.URL_SAFE)), String(Base64.decode(p[1], Base64.URL_SAFE)))
    } catch (_: Exception) { null }
}
