package re.djyan.pro

/**
 * Règles de composition d'une soirée — pures et testables.
 *
 * PRINCIPE : on ne sélectionne que ce qui a été MESURÉ. Un fichier dont on ne
 * connaît ni le tempo ni le niveau n'est pas écarté pour autant : il est
 * conservé, et le compte-rendu le dit. Rien n'est inventé, rien n'est deviné.
 */
data class PartySelection(
    val tracks: List<LocalTrack>,
    val measuredCount: Int,
    val unmeasuredCount: Int,
    val styleMatchedCount: Int,
    val message: String
)

object PartyBuilderRules {

    fun maxTracksFor(duration: String): Int = when (duration) {
        "1 heure" -> 16
        "2 heures" -> 32
        "3 heures" -> 48
        "4 heures" -> 64
        "5 heures" -> 80
        "6 heures" -> 96
        "8 heures" -> 128
        else -> 32
    }

    /** Plage de tempo correspondant à une ambiance. Large : c'est un filtre, pas un ordre. */
    fun bpmRangeFor(mood: String): IntRange = PartyMood.specFor(mood).bpmRange

    /** Plage de niveau sonore correspondant à une énergie (0-100). */
    fun loudnessRangeFor(energy: String): IntRange = when (energy) {
        "🌙 CALME" -> 0..50
        "🎶 NORMALE" -> 25..85
        "🔥 FESTIVE" -> 55..100
        "💥 EXPLOSIVE" -> 70..100
        else -> 0..100
    }

    /** Conservé pour compatibilité : borne basse de la plage d'énergie. */
    fun minLoudnessFor(energy: String): Int = loudnessRangeFor(energy).first

    /**
     * Compose la liste des morceaux d'une soirée.
     * 1. on garde les fichiers dont l'étiquette correspond aux styles choisis
     *    (si aucun fichier n'est étiqueté, on prend tout et on le dit) ;
     * 2. parmi eux, ceux dont on connaît le profil doivent correspondre à
     *    l'ambiance et à l'énergie ;
     * 3. ceux qu'on n'a pas pu mesurer sont conservés ;
     * 4. on trie par affinité et on limite à la durée demandée.
     */
    fun selectTracks(
        tracks: List<LocalTrack>,
        profiles: Map<String, TrackProfile>,
        styleByUri: Map<String, String>,
        styles: List<String>,
        mood: String,
        energy: String,
        duration: String
    ): PartySelection {
        if (tracks.isEmpty()) {
            return PartySelection(emptyList(), 0, 0, 0, "Aucun fichier dans ta bibliothèque. Ajoute d’abord tes fichiers dans SOURCES MUSICALES.")
        }
        val tagged = tracks.filter { styleByUri[it.uri] != null }
        val styleMatched = if (styles.isEmpty()) tracks else tracks.filter { styleByUri[it.uri] in styles }
        val base = if (styles.isEmpty() || tagged.isEmpty()) tracks else styleMatched

        val bpmRange = bpmRangeFor(mood)
        val loudRange = loudnessRangeFor(energy)
        val measured = base.filter { profiles[it.uri] != null }
        val unmeasured = base.filter { profiles[it.uri] == null }
        val kept = measured.filter { track ->
            val profile = profiles[track.uri]!!
            val bpmOk = profile.bpm == null || profile.bpm in bpmRange
            val levelOk = profile.loudness in loudRange
            bpmOk && levelOk
        }

        val candidates = kept + unmeasured
        if (candidates.isEmpty()) {
            return PartySelection(emptyList(), 0, 0, 0,
                "Aucun morceau mesuré ne correspond à cette ambiance ($mood) et cette énergie ($energy). Lance 🧠 PRÉPARER L’ORDRE AUTOPILOTE, ou choisis une ambiance plus large.")
        }

        val ordered = AutopilotPlanner.planByAffinity(candidates, profiles).orderedTracks
        val limited = ordered.take(maxTracksFor(duration))

        val message = buildString {
            append("${limited.size} morceau(x) retenu(s)")
            if (styles.isNotEmpty() && tagged.isNotEmpty()) append(" · ${styleMatched.size} portant tes étiquettes")
            else if (styles.isNotEmpty()) append(" · aucun fichier étiqueté, toute la bibliothèque a été utilisée")
            append(" · ${kept.size} profil(s) mesuré(s) conformes")
            if (unmeasured.isNotEmpty()) append(" · ${unmeasured.size} non mesuré(s) placé(s) en fin de file")
            append(".")
        }
        return PartySelection(limited, kept.size, unmeasured.size, styleMatched.size, message)
    }
}
