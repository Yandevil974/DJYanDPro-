package re.djyan.pro

import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Lit uniquement les métadonnées que le décodeur Android expose pour l'URI
 * sélectionnée. Ne devine ni BPM ni tonalité.
 */
data class LocalAudioInfo(
    val durationMs: Long?,
    val mimeType: String?,
    val bitrate: Int?,
    val sampleRate: Int?
) {
    fun summary(): String = buildList {
        durationMs?.let { add("Durée ${formatDuration(it)}") }
        mimeType?.let { add(it) }
        bitrate?.takeIf { it > 0 }?.let { add("${it / 1000} kb/s") }
        sampleRate?.takeIf { it > 0 }?.let { add("${it / 1000f} kHz") }
    }.joinToString(" · ").ifBlank { "Aucune métadonnée technique fournie par Android" }

    private fun formatDuration(ms: Long): String = String.format(Locale.FRANCE, "%d:%02d", ms / 60000, (ms / 1000) % 60)
}

object LocalAudioInspector {
    suspend fun inspect(context: Context, track: LocalTrack): Result<LocalAudioInfo> = withContext(Dispatchers.IO) {
        runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, android.net.Uri.parse(track.uri))
                fun text(key: Int): String? = retriever.extractMetadata(key)
                LocalAudioInfo(
                    durationMs = text(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull(),
                    mimeType = text(MediaMetadataRetriever.METADATA_KEY_MIMETYPE),
                    bitrate = text(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull(),
                    sampleRate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) text(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)?.toIntOrNull() else null
                )
            } finally { retriever.release() }
        }
    }
}
