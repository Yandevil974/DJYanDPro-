package re.djyan.pro

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Enregistre le dernier plantage de l'application.
 *
 * Sans cela, un crash sur le téléphone reste invisible : on ne peut pas deviner
 * la cause. Ici, la raison exacte est écrite dans un fichier ET affichée dans
 * l'écran 🩺 DIAGNOSTIC, où elle peut être sélectionnée et copiée.
 */
object CrashRecorder {

    private const val FILE_NAME = "dernier_plantage.txt"
    private var installed = false

    fun install(context: Context) {
        if (installed) return
        installed = true
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE).format(Date())
                val text = buildString {
                    appendLine("DJ Yan-D PRO — PLANTAGE DU $stamp")
                    appendLine("Thread : ${thread.name}")
                    appendLine()
                    appendLine(throwable.toString())
                    throwable.stackTrace.take(30).forEach { appendLine("    at $it") }
                    var cause = throwable.cause
                    var level = 0
                    while (cause != null && level < 3) {
                        appendLine()
                        appendLine("Cause : $cause")
                        cause.stackTrace.take(20).forEach { appendLine("    at $it") }
                        cause = cause.cause
                        level++
                    }
                }
                runCatching { File(app.filesDir, FILE_NAME).writeText(text) }
                runCatching {
                    val external = app.getExternalFilesDir(null)
                    if (external != null) {
                        external.mkdirs()
                        File(external, FILE_NAME).writeText(text)
                    }
                }
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    fun lastCrash(context: Context): String? = try {
        val file = File(context.filesDir, FILE_NAME)
        if (file.exists()) file.readText().trim().ifBlank { null } else null
    } catch (_: Exception) { null }

    fun clear(context: Context) {
        runCatching { File(context.filesDir, FILE_NAME).delete() }
    }
}
