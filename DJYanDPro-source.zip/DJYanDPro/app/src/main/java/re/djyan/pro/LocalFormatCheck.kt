package re.djyan.pro

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Vérification de lisibilité d'un fichier local.
 *
 * IMPORTANT — cette vérification ne devine rien :
 *  - elle ouvre le fichier avec MediaMetadataRetriever (le décodeur Android réel) ;
 *  - elle lit le type MIME et la durée que le système expose ;
 *  - elle signale les formats que le lecteur (ExoPlayer / Media3, sans extension
 *    FFmpeg) ne sait pas décoder d'après la documentation officielle Android.
 *
 * Elle ne garantit pas la lecture : seul un test sur l'appareil le peut.
 */
data class FormatCheck(
    val readable: Boolean,
    val mimeType: String?,
    val durationMs: Long?,
    val detail: String
)

object LocalFormatCheck {

    /**
     * Formats NON décodables par ExoPlayer/Media3 sans l'extension FFmpeg.
     * Source : tableau officiel « Supported formats » de la documentation Android Media3.
     */
    private val UNPLAYABLE_TOKENS = listOf(
        "x-ms-wma", "wma",            // Windows Media Audio
        "ape", "x-ape",               // Monkey's Audio
        "alac", "x-alac",             // Apple Lossless
        "aiff", "x-aiff",             // AIFF
        "x-wavpack", "wavpack",
        "midi", "x-midi", "sp-midi"   // MIDI : ce n'est pas de l'audio encodé
    )

    /** Formats que le lecteur décode sans extension particulière. */
    private val PLAYABLE_TOKENS = listOf(
        "mpeg", "mp3", "mp4", "m4a", "aac", "adts", "flac", "ogg", "opus", "vorbis",
        "wav", "x-wav", "wave", "matroska", "webm", "mpeg-ts", "ts", "amr", "3gpp"
    )

    suspend fun check(context: Context, track: LocalTrack): FormatCheck = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, Uri.parse(track.uri))
            val mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            classify(mime, duration)
        } catch (e: Exception) {
            FormatCheck(
                readable = false,
                mimeType = null,
                durationMs = null,
                detail = "Ouverture impossible par Android : ${e.javaClass.simpleName}. Le fichier est peut-être absent, déplacé ou protégé."
            )
        } finally {
            try { retriever.release() } catch (_: Exception) { }
        }
    }

    private fun classify(mime: String?, durationMs: Long?): FormatCheck {
        val lower = mime?.lowercase(Locale.FRANCE).orEmpty()
        val durationText = durationMs?.takeIf { it > 0 }?.let { " · durée ${formatDuration(it)}" } ?: " · durée non communiquée par Android"

        if (UNPLAYABLE_TOKENS.any { lower.contains(it) }) {
            return FormatCheck(false, mime, durationMs, "Format non décodable par le lecteur ($mime). Convertis-le en MP3, M4A/AAC, OGG ou FLAC.")
        }
        if (lower.startsWith("video/")) {
            return FormatCheck(true, mime, durationMs, "Vidéo détectée : seule la piste audio sera lue.$durationText")
        }
        if (lower.isBlank()) {
            return FormatCheck(true, mime, durationMs, "Type MIME non communiqué par Android$durationText — à confirmer à l'écoute.")
        }
        if (PLAYABLE_TOKENS.any { lower.contains(it) }) {
            return FormatCheck(true, mime, durationMs, "Lisible par le lecteur : $mime$durationText")
        }
        return FormatCheck(true, mime, durationMs, "Type inhabituel ($mime)$durationText — à confirmer à l'écoute.")
    }

    private fun formatDuration(ms: Long): String = String.format(Locale.FRANCE, "%d h %02d min", ms / 3_600_000, (ms / 60_000) % 60)
        .let { if (ms < 3_600_000) String.format(Locale.FRANCE, "%d:%02d", ms / 60_000, (ms / 1_000) % 60) else it }
}
