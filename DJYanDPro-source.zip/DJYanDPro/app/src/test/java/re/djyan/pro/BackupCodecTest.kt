package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Vérifie que rien n'est perdu ni inventé lors d'une sauvegarde : ce qui sort
 * d'un aller-retour doit être identique à ce qui est entré.
 */
class BackupCodecTest {

    private fun sample() = YanDBackup(
        crossfadeSeconds = 8,
        masterVolumePercent = 75,
        danceMinBpm = 105,
        danceMaxBpm = 135,
        tracks = listOf(LocalTrack("content://a", "Intro.mp3"), LocalTrack("content://b", "Set 1h.mp4")),
        bpmByUri = mapOf("content://a" to 124),
        likedUris = setOf("content://a"),
        styleByUri = mapOf("content://a" to "Zouk Love"),
        rejectedUris = setOf("content://b"),
        mixes = listOf(PreparedMix(1L, "Samedi soir", listOf(LocalTrack("content://a", "Intro.mp3")), 42L)),
        parties = listOf(PartyDraft(7L, "Anniversaire", listOf("Séga", "Maloya"), "Festive", "5 heures", "🔥 FESTIVE", 99L))
    )

    @Test
    fun unAllerRetourNePerdRien() {
        assertEquals(sample(), BackupCodec.decode(BackupCodec.encode(sample())))
    }

    @Test
    fun lordreDesFichiersEtDesMixEstConserve() {
        val decoded = BackupCodec.decode(BackupCodec.encode(sample()))!!
        assertEquals(listOf("content://a", "content://b"), decoded.tracks.map { it.uri })
        assertEquals("Samedi soir", decoded.mixes.first().name)
        assertEquals(listOf(LocalTrack("content://a", "Intro.mp3")), decoded.mixes.first().tracks)
    }

    @Test
    fun uneSauvegardeVideResteVide() {
        val decoded = BackupCodec.decode(BackupCodec.encode(YanDBackup()))!!
        assertTrue(decoded.tracks.isEmpty())
        assertTrue(decoded.mixes.isEmpty())
        assertTrue(decoded.parties.isEmpty())
        assertEquals(6, decoded.crossfadeSeconds)
        assertEquals(100, decoded.masterVolumePercent)
    }

    @Test
    fun unFichierEtrangerNestPasAccepte() {
        assertNull(BackupCodec.decode("bonjour, je ne suis pas une sauvegarde"))
        assertNull(BackupCodec.decode(""))
    }

    @Test
    fun uneVersionInconnueEstRefuseePlutotQueMalInterpretee() {
        assertNull(BackupCodec.decode("DJYANDPRO_BACKUP\nFORMAT|99"))
    }

    @Test
    fun leResumeDecritVraimentLeContenu() {
        val summary = sample().summary()
        assertTrue(summary.contains("2 fichier(s)"))
        assertTrue(summary.contains("1 mix préparé(s)"))
        assertTrue(summary.contains("1 BPM mesuré(s)"))
        assertTrue(summary.contains("fondu 8s"))
    }
}
