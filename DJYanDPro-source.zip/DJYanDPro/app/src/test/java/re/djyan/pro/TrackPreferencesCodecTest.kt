package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Vérifie que les choix de l'utilisateur (coups de cœur, étiquettes de style)
 * sont conservés exactement, et qu'une donnée illisible ne fabrique rien.
 */
class TrackPreferencesCodecTest {

    @Test
    fun lesCoupsDeCoeurSontConserves() {
        val prefs = TrackPreferences(likedUris = setOf("content://a", "content://b"))
        val decoded = TrackPreferencesCodec.decode(TrackPreferencesCodec.encode(prefs))!!
        assertEquals(setOf("content://a", "content://b"), decoded.likedUris)
    }

    @Test
    fun lesEtiquettesDeStyleSontConservees() {
        val prefs = TrackPreferences(styleByUri = mapOf("content://a" to "Zouk Love", "content://b" to "Séga"))
        val decoded = TrackPreferencesCodec.decode(TrackPreferencesCodec.encode(prefs))!!
        assertEquals("Zouk Love", decoded.styleByUri["content://a"])
        assertEquals("Séga", decoded.styleByUri["content://b"])
    }

    @Test
    fun unVideResteUnVide() {
        val decoded = TrackPreferencesCodec.decode(TrackPreferencesCodec.encode(TrackPreferences()))!!
        assertTrue(decoded.likedUris.isEmpty())
        assertTrue(decoded.styleByUri.isEmpty())
    }

    @Test
    fun uneDonneeCorrompueNeCreeRien() {
        assertNull(TrackPreferencesCodec.decode("incomplet"))
    }

    @Test
    fun lesBpmMesuresSontConservesParFichier() {
        val encoded = BpmCodec.encode(mapOf("content://a" to 128, "content://b" to 96))
        assertEquals(mapOf("content://a" to 128, "content://b" to 96), BpmCodec.decode(encoded))
    }

    @Test
    fun uneEntreeBpmIllisibleEstIgnoreePasInventee() {
        assertEquals(emptyMap<String, Int>(), BpmCodec.decode(""))
        assertEquals(mapOf("content://a" to 120), BpmCodec.decode(BpmCodec.encode(mapOf("content://a" to 120)) + "\u001Fcassé"))
    }
}
