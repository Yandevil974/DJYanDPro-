package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Test

/** Grille des temps : calculs purs, vérifiés sans Android. */
class BeatGridTest {

    @Test
    fun laPeriodeCorrespondAuTempo() {
        assertEquals(500L, BeatGrid.periodMs(120))
        assertEquals(375L, BeatGrid.periodMs(160))
        assertEquals(0L, BeatGrid.periodMs(0))
    }

    @Test
    fun laPhaseEstNulleAuMomentDuTemps() {
        val period = BeatGrid.periodMs(120) // 500 ms
        assertEquals(0L, BeatGrid.phaseAt(2_000L, 0L, period))
        assertEquals(0L, BeatGrid.phaseAt(2_500L, 0L, period))
    }

    @Test
    fun lePremierTempsEstPrisEnCompte() {
        val period = BeatGrid.periodMs(120)
        // le premier temps tombe à 300 ms : à 300 ms on est sur le temps
        assertEquals(0L, BeatGrid.phaseAt(300L, 300L, period))
        assertEquals(0L, BeatGrid.phaseAt(800L, 300L, period))
        assertEquals(100L, BeatGrid.phaseAt(900L, 300L, period))
    }

    @Test
    fun lAttenteAvantLeProchainTempsEstCorrecte() {
        val period = BeatGrid.periodMs(120)
        // position 0 = on est pile sur un temps : on peut démarrer tout de suite
        assertEquals(0L, BeatGrid.delayToNextBeat(0L, 0L, period))
        assertEquals(200L, BeatGrid.delayToNextBeat(300L, 0L, period))
        assertEquals(0L, BeatGrid.delayToNextBeat(500L, 0L, period))
    }

    @Test
    fun sansTempoAucuneAttenteNestImposee() {
        assertEquals(0L, BeatGrid.delayToNextBeat(1_234L, 0L, 0L))
    }
}
