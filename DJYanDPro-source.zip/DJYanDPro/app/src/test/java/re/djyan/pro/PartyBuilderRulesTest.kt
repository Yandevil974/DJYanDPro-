package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Règles de composition d'une soirée : mesuré uniquement, jamais deviné. */
class PartyBuilderRulesTest {

    private fun track(uri: String) = LocalTrack(uri, uri)
    private fun profile(bpm: Int?, loudness: Int) = TrackProfile(bpm, 0L, loudness, loudness, loudness)

    @Test
    fun laDureeDetermineLeNombreDeMorceaux() {
        assertEquals(16, PartyBuilderRules.maxTracksFor("1 heure"))
        assertEquals(80, PartyBuilderRules.maxTracksFor("5 heures"))
    }

    @Test
    fun uneAmbianceCalmeExclutLesTemposRapides() {
        val tracks = listOf(track("calme"), track("rapide"))
        val profiles = mapOf("calme" to profile(95, 50), "rapide" to profile(150, 80))
        val result = PartyBuilderRules.selectTracks(tracks, profiles, emptyMap(), emptyList(), "Chill", "🎶 NORMALE", "2 heures")
        assertEquals(listOf("calme"), result.tracks.map { it.uri })
    }

    @Test
    fun unMorceauNonMesureNEstPasExcluMaisAnnonce() {
        val tracks = listOf(track("mesure"), track("inconnu"))
        val profiles = mapOf("mesure" to profile(120, 60))
        val result = PartyBuilderRules.selectTracks(tracks, profiles, emptyMap(), emptyList(), "Festive", "🎶 NORMALE", "2 heures")
        assertEquals(2, result.tracks.size)
        assertEquals(1, result.unmeasuredCount)
        assertTrue(result.message.contains("non mesuré"))
    }

    @Test
    fun lesEtiquettesDeStyleSontUtiliseesQuandEllesExistent() {
        val tracks = listOf(track("zouk"), track("techno"))
        val styles = mapOf("zouk" to "Zouk Love", "techno" to "House")
        val result = PartyBuilderRules.selectTracks(tracks, emptyMap(), styles, listOf("Zouk Love"), "Festive", "🎶 NORMALE", "2 heures")
        assertEquals(listOf("zouk"), result.tracks.map { it.uri })
        assertEquals(1, result.styleMatchedCount)
    }

    @Test
    fun sansFichierEtiqueteOnPrendToutEtOnLeDit() {
        val tracks = listOf(track("a"), track("b"))
        val result = PartyBuilderRules.selectTracks(tracks, emptyMap(), emptyMap(), listOf("Séga"), "Festive", "🎶 NORMALE", "2 heures")
        assertEquals(2, result.tracks.size)
        assertTrue(result.message.contains("aucun fichier étiqueté"))
    }

    @Test
    fun bibliothequeVideDonneUnMessageClair() {
        val result = PartyBuilderRules.selectTracks(emptyList(), emptyMap(), emptyMap(), emptyList(), "Festive", "🎶 NORMALE", "2 heures")
        assertTrue(result.tracks.isEmpty())
        assertTrue(result.message.contains("SOURCES MUSICALES"))
    }
}
