package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Tests du mix préparé : l'ordre choisi par l'utilisateur doit être conservé
 * exactement, et un mix d'un seul fichier doit être reconnu comme set long.
 */
class PreparedMixTest {

    private fun track(index: Int) = LocalTrack("content://media/audio/$index", "Piste $index")

    @Test
    fun lordreDesPistesEstConserveApresEncodage() {
        val mix = PreparedMix(1L, "Soirée du samedi", listOf(track(3), track(1), track(2)), 1_700_000_000_000L)
        val decoded = PreparedMixCodec.decode(PreparedMixCodec.encode(mix))
        assertEquals(listOf(track(3), track(1), track(2)), decoded!!.tracks)
        assertEquals("Soirée du samedi", decoded.name)
        assertEquals(3, decoded.fileCount())
    }

    @Test
    fun unSeulFichierEstUnSetLong() {
        val mix = PreparedMix(2L, "Set d'une heure", listOf(track(1)), 1L)
        assertTrue(mix.isSingleLongFile())
        assertFalse(PreparedMix(3L, "Deux titres", listOf(track(1), track(2)), 1L).isSingleLongFile())
    }

    @Test
    fun uneLigneInvalideNeCreePasDeFauxMix() {
        assertNull(PreparedMixCodec.decode("ligne incomplète"))
        assertNull(PreparedMixCodec.decode("1|abc"))
    }
}
