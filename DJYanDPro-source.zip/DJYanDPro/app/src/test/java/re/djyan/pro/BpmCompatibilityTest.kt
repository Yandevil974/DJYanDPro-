package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Test

class BpmCompatibilityTest {
    @Test fun identicalTemposProduce100Percent() {
        val result = BpmCompatibility.compare(120, 120)
        assertEquals(0, result.difference)
        assertEquals(100, result.scorePercent)
    }

    @Test fun scoreUsesRelativeTempoDifference() {
        val result = BpmCompatibility.compare(120, 126)
        assertEquals(6, result.difference)
        assertEquals(95, result.scorePercent)
    }

    @Test fun invertedInputsHaveSameResult() {
        val first = BpmCompatibility.compare(100, 140)
        val second = BpmCompatibility.compare(140, 100)
        assertEquals(first.difference, second.difference)
        assertEquals(first.scorePercent, second.scorePercent)
    }

    @Test fun scoreNeverLeavesRange() {
        assertEquals(1, BpmCompatibility.compare(1, 100).scorePercent)
        assertEquals(100, BpmCompatibility.compare(1, 1).scorePercent)
    }
}
