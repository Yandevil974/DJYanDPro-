package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Ordonnancement par affinité : tempo + niveau sonore, uniquement sur du mesuré. */
class AutopilotAffinityTest {

    private fun track(uri: String) = LocalTrack(uri, uri)
    private fun profile(bpm: Int?, loudness: Int, intro: Int, outro: Int?) =
        TrackProfile(bpm, 0L, loudness, intro, outro)

    @Test
    fun laSoireeCommenceParLeMorceauLePlusCalme() {
        val tracks = listOf(track("fort"), track("moyen"), track("calme"))
        val profiles = mapOf(
            "fort" to profile(128, 90, 80, 85),
            "moyen" to profile(126, 60, 55, 58),
            "calme" to profile(120, 30, 28, 30)
        )
        val plan = AutopilotPlanner.planByAffinity(tracks, profiles)
        assertEquals("calme", plan.orderedTracks.first().uri)
    }

    @Test
    fun lesMorceauxProchesEnTempoSeSuivent() {
        val tracks = listOf(track("a"), track("b"), track("c"))
        val profiles = mapOf(
            "a" to profile(100, 40, 40, 40),
            "b" to profile(128, 45, 45, 45),
            "c" to profile(126, 50, 50, 50)
        )
        val ordered = AutopilotPlanner.planByAffinity(tracks, profiles).orderedTracks.map { it.uri }
        // b et c sont proches : ils doivent se suivre, a (100) reste à part
        val positionB = ordered.indexOf("b")
        val positionC = ordered.indexOf("c")
        assertEquals(1, kotlin.math.abs(positionB - positionC))
    }

    @Test
    fun lesMorceauxNonAnalysesFinissentLaFileSansEtrePlacesAuHasard() {
        val tracks = listOf(track("connu1"), track("inconnu"), track("connu2"))
        val profiles = mapOf(
            "connu1" to profile(120, 40, 40, 40),
            "connu2" to profile(122, 45, 45, 45)
        )
        val ordered = AutopilotPlanner.planByAffinity(tracks, profiles).orderedTracks.map { it.uri }
        assertEquals(listOf("connu1", "connu2", "inconnu"), ordered)
    }

    @Test
    fun laDistanceFavoriseUnRaccordDeNiveauPlutotQuUnSaut() {
        val sortie = profile(128, 60, 50, 40)
        val doux = profile(128, 60, 42, null)
        val brutal = profile(128, 60, 95, null)
        assertTrue(AutopilotPlanner.affinityDistance(sortie, doux) < AutopilotPlanner.affinityDistance(sortie, brutal))
    }

    @Test
    fun unTempoInconnuNEstJamaisPretenduCompatible() {
        val avecTempo = profile(128, 50, 50, 50)
        val sansTempo = profile(null, 50, 50, 50)
        assertTrue(AutopilotPlanner.affinityDistance(avecTempo, sansTempo) > 0.0)
    }
}
