package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Vérifie les règles de réorganisation de la file : uniquement à partir de BPM
 * mesurés ou d'étiquettes posées par l'utilisateur. Aucune donnée n'est inventée.
 */
class QueueReorderTest {

    @Test
    fun lesBpmDansLaPlageDansantePassentEnTete() {
        val uris = listOf("a", "b", "c", "d")
        val bpm = mapOf("a" to 90, "b" to 120, "c" to 128, "d" to 140)
        assertEquals(listOf("b", "c", "a", "d"), QueueReorder.byDanceRange(uris, bpm, 100, 130))
    }

    @Test
    fun lesBpmInconnusFinissentToujoursLaFile() {
        val uris = listOf("connu", "inconnu", "dansant")
        val bpm = mapOf("connu" to 95, "dansant" to 124)
        assertEquals(listOf("dansant", "connu", "inconnu"), QueueReorder.byDanceRange(uris, bpm, 110, 130))
    }

    @Test
    fun laPlageEstToujoursInterpreteeDansLeBonSens() {
        val uris = listOf("lent", "moyen", "rapide")
        val bpm = mapOf("lent" to 92, "moyen" to 118, "rapide" to 150)
        assertEquals(QueueReorder.byDanceRange(uris, bpm, 100, 130), QueueReorder.byDanceRange(uris, bpm, 130, 100))
    }

    @Test
    fun changerDeStyleUtiliseUniquementLesEtiquettesDeLutilisateur() {
        val uris = listOf("t1", "t2", "t3", "t4")
        val styles = mapOf("t2" to "Zouk Love", "t4" to "Zouk Love")
        assertEquals(listOf("t2", "t4", "t1", "t3"), QueueReorder.byStyle(uris, styles, "Zouk Love"))
    }

    @Test
    fun unStyleSansAucuneEtiquetteNeReorganiseRien() {
        val uris = listOf("t1", "t2")
        assertEquals(uris, QueueReorder.byStyle(uris, mapOf("t1" to "Séga"), "Maloya"))
    }
}
