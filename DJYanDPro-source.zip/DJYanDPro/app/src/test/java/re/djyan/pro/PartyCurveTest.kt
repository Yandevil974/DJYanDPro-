package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Courbes de soirée, désormais basées sur le TEMPO (et non sur le volume).
 * « Un son fort ne veut pas dire qu'on danse plus » : c'est le rythme qui compte.
 */
class PartyCurveTest {

    private fun track(uri: String) = LocalTrack(uri, uri)
    private fun profile(bpm: Int?, loudness: Int) = TrackProfile(bpm, 0L, loudness, loudness, loudness)

    private val tracks = listOf(track("lent"), track("moyen"), track("rapide"))
    private val profiles = mapOf(
        "lent" to profile(90, 30),
        "moyen" to profile(115, 55),
        "rapide" to profile(140, 85)
    )

    @Test
    fun laCourbeCalmeGardeLesTemposLents() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.CALME, 10)
        assertEquals("lent", order.first().uri)
    }

    @Test
    fun laCourbeProgressiveFaitMonterLeTempo() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.PROGRESSIF, 10).map { it.uri }
        assertEquals(listOf("lent", "moyen", "rapide"), order)
    }

    @Test
    fun laCourbeExplosiveCommenceParLeTempoLePlusRapide() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.EXPLOSIF, 10)
        assertEquals("rapide", order.first().uri)
    }

    @Test
    fun laCourbeRythmiquePrendLesTemposIntermediaires() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.RYTHMIQUE, 10).map { it.uri }
        assertTrue(order.contains("moyen"))
        assertTrue(!order.contains("lent"))
    }

    @Test
    fun leProfilEstBaseSurLeTempoEtNonSurLeVolume() {
        assertEquals("Calme", PartyCurves.profileOf(profile(90, 85)))      // fort MAIS lent → Calme
        assertEquals("Rythmique", PartyCurves.profileOf(profile(115, 30))) // doux MAIS dansant → Rythmique
        assertEquals("Explosif", PartyCurves.profileOf(profile(140, 40)))  // doux MAIS rapide → Explosif
        assertEquals("Doux", PartyCurves.profileOf(profile(null, 30)))
        assertEquals("Soutenu", PartyCurves.profileOf(profile(null, 80)))
    }

    @Test
    fun laDureeLimiteLeNombreDeMorceaux() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.PROGRESSIF, 2)
        assertEquals(2, order.size)
    }
}
