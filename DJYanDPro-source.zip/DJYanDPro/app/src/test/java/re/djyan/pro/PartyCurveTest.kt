package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Courbes de soirée : sélection et ordre à partir de mesures réelles. */
class PartyCurveTest {

    private fun track(uri: String) = LocalTrack(uri, uri)
    private fun profile(bpm: Int?, loudness: Int) = TrackProfile(bpm, 0L, loudness, loudness, loudness)

    private val tracks = listOf(track("doux"), track("moyen"), track("fort"))
    private val profiles = mapOf(
        "doux" to profile(95, 30),
        "moyen" to profile(120, 55),
        "fort" to profile(128, 85)
    )

    @Test
    fun laCourbeCalmeGardeLesMorceauxLesPlusDoux() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.CALME, 10)
        assertEquals("doux", order.first().uri)
        assertTrue(order.any { it.uri == "moyen" })
    }

    @Test
    fun laCourbeProgressiveMonteEnNiveau() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.PROGRESSIF, 10).map { it.uri }
        assertEquals(listOf("doux", "moyen", "fort"), order)
    }

    @Test
    fun laCourbeExplosiveCommenceParLePlusFort() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.EXPLOSIF, 10)
        assertEquals("fort", order.first().uri)
    }

    @Test
    fun laCourbeRythmiqueEcarteLesTemposLents() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.RYTHMIQUE, 10).map { it.uri }
        assertTrue(order.contains("moyen"))
        assertTrue(order.contains("fort"))
        assertTrue(!order.contains("doux"))
    }

    @Test
    fun leProfilEstDeduitDesMesures() {
        assertEquals("Calme", PartyCurves.profileOf(profile(95, 40)))
        assertEquals("Rythmique", PartyCurves.profileOf(profile(120, 50)))
        assertEquals("Explosif", PartyCurves.profileOf(profile(128, 85)))
        assertEquals("Doux", PartyCurves.profileOf(profile(null, 40)))
    }

    @Test
    fun laDureeLimiteLeNombreDeMorceaux() {
        val order = PartyCurves.build(tracks, profiles, PartyCurve.PROGRESSIF, 2)
        assertEquals(2, order.size)
    }
}
