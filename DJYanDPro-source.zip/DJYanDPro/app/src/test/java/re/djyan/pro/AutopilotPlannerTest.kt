package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Test

class AutopilotPlannerTest {
    private val slow = LocalTrack("slow", "Zulu")
    private val medium = LocalTrack("medium", "Alpha")
    private val fast = LocalTrack("fast", "Bravo")
    private val unknown = LocalTrack("unknown", "Charlie")

    @Test fun ordersMeasuredTracksByIncreasingBpmAndUnknownsLast() {
        val plan = AutopilotPlanner.plan(listOf(fast, unknown, slow, medium), mapOf("slow" to 90, "medium" to 110, "fast" to 130))
        assertEquals(listOf(slow, medium, fast, unknown), plan.orderedTracks)
        assertEquals(3, plan.analyzedTrackCount)
    }

    @Test fun usesTitleOnlyToOrderTracksWithoutMeasuredBpm() {
        val plan = AutopilotPlanner.plan(listOf(slow, unknown, fast), emptyMap())
        assertEquals(listOf(fast, unknown, slow), plan.orderedTracks)
        assertEquals(0, plan.analyzedTrackCount)
    }
}
