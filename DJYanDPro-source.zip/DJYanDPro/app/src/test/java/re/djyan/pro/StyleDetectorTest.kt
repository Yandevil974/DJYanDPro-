package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Détection du style depuis le nom de fichier ou la métadonnée « genre ». */
class StyleDetectorTest {

    @Test
    fun leStyleEstLuDansLeNomDuFichier() {
        assertEquals("Zouk Love", StyleDetector.detect("Kassav - Zouk Love 2024.mp3"))
        assertEquals("Ragga", StyleDetector.detect("DJ Yan-D - Ragga Session.mp3"))
        assertEquals("Rap", StyleDetector.detect("01 - Rap FR Intro.m4a"))
        assertEquals("Séga", StyleDetector.detect("sega maloya reunion.mp3"))
        assertEquals("Amapiano", StyleDetector.detect("Amapiano Nights.flac"))
    }

    @Test
    fun laMetadonneeGenreEstPrioritaire() {
        assertEquals("Dancehall", StyleDetector.detect("Dancehall", "un nom sans style.mp3"))
        assertEquals("House", StyleDetector.detect("House", "zouk.mp3"))
    }

    @Test
    fun lesDecenniesSontReconnues() {
        assertEquals("Années 90", StyleDetector.detect("Best of 90s.mp3"))
        assertEquals("Années 2000", StyleDetector.detect("2000s hits.ogg"))
    }

    @Test
    fun lesAccentsNeGenePas() {
        assertEquals("Séga", StyleDetector.detect("SÉGA TROPICAL.mp3"))
        assertEquals("Séga", StyleDetector.detect("séga créole.wav"))
    }

    @Test
    fun onNeDevinePasUnStyleQuiNyEstPas() {
        assertNull(StyleDetector.detect("parapluie.mp3"))
        assertNull(StyleDetector.detect("track 01.mp3"))
        assertNull(StyleDetector.detect(null))
        assertNull(StyleDetector.detect(""))
    }
}
