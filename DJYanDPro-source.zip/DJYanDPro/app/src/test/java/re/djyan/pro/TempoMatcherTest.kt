package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Calage de tempo : la vitesse appliquée à la piste entrante doit rejoindre le
 * tempo de la piste en cours, et rester dans la limite fixée par l'utilisateur.
 */
class TempoMatcherTest {

    private val tolerance = 0.001f

    @Test
    fun laVitesseAligneLeMorceauEntrantSurLeMorceauEnCours() {
        assertEquals(128f / 132f, TempoMatcher.speedFor(128, 132, 8), tolerance)
    }

    @Test
    fun unEcartTropGrandEstBridéPasIgnore() {
        assertEquals(0.92f, TempoMatcher.speedFor(128, 160, 8), tolerance)
        assertEquals(1.08f, TempoMatcher.speedFor(128, 100, 8), tolerance)
    }

    @Test
    fun sansBpmMesureAucuneVitesseNEstAppliquee() {
        assertEquals(1f, TempoMatcher.speedFor(0, 132, 8), tolerance)
        assertEquals(1f, TempoMatcher.speedFor(128, 0, 8), tolerance)
    }

    @Test
    fun leTempoEffectifEstCeluiQuiEstEntendu() {
        assertEquals(128, TempoMatcher.effectiveBpm(132, 128f / 132f))
        assertEquals(0, TempoMatcher.effectiveBpm(0, 1f))
    }

    @Test
    fun leCalageAnnonceSilEstExactOuBridé() {
        assertTrue(TempoMatcher.isExact(128, 132, 8))
        assertFalse(TempoMatcher.isExact(128, 160, 8))
    }

    @Test
    fun uneLimiteDeZeroInterditTouteModification() {
        assertEquals(1f, TempoMatcher.speedFor(128, 140, 0), tolerance)
    }
}
