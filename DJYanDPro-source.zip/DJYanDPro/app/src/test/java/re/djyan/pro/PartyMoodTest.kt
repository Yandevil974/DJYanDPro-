package re.djyan.pro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Catalogue des ambiances : décennies, mashup, disco… et traduction des styles. */
class PartyMoodTest {

    @Test
    fun toutesLesDecenniesSontDisponibles() {
        val labels = PartyMood.labels
        listOf("Années 80", "Années 90", "Années 2000", "Années 2010", "Années 2020").forEach {
            assertTrue("manque $it", labels.contains(it))
        }
    }

    @Test
    fun lesAmbiancesRecentesSontPresentes() {
        assertTrue(PartyMood.labels.contains("Mashup"))
        assertTrue(PartyMood.labels.contains("Disco"))
        assertTrue(PartyMood.labels.contains("Funk"))
        assertTrue(PartyMood.labels.contains("Nouveautés 2025-2027"))
    }

    @Test
    fun uneDecenniePorteSaPeriodeDeSortie() {
        val nineties = PartyMood.specFor("Années 90")
        assertEquals("1990-01-01", nineties.fromDate)
        assertEquals("1999-12-31", nineties.toDate)
        assertTrue(nineties.jamendoTags.contains("90s"))
    }

    @Test
    fun uneAmbianceSansPeriodeNaPasDeDates() {
        val chill = PartyMood.specFor("Chill")
        assertEquals(null, chill.fromDate)
        assertEquals(null, chill.toDate)
    }

    @Test
    fun uneAmbianceInconnueNePlantePas() {
        val spec = PartyMood.specFor("Ambiance Extraterrestre")
        assertNotNull(spec)
        assertTrue(spec.bpmRange.first >= 0)
    }

    @Test
    fun lesStylesSontTraduitsEnAnglais() {
        assertEquals("house", PartyMood.styleTag("House"))
        assertEquals("zouk", PartyMood.styleTag("Zouk Love"))
        assertEquals("sega", PartyMood.styleTag("Séga"))
        assertEquals("80s", PartyMood.styleTag("Années 80"))
    }
}
