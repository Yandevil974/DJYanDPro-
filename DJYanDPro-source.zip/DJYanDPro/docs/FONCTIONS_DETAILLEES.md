# ⚙️ FONCTIONS DÉTAILLÉES — périmètre réel de chaque fonction

> Ce document regroupe les 6 anciens fichiers `*_SCOPE.md` / `LIVE_TEMPO_ADAPTATION.md`
> en un seul, **sans aucune perte de contenu**.
> Il décrit ce qui est **réellement codé** — rien de plus.

## Sommaire
1. Bibliothèque locale autorisée
2. Compatibilité tempo
3. Crossfade local
4. Volume DJ Yan-D
5. Autopilote local
6. Adaptation en direct : Plus calme / Plus festif
7. **Mix préparé** (ajouté le 28/08/2026)
8. **Commandes live : J'aime / Plus dansant / Changer de style** (ajouté le 28/08/2026)
9. **Sauvegarde / Restauration** (ajouté le 28/08/2026)
10. **Niveau DJ 1 : calage de tempo** (ajouté le 28/08/2026)
11. **Niveau DJ 3 : échange des basses** (ajouté le 28/08/2026)
12. **Catalogue Jamendo** (ajouté le 28/08/2026)

---

# Bibliothèque locale autorisée — périmètre réel

## Ce que fait la version actuelle

- Lance le sélecteur de documents fourni par Android avec le type MIME `audio/*`.
- Permet de sélectionner plusieurs fichiers dans une seule action.
- Conserve uniquement les URI de documents et leurs noms déclarés par Android dans DataStore.
- Tente de conserver la permission persistante de lecture accordée par le fournisseur de documents.
- Envoie les URI sélectionnées au `YanDPlaybackService`, qui les transmet à Media3/ExoPlayer comme file de lecture.
- L'enchaînement standard « piste suivante » est assuré par le player lorsque le format est lisible.
- Le bouton **INFOS** interroge `MediaMetadataRetriever` sur le fichier sélectionné et affiche uniquement les données réellement fournies : durée, type MIME, débit et, sous Android 12+, fréquence d’échantillonnage.
- Le bouton **BPM** décode localement au maximum 180 secondes de la piste vers PCM 16 bits, calcule une enveloppe d’énergie puis recherche sa périodicité par autocorrélation. Un BPM n’est affiché que si un pic rythmique mesurable franchit le seuil de confiance. L’interface indique le pourcentage de confiance et la durée réellement analysée.

## Ce que l'application ne fait pas

- ne copie pas les fichiers ;
- ne télécharge pas de catalogue ;
- ne scanne pas le stockage complet de l'appareil ;
- ne prétend pas détenir les droits de l'utilisateur ;
- ne génère pas d'audio à la place d'un fichier inaccessible ;
- ne réalise pas encore de crossfade, synchronisation BPM, EQ DJ, pitch, boucle, cue ou analyse de tonalité ;
- ne déduit pas le BPM, l’énergie ou la tonalité à partir de métadonnées absentes.

## Comportement attendu en cas d'échec

Un URI inaccessible ou un format non pris en charge doit conduire à une erreur Media3/ExoPlayer. La prochaine étape est d'exposer proprement cette erreur dans l'interface avec le titre concerné et une action « retirer de la file ». Aucun contenu alternatif ne sera lancé automatiquement à ce stade.

---

# Compatibilité tempo — périmètre exact

## Données nécessaires

Deux pistes de la bibliothèque locale doivent d’abord avoir chacune une estimation BPM réellement calculée par `LocalBpmAnalyzer`. En l’absence d’un BPM validé, le bouton **COMPARER** est désactivé.

## Calcul affiché

Pour deux BPM `A` et `B` :

```text
écart = |A - B|
score = arrondi(100 - écart / max(A, B) × 100)
score borné entre 0 et 100
```

L’interface affiche le score, les deux BPM et l’écart BPM.

## Limites volontairement affichées

Ce résultat est une **compatibilité tempo seulement**. Il ne mesure pas :

- la tonalité ou l’harmonie ;
- la structure de la piste ;
- les phrases musicales ;
- le style, sous-genre ou époque ;
- l’énergie ;
- le rythme ou la qualité artistique du passage.

Aucun crossfade, ajustement de tempo, EQ, boucle, filtre ou transition audio n’est déclenché par ce score.

---

# Crossfade local — comportement réellement implémenté

## Conditions

Le crossfade est tenté uniquement quand :

1. la file locale contient une piste suivante ;
2. cette piste suivante a été préchargée avec succès par Media3 ;
3. la piste courante fournit une durée supérieure à la durée de crossfade choisie ;
4. la lecture est proche des dernières secondes correspondant à ce réglage.

## Traitement audio

Le service crée deux `ExoPlayer` distincts :

- lecteur actif : piste courante, volume 1 → 0 ;
- lecteur de réserve : piste suivante préchargée, volume 0 → 1.

La durée est réglable de 0 à 12 secondes et est mémorisée localement. `0 s` désactive volontairement le crossfade et demande un passage simple. Pour une valeur positive, la rampe est recalculée toutes les 50 ms pendant les dernières secondes correspondantes. Les deux signaux joués sont donc de vrais fichiers locaux sélectionnés par l’utilisateur ; aucun signal synthétique n’est créé.

## Cas où le fondu ne peut pas être fait

Si la durée est absente/courte, ou si la piste suivante ne devient pas prête, le service passe à la piste suivante seulement lorsqu’il le peut. Ce passage n’est pas présenté comme un crossfade et aucun bruit ne masque l’absence de fondu.

## Hors périmètre

- BPM sync ;
- ajustement de pitch ;
- correction harmonique ;
- EQ ;
- loops, hot cues, filtres ou effets ;
- décision automatique de transition basée sur un score.

---

# Volume DJ Yan-D — périmètre réel

Le curseur **Volume DJ Yan-D** règle le gain interne des deux `ExoPlayer` locaux entre 0 % et 100 %.

- 100 % : gain applicatif unitaire ;
- 0 % : signal Yan-D silencieux, sans arrêt automatique de la lecture ;
- pendant un crossfade : le gain maître multiplie les deux rampes de crossfade, afin de préserver leur rapport réel.

Ce réglage est mémorisé localement et envoyé au service de lecture. Il ne modifie pas le volume global Android ; les boutons matériels et réglages du système restent sous le contrôle de l’utilisateur et du système Android.

Aucun compresseur, normaliseur, limiteur ou égaliseur n’est prétendu par cette fonction.

---

# Autopilote local — fonctionnement réel actuel

## Ce que fait l’utilisateur

1. Il choisit ses fichiers audio autorisés via Android.
2. Il règle éventuellement le volume et la durée de crossfade.
3. Il appuie sur **LANCER L’AUTOPILOTE LOCAL**.

Il n’a ensuite pas à mixer : aucune action sur les volumes, les deux decks ou les transitions n’est nécessaire. Il peut toutefois utiliser **SUIVANT** pour demander à Yan-D de passer immédiatement au prochain fichier local réel.

## Ce que Yan-D fait automatiquement

- lance la première piste de la file locale ;
- précharge la suivante ;
- tente le crossfade selon les conditions documentées ;
- enchaîne automatiquement la piste suivante ;
- continue jusqu’à la fin de la file ou jusqu’à l’action Pause/Arrêter de l’utilisateur ;
- signale une erreur de lecture réelle ;
- lorsqu’une piste active échoue avant une transition, tente automatiquement la piste locale suivante réellement présente dans la file ; si aucune ne reste, arrête la lecture.

Aucun son de compensation, aucun téléchargement et aucun morceau inventé ne sont utilisés lors de ce remplacement.

## Préparer l’ordre autopilote

Le bouton **PRÉPARER L’ORDRE AUTOPILOTE** analyse successivement les fichiers locaux, puis réenregistre réellement la file avec les pistes dont le BPM a été établi rangées par BPM croissant. Les pistes sans BPM fiable restent à la fin, classées par nom. L’interface indique le nombre de BPM effectivement établis.

## Limites transparentes de cette version

Cette préparation ne réordonne qu’à partir du BPM mesuré. Elle n’analyse pas la tonalité, la structure, les phrases musicales, l’énergie ou les styles. Elle ne choisit pas des morceaux depuis un catalogue externe : aucune source catalogue légalement intégrée n’est active.

L’autopilote n’est donc pas encore le DJ AI complet décrit dans la vision finale, mais il est autonome pour l’analyse BPM locale, la préparation d’un ordre simple, la lecture, le préchargement et le crossfade des fichiers locaux réellement fournis.

---

# Adaptation en direct : Plus calme / Plus festif

## Condition

L’autopilote doit avoir reçu les BPM réellement calculés pour les fichiers de la file. Les commandes restent désactivées dans l’interface tant qu’aucun BPM n’est connu.

## Plus calme

Yan-D conserve la piste actuelle, trie les pistes restantes avec BPM par ordre croissant et précharge la première de ce nouvel ordre. Les pistes dont le BPM est inconnu restent après les autres.

## Plus festif

Yan-D conserve la piste actuelle, trie les pistes restantes avec BPM par ordre décroissant et précharge la première de ce nouvel ordre. Les pistes sans BPM restent après les autres.

## Règles de sécurité

- aucune piste n’est inventée ou téléchargée ;
- aucun BPM absent n’est remplacé par une valeur artificielle ;
- si un crossfade est déjà engagé, l’ordre n’est pas modifié pendant ce fondu afin de ne pas perturber les deux flux réels ;
- cette adaptation ne prétend mesurer que le tempo, pas l’énergie musicale, le genre, la tonalité ou la structure.

---

# 7. MIX PRÉPARÉ — périmètre réel

Ajouté le 28/08/2026. Écran accessible depuis l'accueil (`🎚️ MIX PRÉPARÉ`).

## Ce que fait l'utilisateur
1. Il compose une liste **ordonnée** en touchant ses fichiers dans l'ordre où il veut les entendre.
2. Il donne un nom (facultatif) et enregistre.
3. Il lance le mix. Yan-D lit et enchaîne, sans rien ajouter.

## Ce qui est réellement implémenté
- **Mémorisation de l'ordre** : `PreparedMixRepository` stocke la liste dans DataStore.
  Le codec (`PreparedMixCodec`) est testé unitairement : l'ordre est strictement conservé
  (test `lordreDesPistesEstConserveApresEncodage`).
- **Lecture** : le mix est envoyé au service via `ACTION_PLAY_QUEUE`, exactement comme
  l'autopilote — mêmes deux ExoPlayer, même fondu, même préchargement.
- **Ordre verrouillé** : l'extra `EXTRA_LOCK_ORDER = true` empêche toute réorganisation.
  `adaptRemaining()` (PLUS CALME / PLUS FESTIF) **sort immédiatement** quand l'ordre est
  verrouillé. Le mix composé par l'utilisateur n'est jamais réordonné.
- **Set long** : un mix d'un seul fichier (1 h, ou une vidéo dont on ne garde que la piste
  audio) est lu d'un bout à l'autre. Aucun fondu interne n'est tenté (il n'y a rien à fondre).
- **Réinitialisation des refus** : `ACTION_CLEAR_REJECTS` vide la liste des fichiers
  écartés par « PAS CELUI-LÀ », pour qu'un mix puisse être rejoué intégralement.

## Vérification de format (`LocalFormatCheck`)
- Ouvre le fichier avec `MediaMetadataRetriever` (décodeur Android réel).
- Lit le type MIME et la durée exposés par le système.
- Signale comme **non lisibles** les formats que Media3/ExoPlayer ne décode pas sans
  l'extension FFmpeg : WMA, APE, ALAC, AIFF, WavPack, MIDI.
- Signale une vidéo comme **lisible en audio seul** (`video/*` → « seule la piste audio sera lue »).
- **Ne garantit rien** : c'est une lecture de métadonnées, pas une écoute. Seul un test sur
  l'appareil valide la lecture.

## Ce que ce mode ne fait PAS
- Il ne télécharge rien, n'ajoute aucun son, n'invente aucun morceau.
- Il ne réorganise pas l'ordre (verrouillé).
- Il ne lit que les fichiers déjà présents dans SOURCES MUSICALES.
- Il n'analyse pas le BPM du mix (sans intérêt puisque l'ordre est fixe).

## État
**Codé, jamais compilé ni exécuté.** Validation requise sur appareil.

# 8. COMMANDES LIVE — ❤️ J'AIME · 💃 PLUS DANSANT · 🎵 CHANGER DE STYLE

Ajouté le 28/08/2026. Écran `🎛️ COMMANDES LIVE` (route `live`).

## ❤️ J'AIME
- **Ce qui est réel** : mémorise le choix de l'utilisateur dans `TrackPreferencesRepository`
  (DataStore, codec testé). La liste « MES COUPS DE CŒUR » est affichée et peut être
  relancée directement (`▶ LANCER MES COUPS DE CŒUR`).
- **Effet concret sur la lecture** : aimer **annule un rejet précédent** — le titre est
  retiré de la liste des fichiers écartés par « PAS CELUI-LÀ » et redevient jouable
  (`ACTION_LIKE_URI`).
- **Ce qui n'est PAS fait** : aucune recherche de « titres similaires », aucune
  recommandation. Il n'existe aucun catalogue connecté : aimer ne peut pas ajouter
  de musique.

## 💃 PLUS DANSANT
- **Ce qui est réel** : trie la file restante en plaçant en tête les pistes dont le
  **BPM réellement mesuré** par `LocalBpmAnalyzer` tombe dans la plage choisie par
  l'utilisateur (`QueueReorder.byDanceRange`, testé).
- **La plage est un réglage, pas une analyse** : deux curseurs (défaut 100 → 130 BPM),
  enregistrés dans `PlaybackSettingsRepository`. L'application ne prétend pas savoir
  ce qui est « dansant » : elle applique le chiffre que l'utilisateur a fixé.
- **Les BPM inconnus ne sont jamais devinés** : ils finissent la file.

## 🎵 CHANGER DE STYLE
- **Ce qui est réel** : l'utilisateur **étiquette lui-même** ses fichiers (12 styles
  disponibles). La commande place en tête les pistes portant l'étiquette demandée
  (`QueueReorder.byStyle`, testé).
- **Ce qui n'est PAS fait** : l'application ne reconnaît AUCUN style à l'écoute.
  Aucune analyse de genre, de timbre ou de rythme n'est effectuée. Un fichier non
  étiqueté reste non étiqueté et ne passe jamais devant les autres.

## Effet sur un mix préparé
Les trois réorganisations (`adaptRemaining`, `reorderByDanceRange`, `reorderByStyle`)
**sortent immédiatement** quand l'ordre est verrouillé (`EXTRA_LOCK_ORDER`). Un mix
préparé n'est donc jamais réorganisé, quelle que soit la commande.

## Persistance des BPM
Les BPM mesurés sont désormais enregistrés (`LocalBpmRepository`) et relus au
démarrage de l'écran : ils ne sont plus perdus en changeant d'écran, et les
commandes PLUS CALME / PLUS FESTIF / PLUS DANSANT restent disponibles.

## État
**Codé, jamais compilé ni exécuté.** 8 tests unitaires couvrent les règles de tri ;
le comportement audio réel reste à valider sur appareil.

# 9. SAUVEGARDE / RESTAURATION

Ajouté le 28/08/2026. Écran `⚙️ PARAMÈTRES`.

## Ce qui est sauvegardé
Un fichier **texte** que l'utilisateur place où il veut (Drive, carte SD, mail…) :

| Donnée | Détail |
|---|---|
| Bibliothèque | les références (URI) et noms de tes fichiers |
| Mix préparés | nom + liste ordonnée |
| Soirées | tous les projets enregistrés |
| Coups de cœur | les URI aimées |
| Étiquettes de style | le style attribué à chaque fichier |
| BPM mesurés | pour ne pas avoir à ré-analyser |
| Réglages | fondu, volume, plage dansante |
| Refus | la liste « PAS CELUI-LÀ » |

## Ce qui n'est PAS sauvegardé
- **Aucun fichier audio.** L'application ne copie jamais la musique.
- Aucune playlist, aucun catalogue, aucune donnée inventée.

## Comportement réel après restauration
Chaque fichier est **réellement testé** (`LocalFormatCheck`) : l'écran annonce
« X fichier(s) relisible(s) sur Y ». Sur un autre appareil, les URI ne pointent
plus vers rien → il faut re-sélectionner les fichiers. C'est annoncé avant, pas découvert après.

## Restauration = remplacement
Les mixes et soirées **absents** du fichier sont supprimés, pour que le résultat
corresponde exactement à la sauvegarde, sans mélange.

## Format
Texte lisible, versionné (`DJYANDPRO_BACKUP` + `FORMAT|1`), base64 URL-safe.
Un fichier étranger ou une version inconnue est **refusé** plutôt que mal interprété.
Le codec est pur Kotlin (java.util.Base64) et **testé unitairement** (6 tests).

## État
**Codé, jamais compilé ni exécuté.**

# 10. NIVEAU DJ 1 — CALAGE DE TEMPO (beatmatch)

## Ce qui est réel
La piste **entrante** voit sa vitesse ajustée pour que son tempo rejoigne celui de la
piste **en cours** : `vitesse = BPM_en_cours / BPM_entrant`, appliquée via
`PlaybackParameters(vitesse, pitch = 1.0)` d'ExoPlayer → **la hauteur (la voix) est
conservée**, ce n'est pas un disque rayé.

## Conditions strictes
- Les **deux** BPM doivent avoir été **réellement mesurés** (`LocalBpmAnalyzer`).
  Sans BPM, aucune vitesse n'est appliquée (1.0). Jamais devinée.
- L'écart est **bridé** par un réglage (défaut 8 %, curseur 0–30 %). Au-delà, la
  vitesse est bloquée à la limite : le calage est alors **partiel**, pas parfait.
- Après la transition, le morceau entrant **garde** sa vitesse : le tempo de la
  soirée reste verrouillé là où il a été calé, comme un DJ qui laisse le pitch.

## État
Codé, **jamais compilé ni écouté**. Le calcul de vitesse est testé unitairement
(6 tests). **Le rendu sonore du time-stretching reste à valider à l'oreille.**

# 11. NIVEAU DJ 3 — ÉCHANGE DES BASSES

## Ce qui est réel
Pendant le fondu, un **égaliseur système Android** (`android.media.audiofx.Equalizer`)
est attaché à la session audio de chaque lecteur :
- les basses du morceau **sortant** s'effacent progressivement (0 → −12 dB) ;
- les basses du morceau **entrant** s'ouvrent progressivement (−12 dB → 0).

Les bandes concernées sont les bandes dont la fréquence centrale est ≤ 250 Hz,
et le niveau est bridé à ce que l'appareil accepte (`getBandLevelRange`).

## Si l'appareil refuse
Si l'effet n'est pas disponible (session audio absente, ROM bridée), l'égaliseur
reste `null` et **rien n'est annoncé comme traité** : l'échec est silencieux côté
audio, jamais présenté comme une réussite.

## État
Codé, **jamais compilé ni écouté**.

# 12. CATALOGUE JAMENDO (en plus, jamais à la place)

## Ce qui est réel
- Client **officiel** de l'API Jamendo v3.0 (`JamendoClient`) : recherche par tags
  (house, edm, chill…) et par nom de titre.
- Lecture en flux (streaming) via les URL `audio` renvoyées par l'API — lues par
  les deux mêmes ExoPlayer.
- Téléchargement via `DownloadManager` **uniquement** si l'artiste l'autorise
  (champ `audiodownload` non vide). Sinon le bouton affiche « REFUSÉ ».
- L'identifiant (`client_id`) est fourni par l'utilisateur, gratuitement, sur
  `devportal.jamendo.com`. **Aucune clé n'est intégrée au code.**

## Ce que ça n'est pas
- Ce sont des **artistes indépendants sous licence Creative Commons** : ni hits
  commerciaux, ni sets de festival. C'est écrit dans l'écran.
- Le BPM **n'est pas analysé** sur les titres en ligne (l'analyseur est local).
- Nécessite une connexion : contrairement aux fichiers locaux, une coupure réseau
  peut interrompre la lecture.

## Permissions ajoutées
`INTERNET` (streaming + API) et `WRITE_EXTERNAL_STORAGE` limitée à `maxSdkVersion 28`
(téléchargement sur les anciens Android uniquement).

## État
Codé, **jamais compilé ni exécuté**. Le parsing JSON n'est pas couvert par les tests
(org.json n'est pas disponible sur JVM) : il devra être validé sur appareil.
