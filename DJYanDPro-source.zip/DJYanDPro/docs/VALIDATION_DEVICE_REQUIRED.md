# Validation obligatoire sur appareil Android avant toute déclaration de version fonctionnelle

Les fonctions ci-dessous ont été codées mais ne doivent pas être déclarées validées tant qu’elles n’ont pas été compilées et exécutées sur un vrai appareil Android avec de vrais fichiers audio autorisés.

## Parcours autonome à valider

1. Sélectionner au moins trois fichiers locaux réels.
2. Appuyer sur **PRÉPARER L’ORDRE AUTOPILOTE**.
3. Vérifier les BPM affichés ou les erreurs explicites.
4. Appuyer sur **LANCER L’AUTOPILOTE LOCAL**.
5. Verrouiller l’écran et vérifier la continuité de la lecture.
6. Vérifier le préchargement et le crossfade avec une durée positive.
7. Débrancher un support ou rendre un URI inaccessible afin de vérifier le passage à la prochaine piste réelle.
8. Vérifier que l’arrêt final ne produit aucun bruit, tonalité, boucle ou contenu de remplacement.

## Points Android à tester impérativement

- Android 8, 12, 13+ ;
- autorisation de notification Android 13+ ;
- sorties haut-parleur, casque filaire et Bluetooth ;
- retrait de casque ou de périphérique Bluetooth pendant lecture : Yan-D doit se mettre en pause via `ACTION_AUDIO_BECOMING_NOISY` ;
- perte / reprise d’audio focus (appel, assistant, autre application) : les deux lecteurs doivent s’arrêter lors de l’interruption temporaire et reprendre seulement après le gain audio focus ;
- perte définitive d’audio focus : Yan-D reste en pause et n’effectue pas de reprise automatique ;
- fichiers MP3, M4A/AAC, OGG, FLAC selon capacités du téléphone ;
- fichiers très courts, fichiers longs et fichiers invalides ;
- verrouillage d’écran et retour depuis les contrôles média.

## Critère d’acceptation

Le résultat n’est acceptable que si l’utilisateur lance une fois l’autopilote puis laisse Yan-D gérer seul l’enchaînement réel des fichiers accessibles. Toute erreur doit être visible et conduire soit à la piste réelle suivante, soit à un arrêt propre — jamais à un son synthétique.
