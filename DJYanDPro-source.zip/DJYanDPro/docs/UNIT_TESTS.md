# Tests unitaires actuels

Les tests unitaires ne remplacent pas les tests audio sur téléphone. Ils vérifient les règles déterministes qui n’ont pas besoin d’un décodeur Android.

## `BpmCompatibilityTest`

Ce test couvre :

- mêmes BPM → score 100 % ;
- écart BPM relatif → score correspondant à la formule documentée ;
- symétrie de la comparaison A/B et B/A ;
- bornage du score entre 0 et 100.

## `AutopilotPlannerTest`

Ce test couvre :

- ordre BPM croissant pour les pistes dont le BPM a réellement été établi ;
- placement des pistes sans BPM à la fin ;
- ordre alphabétique déterministe seulement entre les pistes sans BPM ;
- nombre exact de pistes analysées dans le plan.

La CI exécute :

```bash
./gradlew --no-daemon testDebugUnitTest
```

avant de construire l’APK de débogage.

## Limite

Les tests de `MediaCodec`, de sélection de fichiers, de MediaSession, d’audio focus, de crossfade audible et de Bluetooth doivent être exécutés sur appareil/émulateur Android. Ils restent répertoriés dans `PHASE_1B_TEST_PLAN.md` et `VALIDATION_DEVICE_REQUIRED.md`.
