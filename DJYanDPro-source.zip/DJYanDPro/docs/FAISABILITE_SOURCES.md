# Registre de faisabilité des sources — 22 août 2026

## Règle de blocage

Une source n'est activée dans l'interface que si les quatre conditions suivantes sont établies :

1. API/SDK public et documenté ;
2. authentification et consentement applicables ;
3. droit contractuel et technique de lecture dans l'application ;
4. droit explicite d'appliquer le traitement DJ envisagé au flux décodé.

À défaut, l'état est `NON CONFIGURÉ` ou `NON DISPONIBLE`. Il est interdit de fabriquer des résultats, de simuler une connexion ou de substituer un contenu audio.

## Spotify

### Capacités envisageables

- OAuth 2.0 PKCE mobile, avec autorisation de l'utilisateur ;
- métadonnées, contenu utilisateur et playlists seulement dans les limites des endpoints, scopes et quotas valides ;
- contrôle distant de l'application Spotify grâce à Spotify App Remote lorsque l'application Spotify est installée.

### Limites bloquantes

- Spotify App Remote déporte la lecture vers l'application Spotify ; Yan-D PRO ne reçoit pas un PCM décodé exploitable par un moteur DJ.
- Le SDK Android indique qu'un compte Spotify Premium est requis pour lire un URI de piste à la demande.
- Spotify ne peut donc pas être une source de crossfade, EQ, pitch, boucles ou analyse audio interne dans Yan-D PRO.
- Aucune extraction, aucun transfert audio vers Musify et aucun contournement Premium/DRM ne seront mis en œuvre.
- Depuis les changements 2026 de Spotify, la disponibilité API en mode développement est plus restrictive et le propriétaire de l'application doit avoir Premium. À confirmer avant toute activation sur l'état exact du compte et de l'application Developer.

### Décision

`SpotifyMetadataConnector` peut être développé après obtention d'un Client ID, d'une URI de redirection et d'une revue des conditions de publication. Il restera facultatif. Aucune clé ou secret ne doit être ajouté à l'APK.

Sources officielles :
- https://developer.spotify.com/documentation/web-api/concepts/authorization
- https://developer.spotify.com/documentation/web-api/tutorials/february-2026-migration-guide
- https://spotify.github.io/android-sdk/app-remote-lib/

## Musify (gokadzev/Musify)

Musify est identifié comme une application Android open source. Le site officiel liste ses fonctions utilisateur et renvoie vers GitHub/F-Droid. Aucune API publique partenaire officiellement documentée n'a été identifiée lors de l'audit initial pour qu'une autre application authentifie un compte, recherche son catalogue et lise légalement un flux dans son propre moteur audio.

### Décision

`MusifyConnector` est réservé dans l'architecture mais reste `NON DISPONIBLE`. Il ne sera activé qu'après réception d'une documentation API officielle et vérification des droits de recherche, lecture et traitement DJ.

Sources :
- https://gokadzev.github.io/Musify/
- https://github.com/gokadzev/Musify
- https://f-droid.org/en/packages/com.gokadzev.musify.fdroid/

## Source de référence pour le moteur DJ réel

`LocalLicensedSource` : fichiers audio choisis à travers le sélecteur Android, auxquels l'utilisateur possède les droits nécessaires. C'est la première source qui permet de tester honnêtement : double deck, préchargement, crossfade, égalisation, BPM, tempo et transitions.

Avant diffusion publique, les droits de lecture privée, de communication au public et de performance doivent être vérifiés selon le territoire et le cas d'usage (privé, bar, club, mariage, entreprise).
