# DJ Yan-D PRO — compilation dans Android Studio

## Pré-requis

- Android Studio récent, avec son JDK embarqué version 17 ou un JDK 17 configuré ;
- Android SDK Platform 35 ;
- Android SDK Build-Tools récent ;
- téléphone Android ou émulateur API 26 minimum ;
- connexion Internet pendant la première synchronisation Gradle, afin de télécharger les dépendances déclarées.

## Ouverture du projet

1. Copier le dossier `DJYanDPro` sur le PC.
2. Dans Android Studio : **File → Open**.
3. Sélectionner le dossier `DJYanDPro` contenant `settings.gradle.kts`.
4. Dans **Settings → Build, Execution, Deployment → Build Tools → Gradle**, sélectionner le JDK 17.
5. Laisser Android Studio synchroniser les fichiers Gradle.

Le projet déclare :

- `compileSdk = 35` ;
- `minSdk = 26` ;
- `targetSdk = 35` ;
- Kotlin 2.0.21 ;
- Android Gradle Plugin 8.6.1.

## Tests avant APK

Dans le terminal Android Studio à la racine du projet :

```bash
./gradlew testDebugUnitTest
```

Sous Windows :

```bat
gradlew.bat testDebugUnitTest
```

Les tests `BpmCompatibilityTest` et `AutopilotPlannerTest` doivent réussir. Un test échoué bloque la validation de l’APK.

## Générer l’APK de débogage

Dans Android Studio :

```text
Build → Build Bundle(s) / APK(s) → Build APK(s)
```

Ou en terminal :

```bash
./gradlew assembleDebug
```

Sous Windows :

```bat
gradlew.bat assembleDebug
```

Le chemin attendu est :

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Installation et premier essai

1. Copier l’APK sur le téléphone, ou utiliser **Run** depuis Android Studio.
2. Autoriser l’installation depuis la source concernée si Android le demande.
3. Sous Android 13+, accepter la permission de notification demandée par Yan-D : elle permet d’afficher les contrôles média du service de lecture. Si elle est refusée, la lecture locale peut rester possible selon Android, mais les contrôles de notification ne doivent pas être considérés comme disponibles.
4. Dans Yan-D : **Sources musicales → Choisir des fichiers audio**.
5. Sélectionner au moins trois fichiers audio que vous avez le droit de lire.
6. Appuyer sur **PRÉPARER L’ORDRE AUTOPILOTE**.
7. Appuyer sur **LANCER L’AUTOPILOTE LOCAL**.

## Résultat à communiquer après essai

Pour corriger réellement les problèmes éventuels, transmettre :

- la version Android du téléphone ;
- le modèle du téléphone ;
- une capture d’écran de l’erreur éventuelle ;
- le texte complet de l’erreur de compilation Android Studio, si la synchronisation ou la génération échoue ;
- si possible, le Logcat filtré avec `re.djyan.pro`.

Ne pas envoyer de mots de passe, secrets Spotify ni fichiers audio protégés.
