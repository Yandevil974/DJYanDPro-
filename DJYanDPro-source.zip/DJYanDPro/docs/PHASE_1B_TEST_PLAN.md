# Plan de test — Phase 1B : source locale et lecture réelle

> Statut : tests à exécuter sur appareil ou émulateur Android après compilation. Aucun résultat ci-dessous ne doit être coché avant exécution.

## Préconditions

- Android 8 (API 26) minimum ; Android 13+ recommandé pour tester les notifications.
- Un fichier audio que le testeur est autorisé à lire (MP3, M4A/AAC, FLAC ou OGG selon le décodeur de l'appareil).
- Le fichier est choisi par le sélecteur de documents Android ; l'application n'effectue aucune recherche de catalogue et ne télécharge rien.

## Cas de test fonctionnels

| ID | Action | Résultat attendu |
|---|---|---|
| L01 | Ouvrir Sources musicales sans fichier sélectionné | Bibliothèque audio autorisée : NON CONFIGURÉ ; aucun bouton de lecture actif. |
| L02 | Sélectionner un fichier audio avec le bouton dédié | Le vrai nom renvoyé par le fournisseur de documents s'affiche ; l'URI est conservée dans DataStore. |
| L03 | Fermer et relancer l'application | La même source reste affichée si la permission URI persistante a été accordée par le fournisseur. |
| L04 | Appuyer sur Lire ce fichier | `YanDPlaybackService` crée un ExoPlayer et lit uniquement l'URI sélectionnée. |
| L05 | Appuyer sur Pause puis reprendre via notification Android | Lecture réellement suspendue puis reprise, sans création de bruit ou piste de secours. |
| L06 | Verrouiller l'écran | La lecture continue via le service média de premier plan, si le système n'interrompt pas l'audio. |
| L07 | Brancher/débrancher casque ou Bluetooth | Android gère la route audio ; l'application ne plante pas. |
| L08 | Recevoir une interruption audio (appel/assistant) | Perte audio focus gérée par ExoPlayer, puis comportement Android standard à la reprise. |
| L09 | Choisir un fichier supprimé/inaccessible | ExoPlayer signale l'erreur ; l’écran Sources affiche le titre et le code d’erreur Media3, sans substitution audio. |
| L10 | Appuyer sur Arrêter | Player stoppé et service arrêté. |
| L11 | Retirer l’accès au fichier ou choisir un format non supporté, puis lancer la file | Réception d’un événement `PLAYBACK_ERROR` provenant du service ; message visible « ERREUR DE LECTURE RÉELLE ». |
| P01 | Créer un projet avec des styles/ambiance/durée/énergie et l’enregistrer | Le projet apparaît dans Mes soirées après fermeture et relance. |
| P02 | Ouvrir Mes soirées puis Dupliquer | Une seconde entrée est réellement ajoutée avec le suffixe « (copie) ». |
| P03 | Supprimer une entrée | Cette entrée disparaît, sans affecter les autres sauvegardes. |
| P04 | Examiner un projet sauvegardé | Il affiche explicitement « aucune playlist générée » : aucun morceau n’est inventé. |
| M01 | Choisir une piste puis appuyer sur INFOS | L’interface affiche seulement les métadonnées retournées par `MediaMetadataRetriever` : durée, MIME, débit et éventuellement fréquence d’échantillonnage. |
| M02 | Inspecter un URI inaccessible | L’interface affiche une erreur d’inspection ; aucun BPM, tonalité, genre ou donnée de remplacement n’est affiché. |
| B01 | Sur une piste rythmée accessible, appuyer sur BPM | L’analyse locale décode du PCM, affiche un BPM calculé, un pourcentage de confiance et le nombre de secondes réellement analysées. |
| B02 | Sur un fichier trop court, silencieux ou non décodable, appuyer sur BPM | L’interface affiche « BPM non établi » avec l’erreur réelle ; aucune valeur BPM de repli n’est affichée. |
| B03 | Lancer BPM sur une piste longue | L’analyse s’arrête après au plus 180 secondes de signal et indique cette durée réelle dans le résultat. |
| C01 | Calculer le BPM de deux pistes puis les retenir avec COMPARER | L’écran affiche un score de compatibilité tempo, les BPM et leur écart. |
| C02 | Retenir une piste sans BPM calculé | Impossible : le contrôle COMPARER reste désactivé. |
| C03 | Lire la note sous le score | Elle précise que tonalité, énergie, structure et style ne sont pas analysés et qu’aucune transition basée sur ce score n’est appliquée. |
| X01 | Mettre deux fichiers audio de plus de 6 s dans la file et lancer la lecture | Vérifier à l’écoute que le volume de la première piste baisse pendant que le volume de la suivante augmente sur les six dernières secondes. |
| X02 | Tester une piste courte ou sans durée disponible | Vérifier qu’aucun libellé ne prétend qu’un crossfade a eu lieu ; passage simple uniquement lorsque la piste suivante est prête. |
| X03 | Supprimer/rendre illisible la seconde piste avant le crossfade | Vérifier la remontée d’erreur Media3 et l’absence de bruit, tonalité ou morceau de remplacement. |
| X04 | Régler le curseur à 0 s, lancer une file puis relancer l’application | Le réglage est conservé ; la lecture effectue un passage simple sans prétendre faire de fondu. |
| X05 | Régler le curseur à une valeur positive, démarrer une file puis mettre pause pendant le fondu | Les deux lecteurs sont suspendus ; Reprendre relance les deux lecteurs si un crossfade est en cours. |
| V01 | Pendant une lecture, faire varier Volume DJ Yan-D entre 100 %, 50 % et 0 % | Le niveau des lecteurs Yan-D varie réellement, sans changer le volume système Android. |
| V02 | Régler le volume à 0 % pendant un crossfade | Les deux flux restent synchronisés mais silencieux ; relever le volume restaure le niveau selon les rampes de crossfade en cours. |
| V03 | Relancer l’application après avoir choisi un volume | Le pourcentage réglé est restauré depuis DataStore. |
| A01 | Mettre plusieurs fichiers dans la file puis toucher PRÉPARER L’ORDRE AUTOPILOTE | Chaque fichier est analysé successivement ; la progression et le nombre final de BPM réellement établis sont affichés. |
| A02 | Vérifier la file après la préparation | Les pistes avec BPM établi sont ordonnées par BPM croissant ; les autres restent après elles. |
| A03 | Lancer ensuite l’autopilote | Yan-D suit l’ordre réellement enregistré sans exiger de manipulation de crossfade ou de volume. |
| A04 | Inclure un fichier non décodable | Son BPM reste absent, une erreur réelle est affichée, et aucun BPM de repli n’est utilisé pour le tri. |
| A05 | Rendre illisible la piste active alors qu’une suivante réelle existe | L’autopilote signale l’erreur puis tente automatiquement la piste locale suivante. |
| A06 | Rendre illisible la dernière piste de la file | L’autopilote signale l’erreur puis s’arrête ; aucun son ou contenu de remplacement n’est diffusé. |
| D01 | Avec plusieurs BPM établis, lancer l’autopilote puis toucher PLUS CALME | La piste en cours continue ; les pistes restantes sont réordonnées du BPM le plus bas au plus haut. |
| D02 | Avec plusieurs BPM établis, lancer l’autopilote puis toucher PLUS FESTIF | La piste en cours continue ; les pistes restantes sont réordonnées du BPM le plus haut au plus bas. |
| D03 | Appuyer sur les commandes sans BPM établi | Les contrôles sont désactivés ; aucun ordre artificiel n’est créé. |
| D04 | Appuyer sur PLUS CALME ou PLUS FESTIF pendant un crossfade | La transition en cours n’est pas modifiée ; aucun changement dangereux de préchargement ne survient. |

## Test “aucun son artificiel”

1. Choisir une source non lisible, ou retirer le support contenant le fichier.
2. Demander sa lecture.
3. Vérifier au niveau haut-parleur/casque et logs qu'aucun oscillateur, tonalité, blanc sonore masqué, boucle synthétique ou contenu substitutif n'est créé.
4. Le seul résultat acceptable est une erreur de lecture documentée.

## Limites actuelles assumées

- Pas de double deck ; pas de crossfade ; pas de BPM/EQ/pitch : aucune de ces commandes n'est montrée comme active.
- Pas de catalogue, de recherche ni de playlist générée.
- Pas de connexion Spotify/Musify.
- Pas d'analyse automatique ni d'import massif de bibliothèque.
